(() => {
  let work = null, running = false, evidence = '', phase = 'READY', cancelled = false;
  const engines = ['native', 'codex', 'claude', 'hermes', 'mcode', 'opencode', 'kilo'];
  const setting = () => ({ worker: 'claude', reviewer: 'codex', rounds: 2, ...S.selfDev });
  const patch = (s) => saveSettings({ selfDev: { ...S.selfDev, ...s } });
  const click = (label, fn) => h('button', { class: 'acc', disabled: running, onclick: () => Promise.resolve(fn()).catch((e) => { evidence += '\n' + e.message; render(); toast(e.message); }) }, label);
  function render() {
    const s = setting();
    $('p-self').replaceChildren(...[h('h3', {}, 'FORGE / SELF DEVELOPMENT'), h('p', { class: 'note' }, 'Worker → real checks → supervisor → reviewed source. The running installation stays available while agents edit a separate working copy.'),
      h('div', { class: 'self-stage' }, phase),
      h('label', {}, 'Worker engine'), h('select', { disabled: running, onchange: (e) => patch({ worker: e.target.value }) }, engines.map((e) => h('option', { value: e, selected: e === s.worker }, ENGINE_LABEL[e] || e))),
      h('label', {}, 'Worker model override (optional)'), h('input', { disabled: running, value: s.workerModel || '', placeholder: 'Use this engine’s default', onchange: (e) => patch({ workerModel: e.target.value }) }),
      h('label', {}, 'Supervisor / reviewer'), h('select', { disabled: running, onchange: (e) => patch({ reviewer: e.target.value }) }, engines.map((e) => h('option', { value: e, selected: e === s.reviewer }, ENGINE_LABEL[e] || e))),
      h('label', {}, 'Reviewer model override (optional)'), h('input', { disabled: running, value: s.reviewerModel || '', placeholder: 'Use this engine’s default', onchange: (e) => patch({ reviewerModel: e.target.value }) }),
      h('label', {}, 'Maximum repair rounds'), h('input', { type: 'number', min: 1, max: 5, disabled: running, value: s.rounds, onchange: (e) => patch({ rounds: Math.max(1, Math.min(5, +e.target.value)) }) }),
      h('label', {}, 'What should Forge improve?'), h('textarea', { id: 'selfTask', rows: 4, disabled: running, placeholder: 'Fix a bug, complete a feature, improve a component…', oninput: (e) => { window._selfTask = e.target.value; } }, window._selfTask || ''),
      running ? h('button', { class: 'danger', onclick: async () => { cancelled = true; if (cur?.busy) api.acpCancel(cur.engine, cur.sessionId); await api.devCancel(); phase = 'CANCELLING'; render(); } }, 'STOP PIPELINE') : null,
      h('div', { class: 'row' }, click('CREATE WORKING COPY', prepare), click('RUN WORKER + SUPERVISOR', improve), click('VALIDATE', validate), click('INSPECT CHANGES', async () => { const r = await api.devDiff(); evidence += '\n' + JSON.stringify(r, null, 2); render(); }), click('CHECKPOINT HISTORY', async () => { const r = await api.devHistory(); evidence += '\n' + r.map(x => x.id + ' / ' + (x.appliedAt ? 'APPLIED' : x.review?.ok ? 'REVIEWED' : 'WORKING COPY')).join('\n'); render(); })),
      work ? h('p', { class: 'note' }, 'Workspace: ' + work.workspace) : null,
      h('div', { class: 'row' }, click('APPLY VALIDATED BUILD', async () => { const r = await api.devApply(); evidence += '\n' + r.message; render(); }), click('ROLL BACK SOURCE', async () => { const r = await api.devRollback(); evidence += '\n' + r.message; render(); })),
      h('pre', { class: 'self-evidence' }, evidence || 'No validation or review has run yet.')].filter(Boolean));
  }
  async function prepare() { if (cur?.busy) throw new Error('Stop the current task first.'); work = await api.devPrepare(); evidence = 'Working copy created.\n' + work.workspace; phase = 'WORKSPACE READY'; render(); }
  async function validate() { const result = await api.devValidate(); evidence = result.checks.map((c) => `${c.ok ? 'PASS' : 'FAIL'} · ${c.name}\n${c.output || ''}`).join('\n'); phase = result.ok ? 'CHECKS PASSED / REVIEW REQUIRED' : 'CHECKS FAILED'; render(); return result; }
  async function choose(eng, model) {
    await window.ForgeChat.switchTo(eng);
    if (model) { const option = cur?.config?.find((x) => x.id === 'model')?.options?.find((x) => x.value === model); if (!option) throw new Error('Model override is not offered by ' + eng + ': ' + model); await setModel(model); }
  }
  async function improve() {
    if (running || cur?.busy) throw new Error('Wait for or stop the current run.');
    const task = (window._selfTask || '').trim(); if (!task) throw new Error('Describe the improvement first.');
    if (!work) await prepare(); const s = setting(); const rounds = Math.max(1, Math.min(5, s.rounds));
    running = true; cancelled = false; let repair = '';
    try {
      await setProject(work.workspace); // Separate Forge chat and provider sessions rooted at the working copy.
      for (let round = 1; round <= rounds; round++) {
        phase = `WORKER / ROUND ${round} OF ${rounds}`; render();
        await choose(s.worker, s.workerModel);
        const writable = cur?.modes?.availableModes?.find(m => /^(agent|code|build|default|acceptEdits)$/.test(m.id)) || cur?.modes?.availableModes?.find(m => !/read.?only|^ask$|plan/i.test(m.id));
        if (writable) await setMode(writable.id);
        await window.ForgeMission.startMonitor(task);
        const workerResult = await sendText(`Work on Forge itself in this isolated workspace: ${work.workspace}\nGoal: ${task}\nRead AGENTS.md first. Inspect the actual source before editing. Implement working behavior, preserve existing integrations/animations, add meaningful regression coverage and run the relevant checks. Do not change the running installation, credentials, tests to hide failures, or code outside this working copy.\n${repair}`);
        if (cancelled) break;
        await api.monitorTurnEnded(); const supervised = await api.monitorReview(); if (!supervised?.ok) throw new Error('Runtime supervisor stopped the development worker.');
        if (!workerResult?.ok) throw new Error('Worker did not complete: ' + (workerResult?.error || workerResult?.stopReason || 'no response'));
        phase = 'VALIDATING'; render(); const result = await validate();
        if (cancelled) break;
        if (!result.ok) { repair = 'Validation failed. Fix these concrete failures:\n' + evidence.slice(-18000); continue; }
        phase = 'SUPERVISOR REVIEW'; render(); await window.ForgeChat.switchTo(s.reviewer, true); await choose(s.reviewer, s.reviewerModel);
        const mode = cur?.modes?.availableModes?.find((x) => /read.?only|^ask$/i.test(x.id)); if (mode) await setMode(mode.id);
        const reviewStart = transcript.length;
        const reviewerResult = await sendText(`Review the worker's implementation in ${work.workspace}. Goal: ${task}\nRead the actual files and changes. Inspect functional behavior, regressions, visual states and meaningful tests. This is a review: do not edit files. Verify that the evidence supports the result and state any unverified runtime dependencies.\nActual validation evidence:\n${evidence.slice(-16000)}\nFinish with exactly one final line: FORGE_REVIEW: PASS or FORGE_REVIEW: FAIL. PASS requires the requested behavior to be implemented and the checks to be adequate; praise or a passing syntax check alone is insufficient.`);
        if (cancelled) break;
        if (!reviewerResult?.ok) throw new Error('Supervisor did not complete: ' + (reviewerResult?.error || reviewerResult?.stopReason || 'no response'));
        const review = transcript.slice(reviewStart).reverse().find((t) => t.role === 'assistant')?.text || '';
        const verdict = review.trim().match(/FORGE_REVIEW:\s*(PASS|FAIL)\s*$/)?.[1] || 'FAIL';
        await api.devReview(verdict, review); evidence += '\n\nSUPERVISOR:\n' + review;
        if (verdict === 'PASS') { phase = 'VALIDATED / REVIEWED / READY TO APPLY'; break; }
        repair = 'Supervisor rejected the result. Correct the findings:\n' + review.slice(-12000); phase = 'REPAIR REQUIRED';
      }
      if (phase !== 'VALIDATED / REVIEWED / READY TO APPLY') phase = cancelled ? 'STOPPED BY USER' : 'STOPPED / REPAIR LIMIT REACHED';
    } catch (e) { phase = 'STOPPED / ERROR'; evidence += '\n' + e.message; throw e; } finally { running = false; render(); }
  }
  api.onDevEvent((event) => { if (event.kind === 'output') { evidence = (evidence + event.text).slice(-50000); const pre = $('p-self').querySelector('pre'); if (pre) pre.textContent = evidence; } });
  addEventListener('forge-ready', async () => { work = await api.devState(); if (work?.validation) evidence = JSON.stringify(work.validation, null, 2); render(); });
  window.ForgeSelfDev = { render, improve, running: () => running };
})();
