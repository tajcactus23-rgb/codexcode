const { app, BrowserWindow, ipcMain, dialog, shell, Notification, safeStorage, desktopCapturer, screen } = require("electron");
const { spawn, execFileSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline");

if (process.env.MCODE_GUI_SNAP) {
  // test runs get their own profile so they never fight the live app for the GPU cache
  const live = app.getPath("userData"), test = live + "-test";
  fs.mkdirSync(test, { recursive: true });
  try { fs.copyFileSync(path.join(live, "settings.json"), path.join(test, "settings.json")); } catch {}
  app.setPath("userData", test);
}
const SETTINGS_FILE = path.join(app.getPath("userData"), "settings.json");
const DEFAULTS = {
  mcodeDir: "C:\\dev\\minimax-code-0.5.2",
  cwd: app.getPath("home"),
  recents: [],
  snippets: [
    { name: "Explain this repo", text: "Give me a short tour of this codebase: structure, entry points, how to run it." },
    { name: "Fix failing tests", text: "Run the test suite, find the failures, and fix them." },
    { name: "Write tests", text: "Add tests for the code I changed most recently, then run them." },
  ],
  notify: true,
  freeOnly: true,
};
let settings = { ...DEFAULTS, ...readJson(SETTINGS_FILE) };
let win;

function readJson(f) { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return {}; } }
const cliPath = () => path.join(settings.mcodeDir, "dist", "cli.js");
function nodeBinary() {
  try { return execFileSync("where", ["node"], { encoding: "utf8" }).split(/\r?\n/).find(Boolean).trim(); } catch { return "node"; }
}
const NODE = nodeBinary();
let monitor;
const send = (ch, ...a) => { monitor?.observe(ch, ...a); if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); };
const NPM_DIR = path.join(process.env.APPDATA || "", "npm", "node_modules");
// mcode's bundled @vscode/ripgrep lookup fails under the pnpm layout ("ripgrep binary not found"), which cripples the
// agent's glob/grep. mcode falls back to rg on PATH, so put mcode's own rg.exe there for the processes we spawn.
const RG_DIR = path.join(settings.mcodeDir, "node_modules", "@vscode", "ripgrep-win32-x64", "bin");
const CHILD_ENV = { ...process.env, FREE_PROXY_KEY: process.env.FREE_PROXY_KEY || "local-proxy-no-secret" };
if (fs.existsSync(path.join(RG_DIR, "rg.exe"))) {
  const key = Object.keys(CHILD_ENV).find((k) => k.toUpperCase() === "PATH") || "PATH"; // Windows uses "Path"; keep one key
  CHILD_ENV[key] = RG_DIR + path.delimiter + (CHILD_ENV[key] || "");
}

require('./voice-clone.cjs')({ app, ipcMain, dialog, send, getWin: () => win, getSettings: () => settings, saveSettings: (patch) => { settings = { ...settings, ...patch }; fs.mkdirSync(path.dirname(SETTINGS_FILE), { recursive: true }); fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); } });
const filePipeline = require('./file-pipeline.cjs')({ app, ipcMain, dialog, send, getWin: () => win, getSettings: () => settings });
const runtime = require('./runtime.cjs')({ app, ipcMain, send, getSettings: () => settings, getWin: () => win, BrowserWindow, desktopCapturer, screen });
const sampleTelemetry = require('./telemetry.cjs').createSampler();
ipcMain.handle('system:telemetry', () => sampleTelemetry());
require('./self-dev.cjs')({ app, ipcMain, send, getSettings: () => settings });
require('./chat-store.cjs')({ app, ipcMain });
const integration = require('./integrations.cjs')({ app, ipcMain, safeStorage, getSettings: () => settings,
  saveSettings: (patch) => { settings = { ...settings, ...patch }; fs.mkdirSync(path.dirname(SETTINGS_FILE), { recursive: true }); fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); }, send, runtime, filePipeline });
function cancelAgent(engine, sessionId) { runtime.stop(); if (engine === 'native') return integration.cancel(sessionId); const a = agents.get(engine); if (a) write(a, { jsonrpc: '2.0', method: 'session/cancel', params: { sessionId } }); }
monitor = require('./supervisor.cjs')({ app, ipcMain, send, getSettings: () => settings, cancel: cancelAgent, review: async ({ engine, model, cwd, prompt, onSession }) => {
  await startAgent(engine);
  const created = await call(engine, 'session/new', { cwd: cwd || settings.cwd, mcpServers: await runtime.mcp() });
  const sessionId = created.sessionId; onSession(sessionId);
  try {
    if (model) await call(engine, 'session/set_config_option', { sessionId, configId: 'model', value: model });
    const mode = created.modes?.availableModes?.find(m => /read.?only|^ask$/.test(m.id));
    if (mode) await call(engine, 'session/set_mode', { sessionId, modeId: mode.id });
    const r = await call(engine, 'session/prompt', { sessionId, prompt: [{ type: 'text', text: prompt }] });
    return { ok: !r.stopReason || r.stopReason === 'end_turn' };
  } finally { call(engine, 'session/close', { sessionId }).catch(() => {}); }
} });
require('./telegram.cjs')({ app, ipcMain, send, getSettings: () => settings, getSecret: integration.getSecret, filePipeline,
  getStatus: () => ({ monitor: monitor.get(), cwd: settings.cwd, runtimeEvents: runtime.history.slice(0, 8) }), stopMission: () => { monitor.stop('Stopped from Telegram'); runtime.stop(); } });
function findBinary(name) {
  if (name && path.isAbsolute(name)) return fs.existsSync(name) ? name : null;
  const dirs = [path.join(app.getPath('home'), '.local', 'bin'), ...String(process.env.PATH || process.env.Path || '').split(path.delimiter)];
  for (const dir of dirs) for (const ext of process.platform === 'win32' ? ['.exe', '.cmd', '.bat', ''] : ['']) {
    const file = path.join(dir, name + ext); if (fs.existsSync(file)) return file;
  }
  return null;
}
function hermesCommand() {
  const cfg = settings.hermes || {};
  const file = findBinary(cfg.command || 'hermes');
  return [file || cfg.command || 'hermes', Array.isArray(cfg.args) ? cfg.args : ['acp']];
}
ipcMain.handle('hermes:check', async () => {
  const [file, args] = hermesCommand();
  if (!findBinary(file)) return { ok: false, message: 'Hermes launcher not found. Set its executable path in Settings → Hermes. On Windows/WSL use wsl.exe with ["--", "hermes", "acp"].' };
  return new Promise((resolve) => {
    const child = spawn(file, [...args, '--check'], { windowsHide: true, shell: false, env: CHILD_ENV }); let output = '';
    const timer = setTimeout(() => { child.kill(); resolve({ ok: false, message: 'Hermes check timed out.' }); }, 20000);
    const collect = (b) => { output = (output + b).slice(-5000); }; child.stdout.on('data', collect); child.stderr.on('data', collect);
    child.on('error', (e) => { clearTimeout(timer); resolve({ ok: false, message: e.message }); });
    child.on('close', (code) => { clearTimeout(timer); resolve({ ok: code === 0, message: output || 'Exit ' + code }); });
  });
});

// ---------- ACP agents (mcode / opencode / kilo), JSON-RPC over stdio ----------
function packageCommand(pkg) {
  try { const file = path.join(path.dirname(require.resolve(pkg + '/package.json')), 'dist', 'index.js'); return [NODE, [file]]; } catch { return [NODE, [path.join(__dirname, 'node_modules', pkg, 'dist', 'index.js')]]; }
}
const ENGINE_CMD = {
  codex: () => packageCommand('@agentclientprotocol/codex-acp'),
  claude: () => packageCommand('@agentclientprotocol/claude-agent-acp'),
  hermes: hermesCommand,
  mcode: () => [NODE, [cliPath(), "acp"]],
  opencode: () => [path.join(NPM_DIR, "opencode-ai", "bin", "opencode.exe"), ["acp"]],
  kilo: () => [path.join(NPM_DIR, "@kilocode", "cli", "node_modules", "@kilocode", "cli-windows-x64", "bin", "kilo.exe"), ["acp"]],
};
const ALLOWED_METHODS = /^(authenticate|session\/(new|load|resume|list|prompt|set_mode|set_config_option|fork|close|activate)|mcode\/session\/[a-z/_]+)$/;
const agents = new Map();

function startAgent(engine) {
  if (engine === 'native') return Promise.resolve({ protocolVersion: 1 });
  if (!ENGINE_CMD[engine]) return Promise.reject(new Error('Unknown agent engine: ' + engine));
  if (agents.has(engine)) return agents.get(engine).ready;
  const [file, args] = ENGINE_CMD[engine]();
  if (!findBinary(file) || (args[0]?.endsWith("index.js") && !fs.existsSync(args[0]))) return Promise.reject(new Error(`${engine} is not installed (${file})`));
  const agentEnv = { ...CHILD_ENV };
  if (engine === 'codex' || engine === 'claude') { delete agentEnv.OPENAI_API_KEY; delete agentEnv.CODEX_API_KEY; delete agentEnv.ANTHROPIC_API_KEY; delete agentEnv.ANTHROPIC_AUTH_TOKEN; }
  if (engine === 'codex') agentEnv.CODEX_CONFIG = JSON.stringify({ forced_login_method: 'chatgpt' });
  const child = spawn(file, args, { cwd: settings.cwd, env: { ...agentEnv, ...(engine === 'hermes' && settings.hermes?.localBase ? { OPENAI_BASE_URL: settings.hermes.localBase, OPENAI_API_KEY: 'local' } : {}) }, windowsHide: true, shell: false });
  const agent = { child, seq: 1, pending: new Map(), stderr: "", capabilities: {} };
  agents.set(engine, agent);
  child.stderr.on("data", (b) => { agent.stderr = (agent.stderr + b).slice(-4000); });
  child.on('error', (e) => { agents.delete(engine); for (const p of agent.pending.values()) p.reject(e); send('acp:exit', engine, -1, e.message); });
  child.on("exit", (code) => {
    agents.delete(engine);
    for (const p of agent.pending.values()) p.reject(new Error(`${engine} exited (${code})`));
    send("acp:exit", engine, code, agent.stderr.split("\n").filter(Boolean).slice(-3).join("\n"));
  });
  readline.createInterface({ input: child.stdout }).on("line", (line) => {
    let m; try { m = JSON.parse(line); } catch { return; }
    if (m.id != null && !m.method) {
      const p = agent.pending.get(m.id);
      if (!p) return;
      agent.pending.delete(m.id);
      m.error ? p.reject(new Error(m.error.message || "request failed")) : p.resolve(m.result);
    } else if (m.method && m.id != null) {
      if (m.method === "session/request_permission") send("acp:request", engine, m.id, m.method, m.params);
      else write(agent, { jsonrpc: "2.0", id: m.id, error: { code: -32601, message: "not supported by client" } });
    } else if (m.method) send("acp:notify", engine, m.method, m.params);
  });
  agent.ready = call(engine, "initialize", { protocolVersion: 1, clientCapabilities: { fs: { readTextFile: false, writeTextFile: false }, terminal: false, _meta: { "terminal-auth": true } } }, true)
    .then((r) => { agent.capabilities = r.agentCapabilities || {}; return r; })
    .catch((e) => { child.kill(); throw e; });
  return agent.ready;
}
function write(agent, msg) { agent.child.stdin.write(JSON.stringify(msg) + "\n"); }
function call(engine, method, params, internal = false) {
  if (engine === 'native') return integration.call(method, params);
  const agent = agents.get(engine);
  if (!agent) return Promise.reject(new Error(engine + " not running"));
  if (!internal && !ALLOWED_METHODS.test(method)) return Promise.reject(new Error("method not allowed: " + method));
  const id = agent.seq++;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { agent.pending.delete(id); reject(new Error(engine + ': ' + method + ' timed out')); }, method === 'session/prompt' ? 900000 : method === 'authenticate' ? 300000 : 30000);
    agent.pending.set(id, { resolve: (r) => { clearTimeout(timer); resolve(r); }, reject: (e) => { clearTimeout(timer); reject(e); } }); write(agent, { jsonrpc: "2.0", id, method, params }); });
}
ipcMain.handle("acp:start", (_e, engine) => startAgent(engine));
ipcMain.handle("acp:call", async (_e, engine, method, params) => { await startAgent(engine); if (/^session\/(new|load|resume)$/.test(method)) params = { ...params, mcpServers: [...(params?.mcpServers || []).filter(m => m.name !== 'forge-runtime'), ...await runtime.mcp()] }; return call(engine, method, params); });
ipcMain.on("acp:cancel", (_e, engine, sessionId) => cancelAgent(engine, sessionId));
ipcMain.on("acp:respond", (_e, engine, id, result) => { const a = agents.get(engine); if (a) write(a, { jsonrpc: "2.0", id, result }); });
ipcMain.handle("acp:restart", (_e, engine) => { agents.get(engine)?.child.kill(); return true; });
ipcMain.handle("engines", () => ({ native: true, ...Object.fromEntries(Object.entries(ENGINE_CMD).map(([k, f]) => [k, !!findBinary(f()[0]) && (!f()[1][0]?.endsWith("index.js") || fs.existsSync(f()[1][0])) && (k !== "mcode" || fs.existsSync(cliPath()))])) }));

ipcMain.handle('subscription:login', async (_e, eng) => {
  if (!['codex', 'claude'].includes(eng)) throw new Error('Unsupported subscription agent.');
  const init = await startAgent(eng);
  if (eng === 'codex') {
    const auth = (init.authMethods || []).find((m) => /chat-gpt|chatgpt/i.test(m.id) && !/device/.test(m.id));
    if (!auth) throw new Error('Codex adapter did not advertise ChatGPT sign-in. Update the adapter.');
    await call(eng, 'authenticate', { methodId: auth.id }); return { message: 'ChatGPT sign-in completed through Codex.' };
  }
  const auth = (init.authMethods || []).find((m) => /claude-ai-login|^claude-login$/.test(m.id));
  const terminal = auth?._meta?.['terminal-auth'];
  let args = terminal?.args;
  if (!args) { try { args = [require.resolve('@anthropic-ai/claude-agent-sdk/cli.js'), '/login']; } catch { throw new Error('Claude CLI not found in the installed adapter.'); } }
  const cli = terminal?.command === 'node' ? NODE : terminal?.command || NODE;
  if (process.platform === 'win32') {
    const quote = (x) => "'" + String(x).replace(/'/g, "''") + "'";
    spawn('powershell.exe', ['-NoExit', '-Command', '& ' + [cli, ...args].map(quote).join(' ')], { detached: true, stdio: 'ignore', windowsHide: false }).unref();
  } else {
    const terminalApp = findBinary('x-terminal-emulator'); if (!terminalApp) throw new Error('Run Claude /login in your terminal, then return to Forge.');
    spawn(terminalApp, ['-e', cli, ...args], { detached: true, stdio: 'ignore' }).unref();
  }
  return { message: 'Claude sign-in opened in a terminal. Select your Claude subscription account, then restart the Claude engine.' };
});

// ---------- free-model proxy ----------
const PROXY = path.join(__dirname, "..", "free-proxy", "proxy.mjs");
async function ensureProxy() {
  try { if ((await fetch("http://127.0.0.1:7799/health")).ok) return "online"; } catch {}
  if (!fs.existsSync(PROXY)) return "missing";
  spawn(NODE, [PROXY], { detached: true, stdio: "ignore", windowsHide: true }).unref();
  await new Promise((r) => setTimeout(r, 1500));
  try { return (await fetch("http://127.0.0.1:7799/health")).ok ? "online" : "failed"; } catch { return "failed"; }
}
ipcMain.handle("proxy:ensure", ensureProxy);
// one place that asks the proxy for its model list and turns every failure into a readable error
async function proxyModelList() {
  const st = await ensureProxy();
  if (st !== "online") throw new Error(st === "missing" ? "free-model proxy not found at " + PROXY : "free-model proxy failed to start");
  const r = await fetch("http://127.0.0.1:7799/v1/models", { signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error("free-model proxy answered HTTP " + r.status);
  const j = await r.json();
  return Array.isArray(j.data) ? j.data : [];
}
ipcMain.handle("proxy:models", async () => {
  const j = { data: await proxyModelList() };
  // Kilo + Hermes both register into MiniMax Code via the local proxy. (Zen is reached
  // directly by the OpenCode engine, so it stays out of the mcode-side registration list.)
  return j.data.map((m) => m.id).filter((id) => id.startsWith("kilo/") || id.startsWith("hermes/"));
});
ipcMain.handle("proxy:test", async (_e, model) => {
  const r = await fetch("http://127.0.0.1:7799/v1/chat/completions", { method: "POST", headers: { "content-type": "application/json", "x-no-fallback": "1" },
    body: JSON.stringify({ model, messages: [{ role: "user", content: "Reply with just: ok" }], max_tokens: 20 }) });
  return r.status;
});

// ---------- model catalog + live bench (real gateway data; score is computed locally) ----------
ipcMain.handle("models:catalog", async () => {
  await ensureProxy();
  const j = { data: await proxyModelList() };
  return j.data.map((m) => ({
    id: m.id, name: m.name || m.id, description: m.description || "", created: m.created || 0,
    context: m.context_length || m.top_provider?.context_length || 0,
    maxOut: m.top_provider?.max_completion_tokens || 0,
    input: m.architecture?.input_modalities || [], output: m.architecture?.output_modalities || [],
    params: m.supported_parameters || [], free: !!m.isFree || /free/i.test(m.id),
    trains: !!m.mayTrainOnYourPrompts,
  }));
});
// provider icons: real favicons, fetched once and cached on disk as data URLs
const PROVIDER_DOMAIN = { nvidia: "nvidia.com", qwen: "qwen.ai", poolside: "poolside.ai", cohere: "cohere.com", stepfun: "stepfun.com",
  liquid: "liquid.ai", inclusionai: "inclusionai.github.io", thinkingmachines: "thinkingmachines.ai", "z-ai": "z.ai", minimax: "minimax.io",
  "dots-studio": "rednote.com", "nex-agi": "nex-agi.com", openai: "openai.com", google: "google.com", anthropic: "anthropic.com", moonshotai: "moonshot.ai" };
ipcMain.handle("models:icons", async (_e, providers) => {
  const file = path.join(app.getPath("userData"), "provider-icons.json");
  let cache = readJson(file);
  for (const p of providers || []) {
    const dom = PROVIDER_DOMAIN[p]; if (!dom || cache[p] !== undefined) continue;
    try {
      const r = await fetch(`https://www.google.com/s2/favicons?domain=${dom}&sz=64`, { signal: AbortSignal.timeout(8000) });
      cache[p] = r.ok ? "data:" + (r.headers.get("content-type") || "image/png") + ";base64," + Buffer.from(await r.arrayBuffer()).toString("base64") : null;
    } catch { cache[p] = null; }
  }
  fs.writeFileSync(file, JSON.stringify(cache));
  return cache;
});
ipcMain.handle("models:bench", async (_e, id) => {
  const t0 = Date.now();
  try {
    const r = await fetch("http://127.0.0.1:7799/v1/chat/completions", {
      method: "POST", headers: { "content-type": "application/json", "x-no-fallback": "1" },
      body: JSON.stringify({ model: id, messages: [{ role: "user", content: "Write three short sentences about the ocean." }], max_tokens: 120 }),
      signal: AbortSignal.timeout(60000),
    });
    const ms = Date.now() - t0;
    if (!r.ok) return { ok: false, ms, status: r.status };
    const j = await r.json();
    const toks = j.usage?.completion_tokens || Math.round((j.choices?.[0]?.message?.content || "").length / 4);
    return { ok: true, ms, toks, tps: toks / Math.max(ms / 1000, 0.1) };
  } catch (e) { return { ok: false, ms: Date.now() - t0, status: e.name === "TimeoutError" ? "timeout" : "error" }; }
});

// ---------- one-shot CLI commands (providers, plugins, account, system) ----------
const ALLOWED = new Set(["exec", "provider", "plugin", "login", "logout", "update", "telemetry", "init", "--version", "--help"]);
const runs = new Map();
let runSeq = 1;
ipcMain.handle("cli:run", (_e, args, cwd) => {
  if (!Array.isArray(args) || !args.length || !args.every((a) => typeof a === "string") || !ALLOWED.has(args[0])) throw new Error("command not allowed");
  const id = runSeq++;
  const child = spawn(NODE, [cliPath(), ...args], { cwd: cwd && fs.existsSync(cwd) ? cwd : settings.cwd, shell: false, windowsHide: true, env: { ...CHILD_ENV, NO_COLOR: "1", FORCE_COLOR: "0" } });
  runs.set(id, child);
  const strip = (b) => b.toString().replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "").replace(/^\[\d\d:\d\d:\d\d\.\d+\] (INFO|DEBUG|WARN):.*$/gm, "");
  child.stdout.on("data", (b) => send("cli:data", id, strip(b)));
  child.stderr.on("data", (b) => send("cli:data", id, strip(b)));
  child.stdin.end();
  child.on("error", (e) => send("cli:data", id, `failed to start: ${e.message}\n`));
  child.on("close", (code) => { runs.delete(id); send("cli:exit", id, code); });
  return id;
});
ipcMain.on("cli:stop", (_e, id) => runs.get(id)?.kill());

// ---------- settings, files, dialogs ----------
ipcMain.handle("settings:get", () => ({ ...settings, cliExists: fs.existsSync(cliPath()) }));
ipcMain.handle("settings:set", (_e, s) => {
  settings = { ...settings, ...s };
  fs.mkdirSync(path.dirname(SETTINGS_FILE), { recursive: true });
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  return { ...settings, cliExists: fs.existsSync(cliPath()) };
});
ipcMain.handle("dialog:folder", async () => (await dialog.showOpenDialog(win, { properties: ["openDirectory"] })).filePaths[0] || null);
ipcMain.handle("fs:list", (_e, dir) => {
  try {
    return fs.readdirSync(dir, { withFileTypes: true })
      .filter((d) => !d.name.startsWith(".") && d.name !== "node_modules")
      .map((d) => ({ name: d.name, dir: d.isDirectory(), path: path.join(dir, d.name) }))
      .sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name));
  } catch { return []; }
});
// ---------- GUI Lab: scan reference folders (deduped by content) ----------
const CATALOG_DIR = "D:\\###BM23-TOOLZ-MASTERSUITE-v2.3.0--2026-08-10###\\_SIFT_GUI_CATALOG";
const FORGED_DIR = path.join(CATALOG_DIR, "FORGED");
require('./projects.cjs').register({ app, ipcMain, dialog, BrowserWindow, getWin: () => win, getSettings: () => settings, getForgedRoots: () => {
  if (!fs.existsSync(FORGED_DIR)) return [];
  return walkHtml(FORGED_DIR).slice(0, 250);
} });
function labFolders() { return [...new Set([CATALOG_DIR, ...(settings.labFolders || [])])].filter((d) => fs.existsSync(d)); }
function walkHtml(dir, out = [], depth = 0) {
  if (depth > 6) return out;
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) { if (d.name !== "node_modules" && !d.name.startsWith(".")) walkHtml(p, out, depth + 1); }
    else if (/\.html?$/i.test(d.name) && !/^_INDEX/i.test(d.name)) out.push(p);
  }
  return out;
}
const { pathToFileURL } = require("node:url");
function scanLab() {
  const crypto = require("node:crypto");
  const seen = new Map(), items = [];
  let dupes = 0;
  for (const root of labFolders()) {
    for (const f of walkHtml(root)) {
      let buf; try { buf = fs.readFileSync(f); } catch { continue; }
      const hash = crypto.createHash("md5").update(buf).digest("hex");
      if (seen.has(hash)) { dupes++; continue; }
      seen.set(hash, f);
      const base = path.basename(f).replace(/\.html?$/i, "");
      const win = (base.match(/_(checker|mailbox)(_|$)/i) || [])[1]?.toLowerCase() || "";
      const rel = f.startsWith(FORGED_DIR) ? path.relative(FORGED_DIR, f).split(path.sep) : null;
      const fam = rel ? (rel.length > 1 ? "FORGED-" + rel[0] : "FORGED") : base.split("_")[0].toUpperCase();
      const name = base.replace(/^[A-Za-z0-9-]+_/, "").replace(/(checker|mailbox)_/i, "").replace(/_+/g, " ").trim() || base;
      items.push({ n: name, c: fam, w: win, k: Math.round(buf.length / 1024), abs: pathToFileURL(f).href, fsPath: f });
    }
  }
  return { items, dupes, folders: labFolders() };
}
ipcMain.handle("lab:scan", () => scanLab());
ipcMain.handle("lab:buildPage", () => {
  const { items, dupes, folders } = scanLab();
  const tpl = fs.readFileSync(path.join(__dirname, "renderer", "lab", "template.html"), "utf8");
  const html = tpl.replace("/*CATALOG*/[]", JSON.stringify(items))
    .replace("/*DUPES*/0", String(dupes))
    .replace("/*FOLDERS*/[]", JSON.stringify(folders));
  fs.writeFileSync(path.join(__dirname, "renderer", "lab", "gui-lab.html"), html);
  return { count: items.length, dupes, folders };
});
ipcMain.handle("lab:addFolder", async () => {
  const dir = (await dialog.showOpenDialog(win, { title: "Import a folder of GUI designs", properties: ["openDirectory"] })).filePaths[0];
  if (!dir) return null;
  settings.labFolders = [...new Set([...(settings.labFolders || []), dir])];
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  return dir;
});
ipcMain.handle("lab:removeFolder", (_e, dir) => {
  settings.labFolders = (settings.labFolders || []).filter((d) => d !== dir);
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  return true;
});
const safeGroup = (g) => String(g || "").replace(/[^A-Za-z0-9 _-]+/g, "").trim().replace(/\s+/g, "_").toUpperCase().slice(0, 40);
ipcMain.handle("lab:forgedDir", (_e, group) => {
  const g = safeGroup(group);
  const dir = g ? path.join(FORGED_DIR, g) : FORGED_DIR;
  fs.mkdirSync(dir, { recursive: true });
  return dir;
});
ipcMain.handle("lab:groups", () => {
  fs.mkdirSync(FORGED_DIR, { recursive: true });
  return fs.readdirSync(FORGED_DIR, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name).sort();
});
// ---------- uploads: ANY file type ----------
// mcode's ACP (P0) only accepts `text` + `resource_link` prompt blocks (inline bytes throw), so a file is
// handed over by path and the agent opens it with its own tools. We add a manifest so it knows what it got.
const KIND = {};
for (const [k, exts] of Object.entries({
  code: "py pyw js mjs cjs ts tsx jsx java kt kts c h cpp hpp cc cs go rs rb php swift lua sh bat cmd ps1 sql r dart scala vue svelte gradle",
  web: "html htm css scss sass less xml xhtml svg",
  data: "json jsonc yaml yml toml ini cfg conf env csv tsv log txt md rst lock properties ndjson",
  archive: "zip rar 7z tar gz tgz bz2 tbz2 xz txz zst cab iso jar apk aab war whl xpi vsix lz lzma z",
  image: "png jpg jpeg gif webp bmp ico tiff avif heic psd",
  doc: "pdf doc docx xls xlsx ppt pptx odt ods odp rtf epub",
  media: "mp3 wav ogg flac m4a mp4 mkv mov avi webm lottie",
  binary: "exe dll so bin dat db sqlite apk ttf otf woff woff2 wasm",
})) for (const e of exts.split(" ")) KIND[e] ??= k;
const ZIP_LIKE = new Set(["zip", "jar", "apk", "aab", "war", "whl", "xpi", "vsix"]);
let extractors;
function findExtractors() {
  if (extractors) return extractors;
  const pf = [process.env.ProgramFiles, process.env["ProgramFiles(x86)"]].filter(Boolean);
  const first = (l) => l.find((f) => fs.existsSync(f)) || null;
  const where = (n) => { try { return execFileSync("where", [n], { encoding: "utf8" }).split(/\r?\n/).find(Boolean)?.trim() || null; } catch { return null; } };
  extractors = {
    sevenZip: first(pf.map((p) => path.join(p, "7-Zip", "7z.exe"))) || where("7z"),
    winrar: first(pf.flatMap((p) => [path.join(p, "WinRAR", "UnRAR.exe"), path.join(p, "WinRAR", "WinRAR.exe")])) || where("unrar"),
    // only the Windows-bundled bsdtar (libarchive) is a real fallback; a GNU tar from Git can't read rar/7z
    tar: first([path.join(process.env.SystemRoot || "C:\\Windows", "System32", "tar.exe")]),
  };
  return extractors;
}
function zipList(file) {
  const fd = fs.openSync(file, "r");
  try {
    const size = fs.fstatSync(fd).size, tailLen = Math.min(size, 65557), tail = Buffer.alloc(tailLen);
    fs.readSync(fd, tail, 0, tailLen, size - tailLen);
    let e = -1;
    for (let i = tailLen - 22; i >= 0; i--) if (tail.readUInt32LE(i) === 0x06054b50) { e = i; break; }
    if (e < 0) return null;
    const total = tail.readUInt16LE(e + 10), cdSize = tail.readUInt32LE(e + 12), cdOff = tail.readUInt32LE(e + 16);
    if (total === 0xffff || cdSize === 0xffffffff || cdOff === 0xffffffff) return { names: [], total: -1, note: "zip64 archive — entry list unavailable" };
    if (cdSize > 8 * 1024 * 1024) return { names: [], total, note: "directory too large to list" };
    const cd = Buffer.alloc(cdSize); fs.readSync(fd, cd, 0, cdSize, cdOff);
    const names = []; let p = 0;
    while (p + 46 <= cd.length && cd.readUInt32LE(p) === 0x02014b50) {
      const nl = cd.readUInt16LE(p + 28), el = cd.readUInt16LE(p + 30), cl = cd.readUInt16LE(p + 32);
      if (names.length < 200) names.push(cd.toString("utf8", p + 46, p + 46 + nl));
      p += 46 + nl + el + cl;
    }
    return { names, total };
  } finally { fs.closeSync(fd); }
}
function describeFile(p) {
  const st = fs.statSync(p);
  const name = path.basename(p), uri = pathToFileURL(p).href;
  if (st.isDirectory()) return { path: p, name, dir: true, size: 0, uri, kind: "folder", ext: "" };
  const ext = path.extname(p).slice(1).toLowerCase();
  const d = { path: p, name, ext, size: st.size, uri, kind: KIND[ext] || "other" };
  if (d.kind === "archive" || ext === "lottie") {
    const ex = findExtractors();
    if (ZIP_LIKE.has(ext) || ext === "lottie") {
      try { d.archive = { type: ext, ...(zipList(p) || { names: [], total: -1, note: "could not read zip directory (corrupt or multi-part?)" }) }; }
      catch (e) { d.archive = { type: ext, names: [], total: -1, note: "unreadable: " + e.message }; }
    } else {
      const tool = /^(rar)$/.test(ext) ? (ex.winrar || ex.sevenZip || ex.tar) : (ex.sevenZip || ex.tar);
      d.archive = { type: ext, names: [], total: -1, extractor: tool,
        note: tool ? "extract with: " + tool : "NO extractor found on this PC — install 7-Zip so the agent can open this" };
    }
  }
  return d;
}
const describeMany = (paths) => (paths || []).map((p) => { try { return describeFile(String(p)); } catch (e) { return { path: String(p), name: path.basename(String(p)), ext: "", size: 0, kind: "error", error: e.message }; } });
ipcMain.handle("upload:pick", async () => {
  const r = await dialog.showOpenDialog(win, { title: "Attach files", properties: ["openFile", "multiSelections"], filters: [
    { name: "All files", extensions: ["*"] },
    { name: "Code", extensions: Object.keys(KIND).filter((k) => KIND[k] === "code") },
    { name: "Web & data", extensions: Object.keys(KIND).filter((k) => KIND[k] === "web" || KIND[k] === "data") },
    { name: "Archives", extensions: Object.keys(KIND).filter((k) => KIND[k] === "archive") },
    { name: "Images & docs", extensions: Object.keys(KIND).filter((k) => KIND[k] === "image" || KIND[k] === "doc") },
  ] });
  return r.canceled ? [] : describeMany(r.filePaths);
});
ipcMain.handle("upload:pickFolder", async () => {
  const r = await dialog.showOpenDialog(win, { title: "Attach a folder", properties: ["openDirectory", "multiSelections"] });
  return r.canceled ? [] : describeMany(r.filePaths);
});
ipcMain.handle("upload:describe", (_e, paths) => describeMany(paths));
ipcMain.handle("upload:saveBlob", (_e, name, bytes) => {
  const dir = path.join(app.getPath("userData"), "uploads");
  fs.mkdirSync(dir, { recursive: true });
  const safe = String(name || "pasted").replace(/[^A-Za-z0-9._-]+/g, "_").slice(-80) || "pasted";
  const file = path.join(dir, `${Date.now()}-${safe}`);
  fs.writeFileSync(file, Buffer.from(bytes));
  return describeFile(file);
});
require("./local-models.cjs")({
  app, dialog, ipcMain, getWin: () => win, send, getSettings: () => settings, getHfToken: () => integration.getSecret("huggingface"),
  runMcode: (args) => new Promise((res) => {
    const c = spawn(NODE, [cliPath(), ...args], { cwd: settings.cwd, shell: false, windowsHide: true, env: { ...CHILD_ENV, NO_COLOR: "1" } });
    let out = ""; c.stdout.on("data", (b) => (out += b)); c.stderr.on("data", (b) => (out += b)); c.stdin.end();
    c.on("close", (code) => res({ code, out: out.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "").slice(-2000) }));
  }),
  restartMcode: () => agents.get("mcode")?.child.kill(),
  saveSettings: (s) => { settings = { ...settings, ...s }; fs.mkdirSync(path.dirname(SETTINGS_FILE), { recursive: true }); fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2)); },
});
// ---------- Plugin Bay: plugins / MCP / connections, straight from mcode's own CLI ----------
// mcode prints its JSON first and may append log lines afterwards, so take the first balanced JSON object.
function extractJson(t) {
  const i = t.indexOf("{"); if (i < 0) throw new Error("no JSON in mcode output");
  let depth = 0, str = false, esc = false;
  for (let k = i; k < t.length; k++) {
    const c = t[k];
    if (str) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === '"') str = false; continue; }
    if (c === '"') str = true; else if (c === "{") depth++; else if (c === "}" && --depth === 0) return JSON.parse(t.slice(i, k + 1));
  }
  throw new Error("truncated JSON in mcode output");
}
function mcodeRun(args, timeoutMs = 120000) {
  return new Promise((resolve) => {
    const c = spawn(NODE, [cliPath(), ...args], { cwd: settings.cwd, shell: false, windowsHide: true, env: { ...CHILD_ENV, NO_COLOR: "1", FORCE_COLOR: "0" } });
    let out = "", err = "";
    const timer = setTimeout(() => c.kill(), timeoutMs);
    c.stdout.on("data", (b) => (out += b)); c.stderr.on("data", (b) => (err += b)); c.stdin.end();
    c.on("error", (e) => { clearTimeout(timer); resolve({ code: -1, out, err: e.message }); });
    c.on("close", (code) => { clearTimeout(timer); resolve({ code, out, err }); });
  });
}
async function mcodeJson(args) { const r = await mcodeRun(args); return extractJson(r.out); }
const PLUGIN_ID = /^[\w.-]+(@[\w.-]+)?$/;
ipcMain.handle("bay:plugins", () => mcodeJson(["plugin", "list", "--json", "--available"]));
ipcMain.handle("bay:providers", () => mcodeJson(["provider", "list", "--json"]));
ipcMain.handle("bay:pluginAction", async (_e, action, id) => {
  if (!["add", "remove", "enable", "disable"].includes(action) || !PLUGIN_ID.test(String(id))) throw new Error("bad plugin action");
  const r = await mcodeRun(["plugin", action, id, "--json"]);
  if (r.code !== 0) throw new Error(`plugin ${action} failed: ` + (r.err || r.out).replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "").trim().split("\n").slice(-2).join(" | "));
  agents.get("mcode")?.child.kill(); // sessions pick up the change on the next action
  return true;
});
ipcMain.handle("bay:providerTest", async (_e, id) => {
  if (!/^[\w:.-]+$/.test(String(id))) throw new Error("bad provider id");
  const r = await mcodeRun(["provider", "test", id, "--json"], 90000);
  try { return extractJson(r.out); } catch { return { ok: r.code === 0, output: (r.out + r.err).replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "").slice(-400) }; }
});
ipcMain.on("edit", (_e, cmd) => { const wc = win?.webContents; if (wc && ["cut", "copy", "paste", "selectAll", "undo", "redo"].includes(cmd)) wc[cmd](); });
ipcMain.handle("shell:open", (_e, p) => shell.openPath(String(p)));
ipcMain.handle("clipboard", (_e, text) => require("electron").clipboard.writeText(String(text)));
ipcMain.handle("notify", (_e, title, body) => { if (Notification.isSupported() && win && !win.isDestroyed() && !win.isFocused()) new Notification({ title, body }).show(); });

// each forged app gets its own slim browser window (never the user's Chrome/Brave)
ipcMain.handle("win:open", (_e, file) => {
  if (typeof file !== "string" || !fs.existsSync(file)) throw new Error("file not found");
  const w = new BrowserWindow({ width: 1500, height: 920, backgroundColor: "#000000", autoHideMenuBar: true, title: path.basename(file),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
  w.webContents.on("will-navigate", (ev, url) => { if (!/^file:/i.test(url)) ev.preventDefault(); });
  w.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  w.loadFile(file);
  return true;
});
ipcMain.handle("capture:window", async () => {
  const dir = path.join(app.getPath("userData"), "annotations");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `annotation-${Date.now()}.png`);
  fs.writeFileSync(file, (await win.capturePage()).toPNG());
  return file;
});
// KILL SERVER: stop every agent, CLI run and the free-model proxy
ipcMain.handle("kill:all", async () => {
  let n = 0; monitor.stop('All owned work stopped'); runtime.stop(); integration.stop();
  for (const a of agents.values()) { a.child.kill(); n++; }
  for (const c of runs.values()) { c.kill(); n++; }
  try { await fetch("http://127.0.0.1:7799/shutdown", { method: "POST", headers: { "x-kill": "1" } }); n++; } catch {}
  return n;
});
app.on("web-contents-created", (_e, contents) => {
  contents.on("will-attach-webview", (ev, prefs, params) => {
    delete prefs.preload;
    prefs.nodeIntegration = false; prefs.contextIsolation = true; prefs.sandbox = true;
    const projectPreview = params.partition === 'persist:forge-project-preview';
    if (!(projectPreview ? /^(https?:|file:|about:blank)/i : /^(file:|about:blank)/i).test(params.src || "")) ev.preventDefault();
  });
});
app.whenReady().then(() => {
  ensureProxy();
  const { session } = require('electron');
  const projectPreviewSession = session.fromPartition('persist:forge-project-preview');
  projectPreviewSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  projectPreviewSession.setPermissionCheckHandler(() => false);
  const rendererUrl = require('node:url').pathToFileURL(path.join(__dirname, 'renderer', 'index.html')).href;
  session.defaultSession.setPermissionRequestHandler((contents, permission, callback, details) => callback(contents === win?.webContents && contents.getURL() === rendererUrl && permission === 'media' && !(details.mediaTypes || []).includes('video')));
  session.defaultSession.setPermissionCheckHandler((contents, permission) => contents === win?.webContents && contents.getURL() === rendererUrl && permission === 'media');
  win = new BrowserWindow({
    width: 1600, height: 960, minWidth: 1100, minHeight: 680, backgroundColor: "#04060c", title: "BM23-TOOLZ · Coder IDE",
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, "preload.cjs"), contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: true },
  });
  win.loadFile(path.join(__dirname, "renderer", "index.html"));
  const snap = process.env.MCODE_GUI_SNAP;
  if (snap) {
    win.webContents.on("console-message", (e) => console.log("[renderer]", e.level, e.message));
    win.webContents.on("did-finish-load", async () => {
      if (process.env.MCODE_GUI_JS) await win.webContents.executeJavaScript(process.env.MCODE_GUI_JS).catch((err) => console.log("[js error]", err.message));
      setTimeout(async () => { fs.writeFileSync(snap, (await win.capturePage()).toPNG()); console.log("[snap] saved", snap); app.quit(); }, Number(process.env.MCODE_GUI_WAIT || 9000));
    });
  }
});
app.on("window-all-closed", () => { integration.stop(); for (const a of agents.values()) a.child.kill(); for (const c of runs.values()) c.kill(); app.quit(); });
