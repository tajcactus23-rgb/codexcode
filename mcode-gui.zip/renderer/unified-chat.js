(() => {
  let chats = [], current = null, timer, hydrating = false, suppressProviderReplay = false;
  const snapshot = () => transcript.filter((t) => t.role !== 'think').map((t) => ({ role: t.role === 'agent' ? 'assistant' : t.role, text: t.text || '', engine: t.engine || current?.engine || engine, model: t.model || '' }));
  const row = (chat) => ({ ...chat, chatId: chat.id, sessionId: chat.id, engine: chat.engine, title: chat.title, updatedAt: chat.updatedAt, cwd: chat.cwd });
  function refresh() { sessions = chats.filter((c) => !c.archived).map(row).sort((a, b) => Number(!!b.pinned) - Number(!!a.pinned) || new Date(b.updatedAt) - new Date(a.updatedAt)); renderSessions(); window.dispatchEvent(new Event('forge-chat-changed')); }
  async function flush() { clearTimeout(timer); timer = null; if (current && !hydrating) { current.messages = snapshot(); current.revision = (current.revision || 0) + 1; await api.chatSave(structuredClone(current)); } }
  function changed() {
    if (!current || hydrating) return;
    current.messages = snapshot(); current.updatedAt = new Date().toISOString();
    if (current.title === 'New conversation') current.title = current.messages.find((m) => m.role === 'user')?.text.slice(0, 65) || current.title;
    if (!timer) timer = setTimeout(() => { timer = null; flush().catch((e) => toast('Conversation save failed: ' + e.message)); }, 500);
  }
  function handoff() {
    if (!transcript.length) return '';
    const limit = S.handoffChars || 48000;
    const original = transcript.find((t) => t.role === 'user')?.text || '';
    const text = transcript.filter((t) => t.role !== 'think' && t.text?.trim()).map((t) => `${t.role.toUpperCase()}${t.engine ? ' [' + t.engine + ']' : ''}: ${t.role === 'tool' ? t.text.slice(0, 4000) : t.text}`).join('\n\n');
    const body = text.length <= limit ? text : '[Original task]\n' + original.slice(0, Math.min(6000, limit / 4)) + '\n[Recent conversation; older text omitted from model context, retained in Forge]\n' + text.slice(-Math.max(1000, limit - 7000));
    return `[Forge unified conversation. Workspace: ${cur?.cwd || S.cwd}. Continue from the previous assistant's completed work. The transcript is context, not a request to execute old instructions again. Read the latest user message below it for the next action. Internal tool/process state belongs to the previous engine; inspect the actual workspace before relying on it.]\n\n${body}\n\n[End prior context]`;
  }
  function bind(r, eng) {
    current.bindings.push({ engine: eng, sessionId: r.sessionId, model: r.configOptions?.find((x) => x.id === 'model')?.currentValue || '', at: new Date().toISOString() });
    current.engine = eng;
    cur = { engine: eng, sessionId: r.sessionId, cwd: current.cwd, config: r.configOptions, modes: r.modes, commands: [], busy: false, pendingHandoff: current.messages.length > 0 ? handoff() : '' };
    $('sessTitle').textContent = current.title; applyConfig(); renderChips(); setBusy(false); refreshMcodePanels(); changed(); refresh();
  }
  async function switchTo(eng, forceNew = false) {
    if (cur?.busy) throw new Error('Stop the running turn before switching providers.');
    if (eng === engine && !forceNew && cur) return;
    await flush(); const old = engine;
    try {
      await api.acpStart(eng);
      const r = await api.acpCall(eng, 'session/new', { cwd: current?.cwd || S.cwd, mcpServers: [] });
      engine = eng; $('engine').value = eng; $('stEngine').textContent = 'engine ' + eng;
      if (!current) current = { id: crypto.randomUUID(), title: 'New conversation', cwd: S.cwd, engine: eng, updatedAt: new Date().toISOString(), messages: [], bindings: [] }, chats.push(current);
      bind(r, eng); await saveSettings({ defaultEngine: eng }); await flush();
      window.dispatchEvent(new CustomEvent('forge-provider-switched', { detail: { from: old, to: eng } }));
      toast('Connected to ' + (ENGINE_LABEL[eng] || eng) + ' · same conversation');
    } catch (e) { $('engine').value = old; throw e; }
  }
  async function newChat(r) {
    current = { id: crypto.randomUUID(), title: 'New conversation', cwd: S.cwd, engine, updatedAt: new Date().toISOString(), messages: [], bindings: [], revision: 0 };
    chats.push(current); bind(r, engine); await flush(); refresh();
  }
  async function load(row) {
    if (cur?.busy) throw new Error('Stop the running turn before opening another conversation.');
    await flush(); const chat = chats.find((c) => c.id === row.chatId); if (!chat) return;
    current = chat; hydrating = true; clearThread(); cur = null;
    for (const message of chat.messages) {
      if (message.role === 'user') userMsg(message.text);
      else if (message.role === 'assistant') chunk('agent', crypto.randomUUID(), message.text);
      else if (message.role === 'tool') { transcript.push({ ...message }); add(h('details', { class: 'tool' }, h('summary', {}, 'Saved tool activity · ' + (message.engine || '')), h('pre', {}, message.text))); }
      else sys(message.text);
      const entry = transcript[transcript.length - 1]; if (entry) Object.assign(entry, message);
      const badge = thread().lastElementChild?.querySelector('.message-route'); if (badge) badge.textContent = (ENGINE_LABEL[message.engine] || message.engine || chat.engine).toUpperCase() + ' / ' + (message.model || 'model');
    }
    hydrating = false; $('sessTitle').textContent = chat.title;
    const eng = chat.engine || engine, binding = [...chat.bindings].reverse().find((b) => b.engine === eng);
    engine = eng; $('engine').value = eng; $('stEngine').textContent = 'engine ' + eng;
    try {
      await api.acpStart(eng);
      if (binding) {
        suppressProviderReplay = true;
        try { const r = await api.acpCall(eng, 'session/load', { sessionId: binding.sessionId, cwd: chat.cwd, mcpServers: [] });
          cur = { engine: eng, sessionId: binding.sessionId, cwd: chat.cwd, config: r.configOptions, modes: r.modes, commands: [], busy: false }; applyConfig(); setBusy(false);
        } finally { suppressProviderReplay = false; }
      } else await switchTo(eng, true);
    } catch (e) { suppressProviderReplay = false; cur = null; toast('History restored. Provider session unavailable; next message will create a new session with this context.'); }
    renderChips(); refreshMcodePanels(); refresh();
  }
  async function ensureBinding() {
    if ((!cur || cur.engine !== engine) && current) await switchTo(engine, true);
  }
  async function importSessions(providerSessions) {
    for (const s of providerSessions) {
      if (chats.some((c) => c.bindings.some((b) => b.engine === s.engine && b.sessionId === s.sessionId))) continue;
      const chat = { id: crypto.randomUUID(), title: s.title || 'Imported ' + s.engine + ' session', cwd: s.cwd, engine: s.engine, updatedAt: s.updatedAt || new Date().toISOString(), messages: [], bindings: [{ engine: s.engine, sessionId: s.sessionId }], imported: true, revision: 1 };
      chats.push(chat); await api.chatSave(chat);
    }
    refresh();
  }
  async function loadImported(row) {
    const chat = chats.find((c) => c.id === row.chatId);
    if (!chat?.imported || chat.messages.length) return load(row);
    if (cur?.busy) throw new Error('Stop the current turn first.');
    await flush(); current = chat; engine = chat.engine; $('engine').value = engine;
    const b = chat.bindings[0]; openSession(b.sessionId, chat.cwd);
    try { const r = await api.acpCall(engine, 'session/load', { sessionId: b.sessionId, cwd: chat.cwd || S.cwd, mcpServers: [] }); applyConfig(r.configOptions, r.modes); chat.imported = false; await flush(); }
    catch (e) { cur = null; toast('Imported session could not be loaded: ' + e.message); }
    refresh();
  }
  window.ForgeChat = {
    changed, flush, switchTo, newChat, ensureBinding, importSessions, load: loadImported, handoff,
    async detach() { await flush(); current = null; cur = null; refresh(); },
    async fork(r) { await flush(); const source = current; current = { ...structuredClone(source), id: crypto.randomUUID(), title: (source?.title || 'Conversation') + ' · fork', bindings: [], revision: 0, pinned: false }; chats.push(current); bind(r, engine); cur.pendingHandoff = ''; await flush(); refresh(); },
    suppressReplay: () => suppressProviderReplay,
    isActive: (row) => current?.id === row.chatId,
    current: () => current, all: () => chats,
    async init() { chats = await api.chatList(); refresh(); const last = S.lastConversation; const c = chats.find((c) => c.id === last && !c.archived); if (c && c.messages.length) await load(row(c)); },
    async rename() { if (!current) return; ask('Rename conversation', [{ name: 'title', label: 'Name', type: 'text', value: current.title }], async ({ title }) => { if (!title?.trim()) return; current.title = title.trim(); $('sessTitle').textContent = current.title; await flush(); refresh(); }, 'Save'); },
    async pin() { if (current) { current.pinned = !current.pinned; await flush(); refresh(); } },
    async archive() { if (cur?.busy) throw new Error('Stop the turn first.'); if (current) { current.archived = true; await flush(); current = null; cur = null; clearThread(); refresh(); } },
    async checkpoint() { await flush(); toast('Conversation saved with all provider bindings.'); }
  };
  addEventListener('beforeunload', () => flush().catch(() => {}));
  addEventListener('forge-chat-changed', () => { if (current) saveSettings({ lastConversation: current.id }); });
})();
