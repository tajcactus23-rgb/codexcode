// Boids + hunter scene for the right panel. Flock flocks, hunter chases the nearest boid,
// flock scatters away from the hunter and from the mouse. Colours follow the active tab.
export function mountBoids(canvas) {
  const g = canvas.getContext("2d");
  let W = 0, H = 0, dpr = 1;
  const css = () => getComputedStyle(document.documentElement);
  let colA = "#2ad4ff", colB = "#ff3fb4";
  let N = (window.CFG && window.CFG.boidsCount) || 90;
  const boids = Array.from({ length: N }, () => ({ x: Math.random(), y: Math.random(), vx: (Math.random() - 0.5) * 0.002, vy: (Math.random() - 0.5) * 0.002, hue: Math.random() }));
  const trail = [];
  const hunter = { x: 0.5, y: 0.5, vx: 0, vy: 0, target: null, kills: 0, flash: 0 };
  const mouse = { x: -1, y: -1, on: false };
  let energy = 0.3, burst = 0;

  function resize() {
    dpr = Math.min(devicePixelRatio, 2);
    W = canvas.clientWidth; H = canvas.clientHeight;
    canvas.width = W * dpr; canvas.height = H * dpr;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  new ResizeObserver(resize).observe(canvas); resize();
  canvas.parentElement.addEventListener("pointermove", (e) => { const r = canvas.getBoundingClientRect(); mouse.x = (e.clientX - r.left) / r.width; mouse.y = (e.clientY - r.top) / r.height; mouse.on = true; });
  canvas.parentElement.addEventListener("pointerleave", () => (mouse.on = false));

  const lim = (b, m) => { const s = Math.hypot(b.vx, b.vy); if (s > m) { b.vx *= m / s; b.vy *= m / s; } };
  function step() {
    const aspect = W / Math.max(H, 1);
    const maxS = 0.0022 * (1 + energy * 1.6) * ((window.CFG && window.CFG.boidsSpeed) || 1);
    for (const b of boids) {
      let cx = 0, cy = 0, ax = 0, ay = 0, sx = 0, sy = 0, n = 0;
      for (const o of boids) {
        if (o === b) continue;
        const dx = (o.x - b.x) * aspect, dy = o.y - b.y, d = Math.hypot(dx, dy);
        if (d < 0.09) { cx += o.x; cy += o.y; ax += o.vx; ay += o.vy; n++; if (d < 0.025) { sx -= dx; sy -= dy; } }
      }
      if (n) { b.vx += ((cx / n - b.x) * 0.004 + (ax / n - b.vx) * 0.05); b.vy += ((cy / n - b.y) * 0.004 + (ay / n - b.vy) * 0.05); }
      b.vx += sx * 0.012; b.vy += sy * 0.012;
      for (const p of [hunter, mouse.on ? mouse : null]) {
        if (!p) continue;
        const dx = (b.x - p.x) * aspect, dy = b.y - p.y, d = Math.hypot(dx, dy);
        if (d < 0.16) { b.vx += (dx / d) * 0.0009 * (1 + burst); b.vy += (dy / d) * 0.0009 * (1 + burst); }
      }
      lim(b, maxS); b.x = (b.x + b.vx + 1) % 1; b.y = (b.y + b.vy + 1) % 1;
    }
    // hunter picks the nearest boid, chases it, eats on contact (boid respawns at an edge)
    let best = null, bd = 1e9;
    for (const b of boids) { const d = Math.hypot((b.x - hunter.x) * aspect, b.y - hunter.y); if (d < bd) { bd = d; best = b; } }
    if (best) {
      hunter.vx += (best.x - hunter.x) * 0.0022; hunter.vy += (best.y - hunter.y) * 0.0022;
      lim(hunter, maxS * 1.15); hunter.x = (hunter.x + hunter.vx + 1) % 1; hunter.y = (hunter.y + hunter.vy + 1) % 1;
      trail.push([hunter.x, hunter.y]); if (trail.length > 40) trail.shift();
      if (bd < 0.018) { hunter.kills++; hunter.flash = 1; const e = Math.random() < 0.5; best.x = e ? (Math.random() < 0.5 ? 0.02 : 0.98) : Math.random(); best.y = e ? Math.random() : (Math.random() < 0.5 ? 0.02 : 0.98); }
    }
  }
  function draw(t) {
    const s = css();
    const C = window.CFG || {}; colA = (C.boidColors && C.boidColors[0]) || s.getPropertyValue("--tab").trim() || colA; colB = (C.boidColors && C.boidColors[1]) || s.getPropertyValue("--tab2").trim() || colB;
    g.fillStyle = "rgba(3,6,14,0.28)"; g.fillRect(0, 0, W, H);
    // faint moving grid
    g.strokeStyle = colA + "14"; g.lineWidth = 1;
    const off = (t * 0.01) % 24;
    for (let x = -24 + off; x < W; x += 24) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
    for (const b of boids) {
      const a = Math.atan2(b.vy, b.vx), x = b.x * W, y = b.y * H;
      g.save(); g.translate(x, y); g.rotate(a);
      const C2 = window.CFG || {}; const cols3 = [colA, colB, (C2.boidColors && C2.boidColors[2]) || "#e8f6ff"]; g.fillStyle = cols3[Math.floor(b.hue * 3) % 3];
      g.beginPath(); g.moveTo(6, 0); g.lineTo(-4, 3); g.lineTo(-2, 0); g.lineTo(-4, -3); g.closePath(); g.fill();
      g.restore();
    }
    g.strokeStyle = colB; g.lineWidth = 2;
    for (let i = 1; i < trail.length; i++) { const [ax, ay] = trail[i - 1], [bx, by] = trail[i]; if (Math.abs(ax - bx) > 0.5 || Math.abs(ay - by) > 0.5) continue; g.globalAlpha = i / trail.length; g.beginPath(); g.moveTo(ax * W, ay * H); g.lineTo(bx * W, by * H); g.stroke(); }
    g.globalAlpha = 1;
    const hx = hunter.x * W, hy = hunter.y * H, ha = Math.atan2(hunter.vy, hunter.vx);
    g.save(); g.translate(hx, hy); g.rotate(ha);
    g.fillStyle = (window.CFG && window.CFG.hunterColor) || "#ffffff"; g.strokeStyle = colB; g.lineWidth = 2;
    g.beginPath(); g.moveTo(18, 0); g.lineTo(-10, 10); g.lineTo(-4, 0); g.lineTo(-10, -10); g.closePath(); g.fill(); g.stroke();
    g.restore();
    if (hunter.flash > 0.02) { g.strokeStyle = colB; g.globalAlpha = hunter.flash; g.lineWidth = 2; g.beginPath(); g.arc(hx, hy, 30 * (1.2 - hunter.flash), 0, 6.283); g.stroke(); g.globalAlpha = 1; hunter.flash *= 0.9; }
    g.font = "10px Consolas,monospace"; g.fillStyle = colA; g.fillText(`FLOCK ${N} · HUNTER KILLS ${hunter.kills}`, 10, H - 10);
  }
  function loop(t) { if (window.__bayOpen || document.hidden || document.body.classList.contains("onpage")) return requestAnimationFrame(loop); const on = !window.CFG || window.CFG.boidsOn !== false; canvas.style.opacity = on ? (canvas.id === 'boidsLeft' ? 0.65 : 0.25) : 0; energy += (0.3 - energy) * 0.01; burst *= 0.95; if (on) { step(); draw(t); } requestAnimationFrame(loop); }
  requestAnimationFrame(loop);
  return { pulse(a = 1) { burst = Math.min(3, burst + a); energy = Math.min(1.5, energy + 0.3 * a); }, busy(on) { energy = on ? 1.2 : 0.3; } };
}
