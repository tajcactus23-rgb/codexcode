(() => {
  const journal = []; let installed = {}, frames = 0, lastMeasure = performance.now(), fps = 0;
  const command = (title, fn) => h('button', { onclick: () => Promise.resolve(fn()).catch((e) => toast(e.message)) }, title);
  function log(text, state = 'info') {
    journal.unshift({ text, state, time: new Date().toLocaleTimeString() }); journal.length = Math.min(journal.length, 80);
    $('activityFeed')?.replaceChildren(...journal.slice(0, 12).map((e) => h('div', { class: 'activity-item ' + e.state }, h('time', {}, e.time), h('span', {}, e.text))));
  }
  function overview() {
    $('p-control').replaceChildren(
      h('div', { class: 'control-heading' }, h('span', {}, 'OPERATIONS DECK'), h('i', { class: 'signal-dot' })),
      h('div', { class: 'instrument' }, h('div', { class: 'instrument-orbit' }), h('span', { id: 'coreState' }, cur?.busy ? 'EXECUTING' : 'STANDING BY'), h('small', {}, 'REACTIVE CORE / FORGE')),
      h('div', { class: 'instrument-data' }, h('div', {}, h('small', {}, 'ENGINE'), h('b', { id: 'deckEngine' }, ENGINE_LABEL[engine] || engine)), h('div', {}, h('small', {}, 'HISTORY'), h('b', {}, 'UNIFIED'))),
      h('div', { class: 'deck-section' }, 'ENGINE INVENTORY'),
      h('div', { class: 'engine-inventory' }, ...['codex', 'claude', 'hermes', 'mcode', 'opencode', 'kilo', 'native'].map((key) => h('button', { class: 'engine-tile' + (key === engine ? ' active' : ''), onclick: () => window.ForgeChat.switchTo(key).catch((e) => toast(e.message)) }, h('span', { class: 'led ' + (installed[key] ? 'ok' : '') }), h('span', {}, ENGINE_LABEL[key] || key), h('small', {}, key === 'native' ? 'ENDPOINT' : installed[key] ? 'FOUND' : 'NOT FOUND')))),
      h('div', { class: 'deck-section' }, 'CONVERSATION CONTROL'),
      h('div', { class: 'deck-actions' }, command('⌖ Pin / unpin', () => window.ForgeChat.pin()), command('✎ Rename', () => window.ForgeChat.rename()), command('⤓ Save history', () => window.ForgeChat.checkpoint()), command('▣ Archive', () => window.ForgeChat.archive())),
      h('div', { class: 'deck-section' }, 'LIVE ACTIVITY'), h('div', { id: 'activityFeed', class: 'activity-feed' }),
      h('div', { class: 'deck-note' }, 'One Forge conversation. Provider sessions attach underneath it. Switching preserves the visible transcript and stages context for your next message.'));
    if (journal.length) { const e = journal.shift(); log(e.text, e.state); }
  }
  const OPS = [
    ['AUDIT', 'AUDIT THE CODEBASE', 'Find the weak points.', 'Inspect this workspace thoroughly. Map the architecture, identify concrete bugs, dead code, fragile dependencies and unfinished work. Prioritize findings with exact file paths and a practical fix plan.'],
    ['DEBUG', 'TRACE THE CURRENT FAILURE', 'Follow the evidence.', 'Inspect the current errors and logs, trace the failing path to its root cause, implement a focused fix and run the relevant validation.'],
    ['BUILD', 'FINISH THE NEXT FEATURE', 'Close the open loop.', 'Inspect the current project, find the highest-impact unfinished feature, finish its actual behavior and verify it through the real user flow.'],
    ['DESIGN', 'PUSH THE VISUALS', 'Make this screen alive.', 'Inspect the active UI and preserve its identity. Improve its hierarchy, motion, interaction and complete loading, empty, failure and responsive states. Keep all actions functional.'],
    ['DESIGN', 'TUNE THE ANIMATION ENGINE', 'Motion with control.', 'Profile the animation system. Improve state reactivity, frame pacing, interaction and adjustable quality without changing the established visual identity.'],
    ['REFACTOR', 'REFACTOR THE HOTSPOT', 'Keep behavior intact.', 'Find the most tangled module in this project, split responsibilities cleanly, remove duplication and verify that its existing behavior still works.'],
    ['TEST', 'TRACE FAILING TESTS', 'Reproduce. Fix. Verify.', 'Run the relevant test suite, reproduce each failure, trace its cause and implement fixes. Keep the tests meaningful and report the actual results.'],
    ['PERFORMANCE', 'OPTIMIZE THE HOT PATH', 'Measure before changing.', 'Find the slowest user-facing path, measure the cause, improve its implementation and verify the change with a relevant benchmark or trace.'],
    ['ARCHITECTURE', 'MAP THE SYSTEM', 'Read the whole circuit.', 'Inspect the workspace and map the entry points, modules, routes, services, state and dependencies. Explain the actual data flow with file references.'],
    ['SECURITY', 'HARDEN THE BOUNDARIES', 'Make failure predictable.', 'Audit the actual trust boundaries, secret handling, validation, authentication and destructive operations. Fix confirmed issues and verify the affected paths.'],
    ['BUILD', 'WIRE THE DISCONNECTED PARTS', 'Turn the UI into behavior.', 'Locate visible controls that lack working backend or runtime behavior. Wire the most important disconnected path end to end and verify it with real data.'],
    ['DESIGN', 'BREAK THE RESPONSIVE LAYOUT', 'Find the awkward states.', 'Inspect the UI at laptop, 1080p, 1440p, ultrawide and 4K sizes. Fix clipping, overflow, poor panel sizing and unusable controls.'],
    ['REPOSITORY', 'REVIEW THE CHANGESET', 'Check what actually changed.', 'Review the current Git changes for behavior regressions, incomplete features, unnecessary changes and missing validation. Fix concrete issues.'],
    ['BUILD', 'COMPLETE THE SETTINGS', 'Expose meaningful controls.', 'Inspect settings and the systems they configure. Connect missing meaningful controls, enforce sensible ranges and verify persistence and application of changes.'],
    ['ARCHITECTURE', 'TRACE DATA FLOW', 'UI to runtime and back.', 'Trace the active feature from UI event through services, runtime and persistence to its response. Find mismatches and fix confirmed gaps.'],
    ['DESIGN', 'POLISH THE COMPONENT', 'A complete interaction.', 'Inspect the selected/current component and improve its spacing, typography, motion, focus behavior and complete interaction states while preserving functionality.']
  ];
  let recent = [], category = 'ALL', hover = false, cycle;
  function home() {
    if (transcript.length || cur?.busy || $('forgeHome')) return;
    $('welcome')?.remove();
    const ops = h('div', { class: 'ops-grid', id: 'opsGrid' });
    $('thread').append(h('div', { id: 'forgeHome' },
      h('div', { class: 'home-eyebrow' }, h('span', { class: 'signal-dot' }), 'FORGE / COGNITIVE CONTROL CENTRE'),
      h('div', { class: 'home-copy' }, h('h1', {}, 'YOUR CODE.', h('br'), h('em', {}, 'UNDER CONTROL.')), h('p', {}, 'One workspace. Every engine. A continuous conversation.')),
      h('div', { class: 'home-tags' }, h('span', {}, 'HERMES / ACP'), h('span', {}, 'LOCAL INFERENCE'), h('span', {}, 'GUI FORGE')),
      h('div', { class: 'ops-heading' }, h('span', {}, 'FORGE OPS'), h('small', {}, 'CHOOSE THE NEXT MOVE'), command('↻ REGENERATE', regenerate)),
      h('div', { class: 'ops-filters' }, ...['ALL', 'BUILD', 'DEBUG', 'DESIGN', 'AUDIT', 'ARCHITECTURE'].map((key) => h('button', { class: key === category ? 'on' : '', onclick: (e) => { category = key; document.querySelectorAll('.ops-filters button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); regenerate(); } }, key))), ops));
    $('forgeHome').onpointerenter = () => { hover = true; }; $('forgeHome').onpointerleave = () => { hover = false; };
    regenerate();
  }
  function regenerate() {
    const grid = $('opsGrid'); if (!grid) return;
    let pool = OPS.filter((o) => category === 'ALL' || o[0] === category);
    const fresh = pool.filter((o) => !recent.includes(o[1])); if (fresh.length >= 4) pool = fresh;
    pool = pool.map((o) => ({ o, n: Math.random() + (document.querySelector('.errmsg') && o[0] === 'DEBUG' ? 1 : 0) })).sort((a, b) => b.n - a.n).slice(0, 4).map((x) => x.o);
    recent = [...recent.slice(-8), ...pool.map((o) => o[1])];
    grid.replaceChildren(...pool.map(([tag, title, sub, prompt], i) => h('button', { class: 'op-card', style: '--delay:' + i * 40 + 'ms', onclick: () => { $('prompt').value = prompt; $('prompt').focus(); window.FORM?.pulse(0.5); } }, h('div', { class: 'op-top' }, h('span', {}, tag), h('b', {}, '↗')), h('strong', {}, title), h('small', {}, sub))));
    window.FORM?.pulse(0.35);
  }
  function resizeRails() {
    for (const side of ['l', 'r']) {
      const rail = $(side + 'Tog'); rail.textContent = ''; rail.title = 'Drag to resize · click to collapse · double-click reset · arrows to resize';
      rail.append(h('span', { class: 'rail-chevrons' }, '‹ ›'), h('span', { class: 'rail-label' }, side === 'l' ? 'HISTORY' : 'CONTROL'), h('span', { class: 'rail-grip' }, '⠿'));
      rail.setAttribute('role', 'separator'); rail.setAttribute('aria-orientation', 'vertical'); rail.setAttribute('aria-label', side === 'l' ? 'History panel' : 'Control panel'); rail.tabIndex = 0;
      const defaults = side === 'l' ? 278 : 332; let dragging = false, moved = false, startX, startWidth;
      const size = () => document.getElementById(side === 'l' ? 'left' : 'right').getBoundingClientRect().width;
      const apply = (width) => { const val = Math.round(Math.max(180, Math.min(innerWidth * 0.33, width))); document.documentElement.style.setProperty('--' + side + '-width', val + 'px'); rail.setAttribute('aria-valuenow', String(val)); localStorage.setItem('forge-' + side + '-width', String(val)); };
      apply(Number(localStorage.getItem('forge-' + side + '-width')) || defaults);
      rail.onclick = () => { if (!moved) setSide(side, !document.body.classList.contains(side + 'col')); moved = false; decorate(); };
      const decorate = () => { if (!rail.querySelector('.rail-label')) rail.replaceChildren(h('span', { class: 'rail-chevrons' }, '‹ ›'), h('span', { class: 'rail-label' }, side === 'l' ? 'HISTORY' : 'CONTROL'), h('span', { class: 'rail-grip' }, '⠿')); };
      rail.onpointerdown = (e) => { if (e.button !== 0) return; startX = e.clientX; startWidth = size() || defaults; dragging = true; moved = false; rail.setPointerCapture(e.pointerId); };
      rail.onpointermove = (e) => { if (!dragging) return; const dx = e.clientX - startX; if (Math.abs(dx) < 4 && !moved) return; moved = true; document.body.classList.add('resizing'); document.body.classList.remove(side + 'col'); apply(startWidth + (side === 'l' ? dx : -dx)); };
      rail.onpointerup = () => { dragging = false; document.body.classList.remove('resizing'); }; rail.onpointercancel = rail.onpointerup;
      rail.ondblclick = () => { apply(defaults); setSide(side, false); decorate(); };
      rail.onkeydown = (e) => { if (['ArrowLeft', 'ArrowRight'].includes(e.key)) { e.preventDefault(); apply(size() + (e.key === 'ArrowRight' ? 16 : -16) * (side === 'l' ? 1 : -1)); } else if (e.key === 'Enter') rail.click(); };
    }
  }
  function stats() {
    const chat = window.ForgeChat.current();
    $('ccState').textContent = cur?.busy ? 'EXECUTING' : 'STANDING BY'; $('coreState') && ($('coreState').textContent = cur?.busy ? 'EXECUTING' : 'STANDING BY');
    $('ccRoute').textContent = (ENGINE_LABEL[engine] || engine).toUpperCase(); $('deckEngine') && ($('deckEngine').textContent = ENGINE_LABEL[engine] || engine);
    $('ccModel').textContent = $('model').selectedOptions[0]?.text || 'NO MODEL SELECTED';
    $('ccChats').textContent = window.ForgeChat.all().filter((x) => !x.archived).length;
    $('ccTurns').textContent = (chat?.messages || []).filter((x) => x.role === 'user').length;
    $('ccMemory').textContent = !chat ? 'NO ACTIVE CHAT' : cur?.pendingHandoff ? 'CONTEXT STAGED' : 'HISTORY SAVED';
    $('ccFps').textContent = fps || '—';
    if (!$('forgeHome') && !transcript.length && !cur?.busy) home();
    if (transcript.length) $('forgeHome')?.remove();
  }
  const oldSetBusy = setBusy; setBusy = (busy) => { oldSetBusy(busy); document.body.classList.toggle('agent-working', !!busy); if (busy) $('forgeHome')?.remove(); stats(); };
  const oldAdd = add; add = (el) => { $('forgeHome')?.remove(); return oldAdd(el); };
  const oldSetSide = setSide; setSide = (side, value) => { oldSetSide(side, value); const rail = $(side + 'Tog'); rail.textContent = ''; rail.append(h('span', { class: 'rail-chevrons' }, value ? '› ‹' : '‹ ›'), h('span', { class: 'rail-label' }, side === 'l' ? 'HISTORY' : 'CONTROL'), h('span', { class: 'rail-grip' }, '⠿')); };
  addEventListener('forge-ready', async () => { installed = await api.engines(); overview(); resizeRails(); showPane('control'); home(); stats(); log('Control centre ready · provider sessions share Forge history'); });
  addEventListener('forge-chat-changed', stats);
  addEventListener('forge-provider-switched', (e) => { log((ENGINE_LABEL[e.detail.from] || e.detail.from) + ' → ' + (ENGINE_LABEL[e.detail.to] || e.detail.to) + ' · context staged', 'ok'); overview(); stats(); });
  addEventListener('forge-model-changed', () => { log('Model changed · ' + $('model').value, 'ok'); stats(); });
  api.onAcpNotify((eng, method, p) => { if (eng !== engine || p.sessionId !== cur?.sessionId) return; const u = p.update; if (u?.sessionUpdate === 'tool_call') log(u.title || u.kind || 'Tool execution'); if (u?.sessionUpdate === 'tool_call_update' && u.status === 'failed') log(u.title || 'Tool failed', 'bad'); });
  addEventListener('forge-turn-ended', () => { log('Turn finished · history saved', 'ok'); stats(); });
  function measure(now) { frames++; if (now - lastMeasure >= 1000) { fps = Math.round(frames * 1000 / (now - lastMeasure)); frames = 0; lastMeasure = now; } requestAnimationFrame(measure); } requestAnimationFrame(measure);
  setInterval(stats, 1500);
  const startCycle = () => { clearInterval(cycle); const seconds = S.opsCycleSeconds || 0; if (seconds) cycle = setInterval(() => { if (!hover && !document.hidden && !cur?.busy) regenerate(); }, seconds * 1000); };
  addEventListener('forge-ready', startCycle); addEventListener('cfg', startCycle);
  window.ForgeControl = { regenerate, log, stats };
})();
