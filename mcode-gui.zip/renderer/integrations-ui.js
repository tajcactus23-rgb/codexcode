(() => {
  const rows = (title, ...kids) => [title, ...kids];
  const field = (label, value, onChange, type = 'text', attrs = {}) => h('label', { class: 'se-row' }, h('span', {}, label), h('input', { type, value: value ?? '', ...attrs, onchange: (e) => Promise.resolve(onChange(type === 'number' ? +e.target.value : e.target.value)).catch((e) => toast(e.message)) }));
  const check = (label, value, fn) => h('label', { class: 'se-row chk' }, h('input', { type: 'checkbox', checked: value, onchange: (e) => Promise.resolve(fn(e.target.checked)).catch((e) => toast(e.message)) }), h('span', {}, label));
  const select = (label, value, options, fn) => h('label', { class: 'se-row' }, h('span', {}, label), h('select', { onchange: (e) => Promise.resolve(fn(e.target.value)).catch((e) => toast(e.message)) }, options.map(([v, name]) => h('option', { value: v, selected: v === value }, name))));
  const note = (text) => h('p', { class: 'se-p' }, text);
  const action = (text, fn) => h('button', { class: 'acc', onclick: async (e) => { e.currentTarget.disabled = true; const button = e.currentTarget; try { await fn(); } catch (e) { toast(e.message); } finally { button.disabled = false; } } }, text);
  const secret = (label, ref) => {
    const input = h('input', { type: 'password', placeholder: 'New value (blank preserves existing)', autocomplete: 'off' });
    const status = h('small', { class: 'dim' }, 'checking…');
    api.integrationStatus().then((s) => { status.textContent = s.secretRefs.includes(ref) ? 'configured · encrypted on this machine' : 'not configured'; }).catch((e) => { status.textContent = e.message; });
    return h('div', { class: 'se-row secret-row' }, h('span', {}, label), input,
      action('STORE', async () => { if (!input.value) return; await api.integrationSecret(ref, input.value); input.value = ''; status.textContent = 'configured · encrypted on this machine'; }),
      action('CLEAR', async () => { await api.integrationSecret(ref, null); status.textContent = 'not configured'; }), status);
  };
  const int = () => ({ profiles: [{ id: 'local', name: 'Built-in llama.cpp', baseUrl: 'http://127.0.0.1:8089/v1', model: '', vision: false }], activeProfile: 'local', ...(S.integrations || {}) });
  const patch = (s) => saveSettings({ integrations: { ...int(), ...s } });
  const patchProfile = (id, s) => patch({ profiles: int().profiles.map((p) => p.id === id ? { ...p, ...s } : p) });
  const voiceDefaults = { sttBase: '', sttModel: 'whisper-1', ttsBase: '', ttsModel: 'tts-1', voice: 'alloy', output: 'system', language: 'en', deviceId: '', silenceMs: 1100, minSpeechMs: 350, threshold: 0.035, maxRecordSec: 45, autoSend: true, speakReplies: true, bargeIn: true, rate: 1, volume: 1 };
  const voice = () => ({ ...voiceDefaults, ...int().voice });
  const patchVoice = (s) => patch({ voice: { ...voice(), ...s } });
  async function useProfile(id, carry = false) {
    if (cur?.busy) throw new Error('Stop the running turn before changing connections.');
    await patch({ activeProfile: id });
    await window.ForgeChat.switchTo('native', true);
  }
  api.onVoiceSetupEvent((text) => { const log = $('voiceSetupLog'); if (log) { log.textContent = (log.textContent + text).slice(-12000); log.scrollTop = log.scrollHeight; } });
  window.ForgeIntegrations = {
    voice, useProfile,
    async useLocal(alias) { await patchProfile('local', { model: alias }); await useProfile('local'); },
    settingsSections() {
      const cfg = int(), v = voice(), hermes = S.hermes || {}, local = S.localRuntime || {};
      const saveLocal = (s) => saveSettings({ localRuntime: { ...(S.localRuntime || {}), ...s } });
      const pro = cfg.profiles.find((p) => p.id === cfg.activeProfile) || cfg.profiles[0];
      const models = h('div', { class: 'se-models' });
      const providerRows = [select('Active profile', pro.id, cfg.profiles.map((p) => [p.id, p.name]), async (id) => { await patch({ activeProfile: id }); openSettings(); }),
        field('Display name', pro.name, (name) => patchProfile(pro.id, { name })),
        field('OpenAI-compatible base URL', pro.baseUrl, (baseUrl) => patchProfile(pro.id, { baseUrl })),
        field('Model ID (manual allowed)', pro.model, (model) => patchProfile(pro.id, { model })),
        check('Enable local files, commands, devices and browser tools', pro.tools !== false, (tools) => patchProfile(pro.id, { tools })),
        check('Image input supported by this model', pro.vision, (vision) => patchProfile(pro.id, { vision })),
        secret('Provider credential', 'provider-' + pro.id),
        h('div', { class: 'se-row' }, action('TEST + DISCOVER MODELS', async () => { const result = await api.integrationModels(pro.id); models.replaceChildren(note(`Connected · ${result.latencyMs} ms · ${result.models.length} models`), ...result.models.map((m) => action(m.id, async () => { await patchProfile(pro.id, { model: m.id }); toast('Selected ' + m.id); openSettings(); }))); }), action('USE PROFILE IN CHAT', async () => { await useProfile(pro.id, true); $('settings')?.remove(); })), models,
        h('div', { class: 'se-row' }, ...[['ollama', 'Ollama', 'http://127.0.0.1:11434/v1'], ['lmstudio', 'LM Studio', 'http://127.0.0.1:1234/v1'], ['vllm', 'vLLM / SGLang', 'http://127.0.0.1:8000/v1'], ['nous', 'Nous inference', 'https://inference-api.nousresearch.com/v1'], ['custom', 'Custom endpoint', 'https://example.com/v1']].map(([id, name, baseUrl]) => action('+ ' + name, async () => { const existing = int().profiles.find((p) => p.id === id); await patch({ profiles: existing ? int().profiles : [...int().profiles, { id, name, baseUrl, model: '', vision: false }], activeProfile: id }); openSettings(); }))),
        field('Temperature', cfg.temperature ?? 0.7, (temperature) => patch({ temperature }), 'number', { min: 0, max: 2, step: 0.05 }),
        field('Top P', cfg.topP ?? 0.95, (topP) => patch({ topP }), 'number', { min: 0.01, max: 1, step: 0.01 }),
        field('Maximum output tokens', cfg.maxTokens ?? 4096, (maxTokens) => patch({ maxTokens }), 'number', { min: 64, max: 131072 }),
        field('Timeout (ms)', cfg.timeoutMs ?? 180000, (timeoutMs) => patch({ timeoutMs }), 'number', { min: 1000, max: 900000 }),
        field('History turns sent', cfg.historyTurns ?? 24, (historyTurns) => patch({ historyTurns }), 'number', { min: 0, max: 100 }),
        field('System instructions', cfg.systemPrompt ?? 'You are a coding and GUI development assistant. Use forge_runtime for actual file, command, browser and device work. Verify results.', (systemPrompt) => patch({ systemPrompt }))];
      const args = field('Launch arguments (JSON array)', JSON.stringify(hermes.args || ['acp']), async (text) => { const args = JSON.parse(text); if (!Array.isArray(args) || !args.every((x) => typeof x === 'string')) throw new Error('Arguments must be an array of strings.'); await saveSettings({ hermes: { ...(S.hermes || {}), args } }); });
      const health = h('pre', { class: 'integration-log' });
      const telegramLog = h('pre', { class: 'integration-log' });
      const voiceLog = h('pre', { class: 'integration-log', id: 'voiceSetupLog' });
      const device = select('Microphone', v.deviceId, [['', 'System default']], (deviceId) => patchVoice({ deviceId }));
      const deviceSelect = device.querySelector('select');
      navigator.mediaDevices?.enumerateDevices().then((devices) => { for (const d of devices.filter((d) => d.kind === 'audioinput')) deviceSelect.append(h('option', { value: d.deviceId, selected: d.deviceId === v.deviceId }, d.label || 'Microphone ' + d.deviceId.slice(0, 6))); }).catch(() => {});
      return {
        commandCentre: rows('Command centre', select('Startup screen', S.startPage || 'mission', [['mission', 'Command bridge'], ['code', 'Unified chat'], ['showcase', 'Showcase']], startPage => saveSettings({ startPage })), note('Live agents, actual system/device inventory, runtime activity, file chunks, bounded missions and independent supervision.'), action('OPEN COMMAND BRIDGE', () => { $('settings')?.remove(); showPage('mission'); }), action('OPEN SHOWCASE', () => { $('settings')?.remove(); showPage('showcase'); })),
        monitor: rows('Monitor agents', note('A separate provider session checks autonomous workers for loops, errors, missing evidence and stalled tools. The run stops when the reviewer is unavailable, rejects progress, or a budget is exceeded.'),
          select('Supervisor engine', S.monitor?.reviewer || 'codex', ['codex','claude','native','hermes','mcode','opencode','kilo'].map(x => [x, ENGINE_LABEL[x] || x]), reviewer => saveSettings({ monitor: { ...S.monitor, reviewer } })),
          field('Supervisor model override', S.monitor?.reviewerModel || '', reviewerModel => saveSettings({ monitor: { ...S.monitor, reviewerModel } })),
          field('No-progress limit seconds', S.monitor?.idleSeconds ?? 180, idleSeconds => saveSettings({ monitor: { ...S.monitor, idleSeconds } }), 'number', { min: 30, max: 1800 }),
          field('Run limit minutes', S.monitor?.maxMinutes ?? 30, maxMinutes => saveSettings({ monitor: { ...S.monitor, maxMinutes } }), 'number', { min: 1, max: 240 }),
          field('Review interval seconds', S.monitor?.reviewSeconds ?? 90, reviewSeconds => saveSettings({ monitor: { ...S.monitor, reviewSeconds } }), 'number', { min: 30, max: 1800 }),
          field('Maximum independent reviews', S.monitor?.maxReviews ?? 8, maxReviews => saveSettings({ monitor: { ...S.monitor, maxReviews } }), 'number', { min: 1, max: 40 }),
          field('Repeated tool failures before stop', S.monitor?.failureLimit ?? 3, failureLimit => saveSettings({ monitor: { ...S.monitor, failureLimit } }), 'number', { min: 1, max: 20 })),
        telegram: rows('Telegram', note('Encrypted bot token, explicit chat allowlist, long polling, /status, /chat, /run, /dev and /stop. Documents download to local attachments. Forge must remain running. Cloud Bot API has its own file download limits; a local Bot API server can handle larger files.'),
          secret('Bot token', 'telegram'),
          field('Allowed chat IDs (comma separated)', (S.telegram?.chatIds || []).join(', '), text => { const chatIds = text.split(',').map(x => x.trim()).filter(Boolean); if (!chatIds.every(x => /^-?\d+$/.test(x))) throw Error('Use numeric Telegram chat IDs.'); return saveSettings({ telegram: { ...S.telegram, chatIds } }); }),
          field('Bot API base URL', S.telegram?.baseUrl || 'https://api.telegram.org', baseUrl => saveSettings({ telegram: { ...S.telegram, baseUrl } })),
          check('Enable /run and /dev from allowed chats', S.telegram?.allowRun === true, allowRun => saveSettings({ telegram: { ...S.telegram, allowRun } })),
          action('TEST BOT TOKEN', async () => { const r = await api.telegramTest(); toast('@' + r.username + ' ready'); }),
          action('DISCOVER MY CHAT ID', async () => { const r = await api.telegramDiscover(); telegramLog.textContent = r.length ? JSON.stringify(r, null, 2) : 'Send your bot a message, then discover again.'; }),
          action('CONNECT TELEGRAM', async () => { const r = await api.telegramStart(); toast('Connected @' + r.username); }), action('DISCONNECT TELEGRAM', () => api.telegramStop()), telegramLog),
        subscriptions: rows('Subscriptions', note('Codex uses Sign in with ChatGPT. Claude uses your Claude Code account login. Forge launches the installed ACP adapters and reuses their credentials; provider API keys are excluded from these subprocesses.'),
          action('SIGN IN WITH CHATGPT / CODEX', async () => { const r = await api.subscriptionLogin('codex'); toast(r.message); }),
          action('SIGN IN WITH CLAUDE SUBSCRIPTION', async () => { const r = await api.subscriptionLogin('claude'); toast(r.message); }),
          action('USE CODEX', () => window.ForgeChat.switchTo('codex')), action('USE CLAUDE', () => window.ForgeChat.switchTo('claude')),
          note('These sessions use your account’s included usage and limits. Your account sign-in must be completed on this computer.')),
        selfDevelopment: rows('Self development', note('Create a working copy of Forge, let a coding agent edit it, run real checks, then ask a separate reviewer to inspect the result. Only a validated, reviewed source hash can be applied.'),
          action('OPEN SELF DEVELOPMENT DECK', () => { $('settings')?.remove(); showPane('self'); window.ForgeSelfDev.render(); }),
          field('Additional validators (JSON array)', JSON.stringify(S.selfDev?.validators || []), async (text) => { const validators = JSON.parse(text); if (!Array.isArray(validators)) throw new Error('Use an array of command/args objects.'); await saveSettings({ selfDev: { ...S.selfDev, validators } }); }),
          field('Handoff context character budget', S.handoffChars || 48000, (handoffChars) => saveSettings({ handoffChars }), 'number', { min: 8000, max: 200000 }),
          field('Suggestion cycling seconds (0 = off)', S.opsCycleSeconds || 0, async (opsCycleSeconds) => { await saveSettings({ opsCycleSeconds }); dispatchEvent(new Event('cfg')); }, 'number', { min: 0, max: 300 })),
        connections: rows('Connections', note('Native endpoint models can call real local tools when enabled and supported by the model. Ask mode permits inspection; Agent mode permits coding and operation. Local servers run on your own machine.'), ...providerRows),
        hermes: rows('Hermes', note('Hermes Agent uses its own provider credentials, skills, memory and tools over ACP. Install Hermes with ACP support, then configure its providers using hermes model. Credentials already configured in Hermes are reused. To let local models code, run hermes model, choose Custom endpoint and point it at the built-in server (http://127.0.0.1:8089/v1) or Ollama/LM Studio. Choose a model with working tool calling.'),
          field('Launcher executable / absolute path', hermes.command || 'hermes', (command) => saveSettings({ hermes: { ...(S.hermes || {}), command } })), args,
          note('Windows with WSL: launcher C:\\Windows\\System32\\wsl.exe, arguments ["--", "hermes", "acp"]. Select a workspace path your WSL installation can access.'),
          action('CHECK HERMES', async () => { const r = await api.hermesCheck(); health.textContent = (r.ok ? 'READY\n' : 'NOT READY\n') + r.message; }),
          action('RESTART HERMES', async () => { if (cur?.busy && cur.engine === 'hermes') throw new Error('Stop the turn first.'); await api.acpRestart('hermes'); toast('Hermes will restart on the next request.'); }), health),
        localRuntime: rows('Local runtime', note('Built-in GGUF inference via llama.cpp. Hugging Face and Unsloth GGUFs use the same native runtime. Safetensors need a separate compatible server such as vLLM.'),
          action('OPEN LOCAL MODEL BAY', () => { $('settings')?.remove(); window.openLocalBay(); }),
          field('Threads (0 = runtime default)', local.threads ?? 0, (threads) => saveLocal({ threads }), 'number', { min: 0, max: 256 }),
          field('GPU layers (-1 = auto)', local.gpuLayers ?? -1, (gpuLayers) => saveLocal({ gpuLayers }), 'number', { min: -1, max: 999 }),
          field('Context tokens (0 = auto)', local.context ?? 0, (context) => saveLocal({ context }), 'number', { min: 0, max: 262144 }),
          field('Batch size', local.batch ?? 512, (batch) => saveLocal({ batch }), 'number', { min: 32, max: 4096 }),
          field('Microbatch size', local.ubatch ?? 128, (ubatch) => saveLocal({ ubatch }), 'number', { min: 32, max: 2048 }),
          field('Reasoning token budget', local.reasoningBudget ?? 2048, (reasoningBudget) => saveLocal({ reasoningBudget }), 'number', { min: -1, max: 65536 }),
          select('KV cache type', local.cacheType || 'q8_0', ['f16', 'q8_0', 'q4_0'].map((x) => [x, x]), (cacheType) => saveLocal({ cacheType })),
          check('Flash attention', local.flashAttention !== false, (flashAttention) => saveLocal({ flashAttention })),
          check('Allow reuse of an installed external runtime', S.useExternalRuntime === true, (useExternalRuntime) => saveSettings({ useExternalRuntime })), note('Launch settings apply the next time you load a model.')),
        uploads: rows('Files & model library', note('Attach every file type, folders, dropped files and clipboard images. Large files stream to disk and split automatically into lossless, verified chunks. A model context remains bounded: agents use offsets, extraction and installed format tools to process the file. Unknown binary formats remain accessible as bytes.'),
          note('Chunk storage: ' + (S.files?.chunkDir || 'Forge app data') + '. Changing storage location takes effect after restarting Forge.'),
          action('CHOOSE CHUNK STORAGE VOLUME', async () => { const chunkDir = await api.pickFolder(); if (chunkDir) { await saveSettings({ files: { ...S.files, chunkDir } }); toast('Chunk storage saved. Restart Forge to use it.'); } }),
          field('Automatic chunk threshold MB', S.files?.thresholdMB ?? 64, thresholdMB => saveSettings({ files: { ...S.files, thresholdMB } }), 'number', { min: 1, max: 1048576 }),
          field('Chunk size MB', S.files?.chunkMB ?? 32, chunkMB => saveSettings({ files: { ...S.files, chunkMB } }), 'number', { min: 1, max: 256 }),
          field('File storage allowance GB (0 = disk capacity)', S.files?.maxGB ?? 0, maxGB => saveSettings({ files: { ...S.files, maxGB } }), 'number', { min: 0, max: 1048576 }),
          action('INSTALL DOCUMENT EXTRACTORS', async () => { const r = await api.fileInstall(); S = await api.settings(); toast(r.message); }),
          action('OPEN FILE CHUNKS / REASSEMBLY', () => { $('settings')?.remove(); showPage('mission'); }),
          field('Direct-chat inline file MB', cfg.attachmentMaxMB ?? 10, (attachmentMaxMB) => patch({ attachmentMaxMB }), 'number', { min: 1, max: 64 }),
          field('Direct-chat total attachment characters', cfg.attachmentMaxChars ?? 120000, (attachmentMaxChars) => patch({ attachmentMaxChars }), 'number', { min: 1000, max: 1000000 }),
          secret('Hugging Face read token (gated/private models)', 'huggingface'), note('Accept a gated model’s license on Hugging Face before downloading it.'), action('BROWSE HUGGING FACE / UNSLOTH', () => { $('settings')?.remove(); window.openLocalBay(); })),
        voice: rows('Voice', note('Voice input goes to the selected model as text. Leave transcription URL blank for local Whisper, or use a compatible speech server. Speech output supports system voices, TTS endpoints and your own local XTTS voice clone.'),
          field('Transcription base URL', v.sttBase, (sttBase) => patchVoice({ sttBase })), field('Transcription model', v.sttModel, (sttModel) => patchVoice({ sttModel })), secret('Transcription credential', 'voice-stt'),
          select('Speech output', v.output, [['system', 'System voices'], ['kokoro', 'Kokoro · ten local voices'], ['endpoint', 'Model / TTS endpoint'], ['clone', 'My voice · local XTTS clone']], (output) => patchVoice({ output })),
          select('Kokoro voice preset', v.kokoroVoice || 'bm_george', [['af_heart','Heart · US female'], ['af_bella','Bella · US female'], ['af_nicole','Nicole · US female'], ['af_sarah','Sarah · US female'], ['af_sky','Sky · US female'], ['am_fenrir','Fenrir · US male'], ['am_michael','Michael · US male'], ['bf_emma','Emma · UK female'], ['bf_isabella','Isabella · UK female'], ['bm_george','George · UK male']], kokoroVoice => patchVoice({ kokoroVoice })),
          action('CHECK KOKORO RUNTIME', async () => { const r = await api.voiceKokoroCheck(); toast(r.message); }),
          note('Kokoro voices are actual model voice presets. Install the local voice runtime first; initial synthesis downloads model assets. espeak-ng may be required for pronunciation fallback.'),
          field('Speech base URL', v.ttsBase, (ttsBase) => patchVoice({ ttsBase })), field('Speech model', v.ttsModel, (ttsModel) => patchVoice({ ttsModel })), field('Voice ID', v.voice, (voice) => patchVoice({ voice })), secret('Speech credential', 'voice-tts'), device,
          field('Voice-clone Python executable', v.clonePython || 'python', (clonePython) => patchVoice({ clonePython })),
          note('Setup requires Python 3.10–3.13 and downloads speech dependencies into a dedicated environment. First use downloads the selected speech model. XTTS uses a clean 6–30 second recording of your own voice.'),
          action('INSTALL LOCAL VOICE RUNTIME', async () => { const result = await api.voiceInstall(); S = await api.settings(); toast(result.message); }), voiceLog,
          field('Local Whisper model', v.localSttModel || 'small', (localSttModel) => patchVoice({ localSttModel })),
          check('I accept the XTTS model license for local voice synthesis', v.cloneLicenseAccepted === true, (cloneLicenseAccepted) => patchVoice({ cloneLicenseAccepted })),
          action('CHOOSE MY VOICE RECORDING', async () => { const reference = await api.voiceReference(); if (reference) { S = await api.settings(); toast('Voice reference saved on this machine.'); } }),
          action('CHECK VOICE-CLONE RUNTIME', async () => { const result = await api.voiceCloneCheck(); toast(result.message); }),
          field('Language code', v.language, (language) => patchVoice({ language })),
          field('Silence before sending (ms)', v.silenceMs, (silenceMs) => patchVoice({ silenceMs }), 'number', { min: 400, max: 5000 }),
          field('Minimum speech (ms)', v.minSpeechMs, (minSpeechMs) => patchVoice({ minSpeechMs }), 'number', { min: 100, max: 2000 }),
          field('Speech detection threshold', v.threshold, (threshold) => patchVoice({ threshold }), 'number', { min: 0.005, max: 0.5, step: 0.005 }),
          field('Maximum recording seconds', v.maxRecordSec, (maxRecordSec) => patchVoice({ maxRecordSec }), 'number', { min: 5, max: 120 }),
          field('Speaking rate', v.rate, (rate) => patchVoice({ rate }), 'number', { min: 0.25, max: 4, step: 0.05 }), field('Volume', v.volume, (volume) => patchVoice({ volume }), 'number', { min: 0, max: 1, step: 0.05 }),
          check('Send transcribed turns automatically', v.autoSend, (autoSend) => patchVoice({ autoSend })), check('Speak completed replies', v.speakReplies, (speakReplies) => patchVoice({ speakReplies })), check('Barge in: interrupt speech / model when talking', v.bargeIn, (bargeIn) => patchVoice({ bargeIn })),
          action('TEST SPEECH OUTPUT', () => window.ForgeVoice.speak('Forge voice output is connected.')), action('START VOICE CONVERSATION', async () => { $('settings')?.remove(); await window.ForgeVoice.start(); }))
      };
    }
  };
})();
