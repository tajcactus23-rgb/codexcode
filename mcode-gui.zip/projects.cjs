const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { pathToFileURL } = require('node:url');

const statuses = new Set(['in-progress', 'ready', 'archived']);
const idFor = p => crypto.createHash('sha256').update(path.resolve(p)).digest('hex').slice(0, 20);
const text = (s, limit) => String(s || '').trim().slice(0, limit);
function previewURL(s) {
  if (!s) return null;
  const u = new URL(s);
  if (!['http:', 'https:', 'file:'].includes(u.protocol)) throw Error('Use an HTTP(S) preview URL or a local HTML file.');
  return u.href;
}
function createStore({ userData, getRoots = () => [] }) {
  const file = path.join(userData, 'showcase-projects.json');
  let saved;
  try { saved = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { saved = {}; }
  if (!saved || typeof saved !== 'object' || Array.isArray(saved)) saved = {};
  if (!saved.items || typeof saved.items !== 'object' || Array.isArray(saved.items)) saved.items = {};
  saved.items = Object.fromEntries(Object.entries(saved.items).filter(([, item]) => item && typeof item.path === 'string'));
  if (!Array.isArray(saved.hidden)) saved.hidden = [];
  const pathsById = new Map();
  function locations() { return [...new Set([...getRoots(), ...Object.values(saved.items).map(x => x.path)].filter(p => typeof p === 'string' && p).map(p => path.resolve(p)))].slice(0, 300); }
  function persist() { fs.mkdirSync(userData, { recursive: true }); const temp = file + '.tmp'; fs.writeFileSync(temp, JSON.stringify(saved, null, 2)); fs.renameSync(temp, file); }
  async function inspect(location) {
    const absolute = path.resolve(location), id = idFor(absolute), meta = saved.items[id] || {};
    let stat;
    try { stat = await fs.promises.stat(absolute); } catch { return { id, path: absolute, name: meta.name || path.basename(absolute), missing: true, status: meta.status || 'in-progress', tags: meta.tags || [], summary: meta.summary || 'Project path is unavailable.', pinned: !!meta.pinned, source: meta.source || 'workspace', previewUrl: meta.previewUrl || null }; }
    const dir = stat.isDirectory() ? absolute : path.dirname(absolute);
    const read = async f => { try { const s = await fs.promises.stat(f); if (s.size > 1048576) return ''; return await fs.promises.readFile(f, 'utf8'); } catch { return ''; } };
    let pkg = {}; try { pkg = JSON.parse(await read(path.join(dir, 'package.json'))); } catch {}
    if (!pkg || typeof pkg !== 'object' || Array.isArray(pkg)) pkg = {};
    const candidates = stat.isFile() && /\.html?$/i.test(absolute) ? [absolute] : ['index.html', 'dist/index.html', 'build/index.html', 'public/index.html', 'renderer/index.html'].map(f => path.join(dir, f));
    let entry = null;
    for (const f of candidates) { try { if ((await fs.promises.stat(f)).isFile()) { entry = f; break; } } catch {} }
    const readme = await read(path.join(dir, 'README.md'));
    const summary = text(pkg.description || readme.split('\n').find(l => l.trim() && !/^#|^```|^\[|^</.test(l.trim())) || '', 280);
    const deps = { ...pkg.dependencies, ...pkg.devDependencies }, tags = Object.keys(deps).filter(k => /^(react|vue|svelte|electron|three|vite|next|typescript)$/.test(k)).slice(0, 5);
    if (entry && !tags.length) tags.push('HTML');
    let thumbnail = meta.thumbnail || null;
    if (!thumbnail) for (const f of ['preview.png', 'screenshot.png', 'previews/preview.png', 'previews/control-centre.png', 'docs/screenshot.png']) { try { if ((await fs.promises.stat(path.join(dir, f))).isFile()) { thumbnail = path.join(dir, f); break; } } catch {} }
    return { id, path: absolute, directory: dir, name: meta.name || pkg.productName || pkg.name || path.basename(absolute).replace(/\.html?$/i, ''), summary: meta.summary ?? summary, status: meta.status || 'in-progress', tags: meta.tags || tags, pinned: !!meta.pinned, source: meta.source || 'workspace', modifiedAt: stat.mtime.toISOString(), entry, previewUrl: meta.previewUrl || (entry ? pathToFileURL(entry).href : null), thumbnail, missing: false };
  }
  async function list() {
    const roots = locations(); pathsById.clear(); roots.forEach(p => pathsById.set(idFor(p), p));
    const items = await Promise.all(roots.map(inspect));
    return items.filter(x => !saved.hidden.includes(x.id)).sort((a, b) => Number(b.pinned) - Number(a.pinned) || String(b.modifiedAt || '').localeCompare(a.modifiedAt || '') || a.name.localeCompare(b.name));
  }
  async function add(location, source = 'imported') { const p = await inspect(location); if (p.missing) throw Error('Choose an existing project folder or HTML file.'); saved.items[p.id] = { ...saved.items[p.id], path: p.path, source }; saved.hidden = saved.hidden.filter(id => id !== p.id); persist(); return inspect(p.path); }
  async function find(id) {
    if (saved.hidden.includes(id)) throw Error('Project is no longer in the showcase.');
    let location = pathsById.get(id) || saved.items[id]?.path;
    if (!location) { locations().forEach(p => pathsById.set(idFor(p), p)); location = pathsById.get(id); }
    if (!location) throw Error('Project is no longer in the showcase.');
    return inspect(location);
  }
  async function update(id, patch) {
    const p = await find(id), next = { ...saved.items[id], path: p.path };
    if (patch.name !== undefined) next.name = text(patch.name, 100) || path.basename(p.path);
    if (patch.summary !== undefined) next.summary = text(patch.summary, 800);
    if (patch.status !== undefined) { if (!statuses.has(patch.status)) throw Error('Unknown project status.'); next.status = patch.status; }
    if (patch.tags !== undefined) next.tags = (Array.isArray(patch.tags) ? patch.tags : String(patch.tags).split(',')).map(s => text(s, 30)).filter(Boolean).slice(0, 8);
    if (patch.pinned !== undefined) next.pinned = !!patch.pinned;
    if (patch.previewUrl !== undefined) next.previewUrl = previewURL(text(patch.previewUrl, 2048));
    // Thumbnail paths are only set by the native picker or the capture worker.
    if (patch.thumbnail !== undefined) next.thumbnail = patch.thumbnail;
    saved.items[id] = next; persist(); return inspect(p.path);
  }
  async function remove(id) { await find(id); delete saved.items[id]; saved.hidden = [...new Set([...saved.hidden, id])]; persist(); return true; }
  async function thumbnail(id) {
    const p = await find(id); if (!p.thumbnail) return null;
    try { const s = await fs.promises.stat(p.thumbnail); if (!s.isFile() || s.size > 12 * 1048576) return null; const ext = path.extname(p.thumbnail).toLowerCase(), type = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp' }[ext]; if (!type) return null; return `data:${type};base64,${(await fs.promises.readFile(p.thumbnail)).toString('base64')}`; } catch { return null; }
  }
  return { list, inspect, add, find, update, remove, thumbnail };
}

function register({ app, ipcMain, dialog, BrowserWindow, getWin, getSettings, getForgedRoots }) {
  const userData = app.getPath('userData');
  const store = createStore({ userData, getRoots: () => [getSettings().cwd, ...(getSettings().recents || []), ...getForgedRoots()] });
  ipcMain.handle('projects:list', () => store.list());
  ipcMain.handle('projects:import', async (_e, kind) => { const r = await dialog.showOpenDialog(getWin(), { title: kind === 'file' ? 'Add a built project' : 'Add a project workspace', properties: [kind === 'file' ? 'openFile' : 'openDirectory'], ...(kind === 'file' ? { filters: [{ name: 'HTML projects', extensions: ['html', 'htm'] }] } : {}) }); return r.filePaths[0] ? store.add(r.filePaths[0]) : null; });
  ipcMain.handle('projects:update', (_e, id, patch) => { const { thumbnail, ...safe } = patch || {}; return store.update(id, safe); });
  ipcMain.handle('projects:remove', (_e, id) => store.remove(id));
  ipcMain.handle('projects:thumbnail', (_e, id) => store.thumbnail(id));
  ipcMain.handle('projects:pick-cover', async (_e, id) => { await store.find(id); const r = await dialog.showOpenDialog(getWin(), { title: 'Choose a project cover', properties: ['openFile'], filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'webp'] }] }); return r.filePaths[0] ? store.update(id, { thumbnail: r.filePaths[0] }) : null; });
  const makeWindow = (project, show) => { const w = new BrowserWindow({ width: 1920, height: 1080, show, title: project.name, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, backgroundThrottling: true } }); w.webContents.setWindowOpenHandler(() => ({ action: 'deny' })); return w; };
  ipcMain.handle('projects:open', async (_e, id) => { const p = await store.find(id); if (!p.previewUrl) throw Error('Set a running app URL or build an HTML entry point first.'); const w = makeWindow(p, true); try { await w.loadURL(previewURL(p.previewUrl)); } catch (e) { if (!w.isDestroyed()) w.close(); throw e; } return { opened: true }; });
  ipcMain.handle('projects:capture', async (_e, id) => {
    const p = await store.find(id); if (!p.previewUrl) throw Error('Set a running app URL or build an HTML entry point first.'); const w = makeWindow(p, false);
    const timer = setTimeout(() => { if (!w.isDestroyed()) w.destroy(); }, 20000);
    try { await w.loadURL(previewURL(p.previewUrl)); await new Promise(r => setTimeout(r, 800)); const dir = path.join(userData, 'project-covers'); fs.mkdirSync(dir, { recursive: true }); const file = path.join(dir, id + '.png'); await fs.promises.writeFile(file, (await w.capturePage()).toPNG()); return store.update(id, { thumbnail: file }); } finally { clearTimeout(timer); if (!w.isDestroyed()) w.destroy(); }
  });
  return store;
}
module.exports = { createStore, register, previewURL };
