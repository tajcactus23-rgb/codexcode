"""Persistent local XTTS worker. Uses a reference recording of the user's voice."""
import json
import sys
import traceback

def main():
    try:
        import torch
        from TTS.api import TTS
        model = TTS('tts_models/multilingual/multi-dataset/xtts_v2').to('cuda' if torch.cuda.is_available() else 'cpu')
    except Exception:
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)
    print('FORGE_JSON:' + json.dumps({'ready': True}), flush=True)
    for line in sys.stdin:
        req = {}
        try:
            req = json.loads(line)
            model.tts_to_file(text=req['text'], speaker_wav=req['reference'], language=req.get('language') or 'en', file_path=req['output'])
            print('FORGE_JSON:' + json.dumps({'id': req['id'], 'output': req['output']}), flush=True)
        except Exception as err:
            print('FORGE_JSON:' + json.dumps({'id': req.get('id'), 'error': str(err)}), flush=True)

if __name__ == '__main__':
    main()
