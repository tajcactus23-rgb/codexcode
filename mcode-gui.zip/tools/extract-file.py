"""Extract supported documents to disk, page by page; never loads the whole text into a model."""
import sys, pathlib, zipfile, json
source, target = map(pathlib.Path, sys.argv[1:3])
ext = source.suffix.lower()
with target.open('w', encoding='utf8') as out:
    if ext == '.pdf':
        from pypdf import PdfReader
        for i, page in enumerate(PdfReader(str(source)).pages):
            out.write(f'\n[Page {i+1}]\n' + (page.extract_text() or '') + '\n')
    elif ext == '.docx':
        from docx import Document
        doc = Document(str(source))
        for p in doc.paragraphs: out.write(p.text + '\n')
        for table in doc.tables:
            for row in table.rows: out.write('\t'.join(c.text for c in row.cells) + '\n')
    elif ext in ('.xlsx', '.xlsm'):
        from openpyxl import load_workbook
        book = load_workbook(source, read_only=True, data_only=False)
        for sheet in book:
            out.write(f'\n[Sheet {sheet.title}]\n')
            for row in sheet.iter_rows(values_only=True): out.write('\t'.join('' if v is None else str(v) for v in row) + '\n')
        book.close()
    elif ext == '.pptx':
        from pptx import Presentation
        for i, slide in enumerate(Presentation(str(source)).slides):
            out.write(f'\n[Slide {i+1}]\n')
            for shape in slide.shapes:
                if shape.has_text_frame: out.write(shape.text + '\n')
    elif zipfile.is_zipfile(source):
        with zipfile.ZipFile(source) as z:
            for entry in z.infolist(): out.write(json.dumps({'name': entry.filename, 'bytes': entry.file_size, 'compressed': entry.compress_size}) + '\n')
    else:
        # All bytes remain accessible. Text formats are streamed; binary files expose metadata explicitly.
        with source.open('rb') as src:
            probe = src.read(8192)
            if b'\0' in probe:
                out.write(json.dumps({'format':ext, 'bytes':source.stat().st_size, 'binary':True, 'hex_header':probe[:256].hex(), 'note':'Use file.read(base64), an installed extractor or vendor tool to interpret this binary format.'}))
            else:
                import codecs
                decoder=codecs.getincrementaldecoder('utf8')('replace')
                out.write(decoder.decode(probe))
                while True:
                    part=src.read(1048576)
                    if not part: break
                    out.write(decoder.decode(part))
                out.write(decoder.decode(b'', final=True))
print(json.dumps({'path':str(target), 'bytes':target.stat().st_size}))
