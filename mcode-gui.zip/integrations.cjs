// Native endpoint chat, encrypted credential references and configurable speech services.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { fileURLToPath } = require('node:url');

const DEFAULT_INTEGRATIONS = {
  profiles: [{ id: 'local', name: 'Built-in llama.cpp', baseUrl: 'http://127.0.0.1:8089/v1', model: '', vision: false }],
  activeProfile: 'local', temperature: 0.7, topP: 0.95, maxTokens: 4096, timeoutMs: 180000,
  systemPrompt: 'You are a coding and GUI development assistant. Explain and produce code accurately. Use forge_runtime to inspect and edit actual local files, run installed tools, and operate the browser/device when the task requires it. Check results and report limitations accurately.',
  attachmentMaxMB: 10, attachmentMaxChars: 120000, historyTurns: 24,
  voice: { sttBase: '', sttModel: 'whisper-1', ttsBase: '', ttsModel: 'tts-1', voice: 'alloy',
    output: 'system', language: 'en', deviceId: '', silenceMs: 1100, minSpeechMs: 350, threshold: 0.035,
    maxRecordSec: 45, autoSend: true, speakReplies: true, bargeIn: true, rate: 1, volume: 1 },
};
function endpoint(base, suffix) {
  const u = new URL(String(base).replace(/\/$/, '') + suffix);
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) throw new Error('Use an HTTP(S) endpoint without embedded credentials.');
  if (u.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(u.hostname)) throw new Error('Remote endpoints must use HTTPS.');
  return u.href;
}
function config(settings) {
  const s = settings.integrations || {};
  return { ...DEFAULT_INTEGRATIONS, ...s, voice: { ...DEFAULT_INTEGRATIONS.voice, ...s.voice } };
}
async function checkedFetch(url, opts = {}) {
  const r = await fetch(url, { ...opts, signal: opts.signal || AbortSignal.timeout(30000) });
  if (!r.ok) { const detail = (await r.text()).slice(0, 300); throw new Error(`Endpoint HTTP ${r.status}: ${detail}`); }
  return r;
}
// Streaming parsers must preserve a multi-byte character split over network packets.
async function* sse(body) {
  const decoder = new TextDecoder(); let pending = '';
  for await (const bytes of body) {
    pending += decoder.decode(bytes, { stream: true });
    let end;
    while ((end = pending.indexOf('\n')) >= 0) {
      const line = pending.slice(0, end).trim(); pending = pending.slice(end + 1);
      if (!line.startsWith('data:')) continue;
      const data = line.slice(5).trim(); if (data === '[DONE]') return;
      if (data) yield JSON.parse(data);
    }
  }
  pending += decoder.decode();
  if (pending.trim().startsWith('data:') && pending.trim().slice(5).trim() !== '[DONE]') yield JSON.parse(pending.trim().slice(5));
}
async function promptContent(blocks, profile, cfg, drivers) {
  const content = []; let chars = 0;
  for (const block of blocks || []) {
    if (block.type === 'text') { content.push({ type: 'text', text: block.text }); continue; }
    if (block.type !== 'resource_link' || !block.uri?.startsWith('file:')) throw new Error('Direct chat accepts text and attached local files.');
    const file = fileURLToPath(block.uri), st = await fs.promises.stat(file);
    if (drivers) {
      const ext = path.extname(file).toLowerCase();
      const images = /\.(png|jpe?g|webp|gif)$/.test(ext);
      const textFile = /\.(txt|md|js|jsx|ts|tsx|json|html?|css|scss|py|sh|ps1|c|h|cpp|hpp|go|rs|java|sql|csv|tsv|log|yaml|yml|toml|xml|svg|vue|svelte|ini|rb|php|swift|dart|lua)$/.test(ext);
      if (!st.isFile() || st.size > cfg.attachmentMaxMB * 1048576 || (!images && !textFile)) {
        const chunks = st.isFile() ? await drivers.filePipeline.prepare(file) : null;
        let preview = '', extraction = '';
        if (st.isFile() && textFile) preview = (await drivers.filePipeline.readRange(file, { length: Math.min(65536, cfg.attachmentMaxChars) })).text;
        else if (st.isFile() && /\.(pdf|docx|xlsx|xlsm|pptx|zip)$/.test(ext)) {
          try { const result = await drivers.runtime.extract(file); extraction = result.path; preview = (await drivers.filePipeline.readRange(result.path, { length: 32768 })).text; }
          catch (e) { extraction = 'Extractor unavailable: ' + e.message; }
        }
        content.push({ type: 'text', text: `[Local attachment] ${file} (${st.size} bytes). ${chunks ? 'Lossless chunk manifest: '+chunks.manifestPath : ''} ${extraction ? 'Extracted text: '+extraction : ''}\nUse forge_runtime file.read with offsets, file.extract or installed format tools to process the whole file. This preview is bounded, not the whole file:\n${preview}` });
        continue;
      }
    }
    if (!st.isFile()) throw new Error('Direct chat requires individual files. Use a coding agent to read folders.');
    if (st.size > cfg.attachmentMaxMB * 1048576) throw new Error(`${path.basename(file)} exceeds the direct-chat attachment limit.`);
    const ext = path.extname(file).toLowerCase();
    const mime = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif' }[ext];
    if (mime) {
      if (!profile.vision) throw new Error('This profile has vision disabled. Enable it only for a model that supports images.');
      content.push({ type: 'image_url', image_url: { url: `data:${mime};base64,${(await fs.promises.readFile(file)).toString('base64')}` } });
    } else {
      if (!/\.(txt|md|js|jsx|ts|tsx|json|html?|css|scss|py|sh|ps1|c|h|cpp|hpp|go|rs|java|sql|csv|tsv|log|yaml|yml|toml|xml|svg|vue|svelte|ini|rb|php|swift|dart|lua)$/i.test(ext)) throw new Error(`${path.basename(file)} needs a coding agent or a document extractor; direct chat cannot read this format.`);
      const text = await fs.promises.readFile(file, 'utf8'); chars += text.length;
      if (chars > cfg.attachmentMaxChars) throw new Error('Attachment text exceeds the context limit. Attach fewer/smaller files.');
      content.push({ type: 'text', text: `\n[Attached ${path.basename(file)}]\n${text}\n[End attachment]` });
    }
  }
  return content;
}
function historyWindow(messages, turns) {
  if (!turns) return [];
  let seen = 0, begin = 0;
  for (let i = messages.length - 1; i >= 0; i--) if (messages[i].role === 'user' && ++seen === turns) { begin = i; break; }
  return messages.slice(begin);
}
module.exports = function register({ app, ipcMain, safeStorage, getSettings, saveSettings, send, runtime, filePipeline }) {
  const secretFile = path.join(app.getPath('userData'), 'forge-secrets.json');
  const sessionFile = path.join(app.getPath('userData'), 'direct-sessions.json');
  const read = (file) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; } };
  const persist = (file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(value, null, 2), { mode: 0o600 }); fs.renameSync(tmp, file); };
  function getSecret(id) {
    const encrypted = read(secretFile)[id];
    if (!encrypted) return '';
    if (!safeStorage.isEncryptionAvailable()) throw new Error('OS credential encryption is unavailable.');
    return safeStorage.decryptString(Buffer.from(encrypted, 'base64'));
  }
  ipcMain.handle('integration:secret', (_e, id, value) => {
    if (!/^[\w.-]{1,100}$/.test(id)) throw new Error('Invalid secret reference.');
    const all = read(secretFile);
    if (value === null) delete all[id];
    else { if (!safeStorage.isEncryptionAvailable() || safeStorage.getSelectedStorageBackend?.() === 'basic_text') throw new Error('OS credential encryption is unavailable.'); all[id] = safeStorage.encryptString(String(value)).toString('base64'); }
    persist(secretFile, all); return true;
  });
  ipcMain.handle('integration:status', () => ({ secretRefs: Object.keys(read(secretFile)), config: config(getSettings()) }));
  const headers = (id) => { const key = getSecret(id); return key ? { authorization: `Bearer ${key}` } : {}; };
  ipcMain.handle('integration:models', async (_e, profileId) => {
    const cfg = config(getSettings()), p = cfg.profiles.find((x) => x.id === profileId);
    if (!p) throw new Error('Choose a provider profile first.');
    const t = Date.now();
    const r = await checkedFetch(endpoint(p.baseUrl, '/models'), { headers: headers('provider-' + p.id) });
    return { models: (await r.json()).data || [], latencyMs: Date.now() - t };
  });
  const sessions = read(sessionFile), active = new Map();
  const profile = () => { const cfg = config(getSettings()); const p = cfg.profiles.find((x) => x.id === cfg.activeProfile); if (!p) throw new Error('No active endpoint profile.'); return p; };
  const sessionConfig = (s) => ({ configOptions: [{ id: 'model', category: 'model', name: 'Model', type: 'select', currentValue: s.model, options: [{ value: s.model, name: s.model || 'Set model in Settings → Connections' }] }], modes: { currentModeId: s.mode || 'agent', availableModes: [{ id: 'agent', name: 'AGENT · local tools', description: 'Files, commands, devices and controlled browser through actual tools.' }, { id: 'ask', name: 'ASK · read only', description: 'Conversation and workspace inspection without mutation tools.' }] } });
  const notify = (sid, update) => send('acp:notify', 'native', 'session/update', { sessionId: sid, update });
  async function call(method, p = {}) {
    const cfg = config(getSettings());
    if (method === 'session/new') {
      const pro = profile(), id = crypto.randomUUID();
      sessions[id] = { sessionId: id, profileId: pro.id, model: pro.model || '', cwd: p.cwd, title: 'Direct model chat', updatedAt: new Date().toISOString(), messages: [] };
      persist(sessionFile, sessions); return { sessionId: id, ...sessionConfig(sessions[id]) };
    }
    if (method === 'session/list') return { sessions: Object.values(sessions).map(({ messages, ...s }) => s) };
    const s = sessions[p.sessionId]; if (!s) throw new Error('Direct chat session not found.');
    if (method === 'session/load') { for (const m of s.messages.filter(m => ['user', 'assistant'].includes(m.role) && m.content)) notify(s.sessionId, { sessionUpdate: m.role === 'user' ? 'user_message_chunk' : 'agent_message_chunk', messageId: crypto.randomUUID(), content: { type: 'text', text: Array.isArray(m.content) ? m.content.filter((x) => x.type === 'text').map((x) => x.text).join('\n') : m.content } }); return sessionConfig(s); }
    if (method === 'session/set_config_option') { s.model = String(p.value); persist(sessionFile, sessions); return sessionConfig(s); }
    if (method === 'session/set_mode') { if (!['ask', 'agent'].includes(p.modeId)) throw new Error('Unknown mode'); s.mode = p.modeId; persist(sessionFile, sessions); return {}; }
    if (method === 'session/close') { cancel(p.sessionId); return {}; }
    if (method === 'session/fork') { const id = crypto.randomUUID(); sessions[id] = { ...structuredClone(s), sessionId: id }; persist(sessionFile, sessions); return { sessionId: id }; }
    if (method !== 'session/prompt') throw new Error(`Direct chat does not support ${method}. Select an ACP coding agent for tools.`);
    if (active.has(s.sessionId)) throw new Error('This session already has a request running.');
    const pro = cfg.profiles.find((x) => x.id === s.profileId); if (!pro || !s.model) throw new Error('Set a model ID in Settings → Connections before sending.');
    const user = { role: 'user', content: await promptContent(p.prompt, pro, cfg, runtime && filePipeline ? { runtime, filePipeline } : null) };
    const abort = new AbortController(); active.set(s.sessionId, abort);
    const timer = setTimeout(() => { abort.abort(); runtime?.stop(); }, cfg.timeoutMs);
    const mid = crypto.randomUUID(); let text = '', finalReply = '', committed = false;
    try {
      const messages = [{ role: 'system', content: cfg.systemPrompt }, ...historyWindow(s.messages, cfg.historyTurns), user];
      const toolsEnabled = runtime && pro.tools !== false;
      let completed = false;
      for (let round = 0; round < (toolsEnabled ? 16 : 1); round++) {
        abort.signal.throwIfAborted();
        const r = await checkedFetch(endpoint(pro.baseUrl, '/chat/completions'), { method: 'POST', headers: { 'content-type': 'application/json', ...headers('provider-' + pro.id) }, signal: abort.signal,
          body: JSON.stringify({ model: s.model, messages, ...(toolsEnabled ? { tools: [{ type: 'function', function: { name: runtime.definition.name, description: runtime.definition.description, parameters: runtime.definition.inputSchema } }], tool_choice: 'auto' } : {}), stream: true, temperature: cfg.temperature, top_p: cfg.topP, max_tokens: cfg.maxTokens }) });
        if (!committed) { s.messages.push(user); committed = true; }
        let roundText = '', calls = [];
        const delta = part => {
          if (part.content) { text += part.content; roundText += part.content; notify(s.sessionId, { sessionUpdate: 'agent_message_chunk', messageId: mid, content: { type: 'text', text: part.content } }); }
          for (const item of part.tool_calls || []) {
            const index = item.index ?? calls.length, c = calls[index] ||= { id: '', type: 'function', function: { name: '', arguments: '' } };
            if (item.id) c.id = item.id;
            if (item.function?.name) c.function.name += item.function.name;
            if (item.function?.arguments) { c.function.arguments += item.function.arguments; if (c.function.arguments.length > 6 * 1048576) throw new Error('Model function arguments exceed 6 MB.'); }
          }
        };
        if (/text\/event-stream/i.test(r.headers.get('content-type') || '')) {
          for await (const j of sse(r.body)) { if (j.error) throw new Error(j.error.message || 'Stream failed'); delta(j.choices?.[0]?.delta || {}); }
        } else delta((await r.json()).choices?.[0]?.message || {});
        calls = calls.filter(Boolean);
        if (!calls.length) { if (!roundText) throw new Error('Provider returned no text response.'); completed = true; finalReply = roundText; break; }
        const assistant = { role: 'assistant', content: roundText || null, tool_calls: calls };
        messages.push(assistant); s.messages.push(assistant);
        const visualMessages = [];
        for (const tc of calls) {
          abort.signal.throwIfAborted();
          const id = tc.id || crypto.randomUUID(); tc.id = id;
          let result;
          notify(s.sessionId, { sessionUpdate: 'tool_call', toolCallId: id, title: tc.function.name, kind: 'other', status: 'in_progress' });
          try {
            if (tc.function.name !== 'forge_runtime') throw new Error('Unknown function');
            const args = JSON.parse(tc.function.arguments);
            const readOnly = ['system.inventory', 'devices.inventory', 'file.list', 'file.stat', 'file.read', 'desktop.windows', 'desktop.inspect', 'desktop.screenshot', 'browser.snapshot', 'browser.screenshot'];
            if (s.mode === 'ask' && !readOnly.includes(args.action)) throw new Error('Read-only mode does not allow this action.');
            result = await runtime.execute(args.action, args.args || {});
            notify(s.sessionId, { sessionUpdate: 'tool_call_update', toolCallId: id, status: 'completed', content: [{ type: 'content', content: { type: 'text', text: JSON.stringify(result).slice(0, 32000) } }] });
          } catch (e) { result = { error: e.message }; notify(s.sessionId, { sessionUpdate: 'tool_call_update', toolCallId: id, status: 'failed', content: [{ type: 'content', content: { type: 'text', text: e.message } }] }); }
          const visualPaths = result?.imagePath ? [result.imagePath] : (result?.screens || []).map(x => x.imagePath);
          const rawResult = JSON.stringify(result);
          if (rawResult.length > 64000) { const folder = path.join(app.getPath('userData'), 'runtime-logs'); fs.mkdirSync(folder, { recursive: true }); const resultPath = path.join(folder, crypto.randomUUID() + '.json'); fs.writeFileSync(resultPath, rawResult); result = { truncated: true, resultPath, preview: rawResult.slice(0, 16000), instruction: 'Complete result is on disk. Read it in bounded ranges; this is a preview.' }; }
          const reply = { role: 'tool', tool_call_id: id, content: JSON.stringify(result) }; messages.push(reply); s.messages.push(reply);
          if (pro.vision) for (const image of visualPaths.slice(0, 2)) {
            if (image?.endsWith('.png') && fs.existsSync(image) && fs.statSync(image).size < 10 * 1048576) visualMessages.push({ role: 'user', content: [{ type: 'text', text: 'Actual screenshot returned by the preceding runtime tool. Inspect it before acting; coordinate bounds are in the tool result.' }, { type: 'image_url', image_url: { url: 'data:image/png;base64,' + fs.readFileSync(image).toString('base64') } }] });
          }
        }
        messages.push(...visualMessages);
      }
      if (!completed) throw new Error('Local model tool limit reached (16 rounds). Inspect the actual tool results before continuing.');
      return { stopReason: 'end_turn' };
    } catch (e) { if (abort.signal.aborted) return { stopReason: 'cancelled' }; throw e; }
    finally { clearTimeout(timer); active.delete(s.sessionId); if (committed) { if (finalReply) s.messages.push({ role: 'assistant', content: finalReply }); s.title = (user.content.find((x) => x.type === 'text')?.text || s.title).slice(0, 70); s.updatedAt = new Date().toISOString(); persist(sessionFile, sessions); } }
  }
  function cancel(id) { active.get(id)?.abort(); }
  const speechJobs = new Map();
  ipcMain.on('voice:cancel', (_e, id) => speechJobs.get(id)?.abort());
  ipcMain.handle('voice:transcribe', async (_e, bytes, mime, id) => {
    const v = config(getSettings()).voice;
    if (!v.sttBase) throw new Error('Configure a transcription endpoint in Settings → Voice. Local Whisper servers work here.');
    if (bytes.byteLength > 25 * 1048576) throw new Error('Recording exceeds 25 MB.');
    const form = new FormData(); form.set('file', new Blob([bytes], { type: mime }), 'speech.' + (mime.includes('wav') ? 'wav' : 'webm')); form.set('model', v.sttModel); if (v.language) form.set('language', v.language);
    const ctrl = new AbortController(); speechJobs.set(id, ctrl); const timeout = setTimeout(() => ctrl.abort(), 120000);
    try { return (await (await checkedFetch(endpoint(v.sttBase, '/audio/transcriptions'), { method: 'POST', headers: headers('voice-stt'), body: form, signal: ctrl.signal })).json()).text || ''; }
    finally { clearTimeout(timeout); speechJobs.delete(id); }
  });
  ipcMain.handle('voice:speak', async (_e, text, id) => {
    const v = config(getSettings()).voice; if (!v.ttsBase) throw new Error('Configure a speech endpoint in Settings → Voice.');
    const ctrl = new AbortController(); speechJobs.set(id, ctrl); const timeout = setTimeout(() => ctrl.abort(), 120000);
    try { const r = await checkedFetch(endpoint(v.ttsBase, '/audio/speech'), { method: 'POST', headers: { 'content-type': 'application/json', ...headers('voice-tts') }, signal: ctrl.signal,
      body: JSON.stringify({ model: v.ttsModel, voice: v.voice, input: String(text).slice(0, 12000), response_format: 'mp3', speed: v.rate }) });
      return { bytes: await r.arrayBuffer(), mime: r.headers.get('content-type') || 'audio/mpeg' }; }
    finally { clearTimeout(timeout); speechJobs.delete(id); }
  });
  return { call, cancel, getSecret, stop: () => { for (const c of active.values()) c.abort(); for (const c of speechJobs.values()) c.abort(); } };
};
module.exports.endpoint = endpoint;
module.exports.sse = sse;
module.exports.promptContent = promptContent;
module.exports.config = config;
