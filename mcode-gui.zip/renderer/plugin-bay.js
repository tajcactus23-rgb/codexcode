// PLUGIN BAY — depth gallery for Plugins, Skills, Prompts, MCP servers and Connections.
// Structure after Houmahani Kane / Codrops "Atmospheric Depth Gallery" (MIT). Cards are drawn locally on canvases.
// Static backdrop; the stack only moves when you scroll. Card textures exist only near the current card (±3).
import * as THREE from "../node_modules/three/build/three.module.js";

const NEON = ["#2ad4ff", "#ff3fb4", "#b6ff3b", "#ffb020", "#8a7dff", "#3bffc4", "#ff6b5a", "#ffd23b"];
const hashI = (s) => { let x = 0; for (const c of String(s)) x = (x * 31 + c.charCodeAt(0)) >>> 0; return x; };
const accentOf = (s) => NEON[hashI(s) % NEON.length];
const moodOf = (hex) => { const n = parseInt(hex.slice(1), 16); const f = 0.09; return "#" + [n >> 16 & 255, n >> 8 & 255, n & 255].map((v) => Math.round(v * f).toString(16).padStart(2, "0")).join(""); };
const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, "");
const KNOWN_COST = { "cloudbase@official": 34.4, "chrome-devtools-mcp@official": 5.9 }; // measured tokens/request (K)
const GAP = 5, CAM_OFF = 4.2;
const clamp = THREE.MathUtils.clamp, lerp = THREE.MathUtils.lerp;

const B = { open: false, tab: "plugins", sub: "installed", q: "", items: [], data: {}, busy: false };

// ---------- DOM ----------
const root = document.createElement("div");
root.id = "pbay"; root.hidden = true;
root.innerHTML = `
  <canvas class="pb-gl"></canvas>
  <div class="pb-head">
    <b>⬢ PLUGIN BAY</b>
    <div class="pb-tabs"></div>
    <div class="pb-sub"></div>
    <div class="pb-grow"></div>
    <input class="pb-q" placeholder="search…">
    <button class="pb-x" title="Close (Esc)">✕</button>
  </div>
  <div class="pb-left"><div class="pb-idx">—</div><div class="pb-of"></div><div class="pb-rail"></div></div>
  <aside class="pb-spec"><h2></h2><div class="pb-id"></div><dl></dl><div class="pb-out"></div><div class="pb-acts"></div></aside>
  <div class="pb-empty" hidden></div>
  <div class="pb-hint">scroll or ↑ ↓ to move through the stack · Enter = main action</div>`;
document.body.append(root);
const q = (s) => root.querySelector(s);

const TABS = [["plugins", "PLUGINS"], ["skills", "SKILLS"], ["prompts", "PROMPTS"], ["mcp", "MCP SERVERS"], ["connections", "CONNECTIONS"]];
function renderTabs() {
  q(".pb-tabs").replaceChildren(...TABS.map(([k, t]) => {
    const b = document.createElement("button"); b.textContent = t; b.className = B.tab === k ? "on" : "";
    b.onclick = () => { B.tab = k; B.q = ""; q(".pb-q").value = ""; load(); }; return b;
  }));
  const sub = q(".pb-sub"); sub.replaceChildren();
  if (B.tab === "plugins") for (const [k, t] of [["installed", "INSTALLED"], ["available", "MARKETPLACE"]]) {
    const b = document.createElement("button"); b.textContent = t; b.className = B.sub === k ? "on" : "";
    b.onclick = () => { B.sub = k; build(); }; sub.append(b);
  }
}

// ---------- items per tab (real data only; unknown values shown as "—") ----------
function pluginItem(p) {
  const cap = p.capabilities || {}, cost = KNOWN_COST[p.pluginId];
  const lean = cost == null ? (cap.mcpServerCount ? null : true) : cost <= 3;
  return { kind: "plugin", id: p.pluginId, title: p.displayName || p.name, sub: `${p.pluginId} · v${p.version || "?"} · ${p.author || ""}`,
    desc: p.description || "", accent: accentOf(p.pluginId), on: p.installed ? !!p.enabled : null, installed: !!p.installed,
    stats: [["◆ SKILLS", cap.skillCount ?? "—"], ["⚙ MCP SERVERS", cap.mcpServerCount ?? "—"], ["▣ APPS", cap.appCount ?? "—"]],
    meter: { label: "CONTEXT COST / REQUEST", value: cost, text: cost == null ? "not measured" : cost + "K tok" },
    tag: !p.installed ? { t: "NOT INSTALLED", lv: "dim" } : !p.enabled ? { t: "DISABLED", lv: "mid" } : lean === true ? { t: "LEAN ✓ LOCAL-SAFE", lv: "ok" } : lean === false ? { t: "FULL · CLOUD ONLY", lv: "bad" } : { t: "MCP · COST UNMEASURED", lv: "mid" },
    rows: [["STATUS", p.installed ? (p.enabled ? "ENABLED" : "DISABLED") : "NOT INSTALLED"], ["SKILLS", cap.skillCount ?? "—"], ["MCP SERVERS", cap.mcpServerCount ?? "—"],
      ["APPS", cap.appCount ?? "—"], ["CONTEXT COST", cost == null ? "not measured" : cost + "K tokens / request"], ["MARKETPLACE", p.marketplaceName || "—"], ["AUTHOR", p.author || "—"]],
    actions: p.installed ? [[p.enabled ? "DISABLE" : "ENABLE", () => pluginAct(p.enabled ? "disable" : "enable", p.pluginId)], ["REMOVE", () => pluginAct("remove", p.pluginId)]]
      : [["INSTALL", () => pluginAct("add", p.pluginId)]] };
}
function skillItem(c) {
  const [plugin, name] = c.name.includes(":") ? c.name.split(":") : ["built-in", c.name];
  return { kind: "skill", id: c.name, title: "/" + name, sub: plugin, desc: (c.description || "No description.").replace(/\s+/g, " "), accent: accentOf(plugin),
    stats: [["SOURCE", plugin.slice(0, 14)], ["TAKES INPUT", c.input?.hint ? "YES" : "NO"], ["TYPE", plugin === "built-in" ? "CORE" : "SKILL"]],
    meter: null, tag: { t: "SLASH COMMAND", lv: "ok" },
    rows: [["COMMAND", "/" + c.name], ["FROM", plugin], ["INPUT", c.input?.hint || "none"]],
    actions: [["USE IN CHAT", () => { const p = document.getElementById("prompt"); p.value = "/" + c.name + " "; close(); p.focus(); }]] };
}
function promptItem(s, i) {
  return { kind: "prompt", id: "snip-" + i, title: s.name, sub: "your snippet", desc: s.text.replace(/\s+/g, " "), accent: accentOf(s.name),
    stats: [["WORDS", s.text.split(/\s+/).filter(Boolean).length], ["CHARS", s.text.length], ["LINES", s.text.split("\n").length]],
    meter: null, tag: { t: "PROMPT SNIPPET", lv: "ok" },
    rows: [["NAME", s.name], ["LENGTH", s.text.length + " chars"]],
    actions: [["USE IN CHAT", () => { const p = document.getElementById("prompt"); p.value = s.text; close(); p.focus(); }],
      ["DELETE", async () => { await saveSettings({ snippets: (S.snippets || []).filter((_, j) => j !== i) }); load(); }]] };
}
function mcpItem(p) {
  const it = pluginItem(p);
  return { ...it, kind: "mcp", title: (p.displayName || p.name) + " MCP", tag: p.enabled ? { t: "ATTACHED TO SESSIONS", lv: "ok" } : { t: "DETACHED", lv: "mid" } };
}
function providerItem(p) {
  const models = p.models || [];
  return { kind: "connection", id: p.providerId, title: p.name, sub: `${p.providerId} · ${p.kind}`, accent: accentOf(p.providerId),
    desc: p.kind === "custom" ? `Custom OpenAI-compatible endpoint with ${models.length} model${models.length === 1 ? "" : "s"}.` : "MiniMax account connection.",
    on: p.readOnly ? null : null,
    stats: [["MODELS", models.length], ["ACTIVE", p.active ? "YES" : "NO"], ["API KEY", p.hasApiKey ? "SET" : p.kind === "custom" ? "ENV" : "NONE"]],
    meter: null, tag: p.active ? { t: "ACTIVE SOURCE", lv: "ok" } : p.enabled ? { t: "ENABLED", lv: "ok" } : { t: "DISABLED", lv: "mid" },
    rows: [["PROVIDER", p.providerId], ["KIND", p.kind], ["MODELS", models.slice(0, 6).map((m) => m.id || m.name || m).join(", ") || "—"], ["READ-ONLY", p.readOnly ? "YES" : "NO"]],
    actions: [["TEST", async () => { setOut("testing " + p.providerId + "…"); try { const r = await api.bayProviderTest(p.providerId); setOut(JSON.stringify(r).slice(0, 300)); } catch (e) { setOut("✗ " + errText(e)); } }]] };
}

async function load() {
  const tab = B.tab; B.loading = true; renderTabs(); B.items = []; build();
  try {
    if (tab === "plugins" || tab === "mcp") B.data.plugins = await api.bayPlugins();
    if (tab === "connections") B.data.providers = await api.bayProviders();
  } catch (e) { B.loading = false; return showEmpty("✗ " + errText(e)); }
  B.loading = false;
  if (tab === B.tab) build();
}
function build() {
  renderTabs();
  let list = [];
  if (B.tab === "plugins") list = ((B.data.plugins || {})[B.sub] || []).map(pluginItem);
  else if (B.tab === "mcp") list = [...((B.data.plugins || {}).installed || [])].filter((p) => (p.capabilities || {}).mcpServerCount > 0).map(mcpItem);
  else if (B.tab === "skills") list = (window.cur?.commands || (typeof cur !== "undefined" && cur?.commands) || []).map(skillItem);
  else if (B.tab === "prompts") list = (S.snippets || []).map(promptItem);
  else if (B.tab === "connections") list = ((B.data.providers || {}).providers || []).map(providerItem);
  const ql = B.q.toLowerCase();
  if (ql) list = list.filter((it) => (it.title + " " + it.sub + " " + it.desc).toLowerCase().includes(ql));
  B.items = list;
  if (!list.length && B.loading) showEmpty("loading " + B.tab + "…");
  else if (!list.length) showEmpty(B.tab === "skills" ? "No skills loaded yet: start a chat session first, then reopen." : "Nothing here.");
  else q(".pb-empty").hidden = true;
  rebuildStack();
}
function showEmpty(t) { const e = q(".pb-empty"); e.hidden = false; e.textContent = t; }
function setOut(t) { q(".pb-out").textContent = t; }
async function pluginAct(action, id) {
  if (B.busy) return; B.busy = true; setOut(`${action} ${id}…`);
  try { await api.bayPluginAction(action, id); setOut(`✓ ${action} ${id} — engine restarts on your next message`); B.data.plugins = await api.bayPlugins(); build(); }
  catch (e) { setOut("✗ " + errText(e)); }
  finally { B.busy = false; }
}

// ---------- card art (2x canvas, mipmaps + max anisotropy: crisp) ----------
function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function hexA(h, a) { const n = parseInt(h.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; }
function wrap(g, text, x, y, w, lh, max) {
  const words = String(text).split(" "); let line = "", n = 0;
  for (const wd of words) { const t = line ? line + " " + wd : wd; if (g.measureText(t).width > w && line) { if (n === max - 1) { g.fillText(line + "…", x, y + n * lh); return; } g.fillText(line, x, y + n * lh); line = wd; n++; } else line = t; }
  g.fillText(line, x, y + n * lh);
}
function fit(g, text, maxW) { let t = String(text); while (g.measureText(t).width > maxW && t.length > 3) t = t.slice(0, -2); return t === String(text) ? t : t + "…"; }
const LV = { ok: "#3bff9a", mid: "#ffb020", bad: "#ff4a5a", dim: "#7f93a8" };
function cardTexture(it, aniso) {
  const W = 1280, H = 820, c = document.createElement("canvas"); c.width = W; c.height = H; const g = c.getContext("2d"), a = it.accent;
  const dim = it.on === false || it.installed === false;
  g.fillStyle = "#060b16"; rr(g, 0, 0, W, H, 36); g.fill();
  const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, hexA(a, 0.2)); gr.addColorStop(0.5, "rgba(0,0,0,0)"); g.fillStyle = gr; rr(g, 0, 0, W, H, 36); g.fill();
  g.lineWidth = 5; g.strokeStyle = dim ? hexA(a, 0.45) : a; rr(g, 4, 4, W - 8, H - 8, 32); g.stroke();
  // badge
  const k = 33; g.beginPath(); g.moveTo(70 + k, 70); g.lineTo(220 - k, 70); g.lineTo(220, 70 + k); g.lineTo(220, 220 - k); g.lineTo(220 - k, 220); g.lineTo(70 + k, 220); g.lineTo(70, 220 - k); g.lineTo(70, 70 + k); g.closePath(); g.fillStyle = a; g.fill();
  g.fillStyle = "#03060d"; g.font = "800 58px Consolas"; g.textAlign = "center"; g.textBaseline = "middle";
  g.fillText(it.title.replace(/^\//, "").split(/[\s_-]+/).map((w) => w[0] || "").join("").slice(0, 2).toUpperCase() || "?", 145, 147);
  g.textAlign = "left"; g.textBaseline = "alphabetic";
  g.fillStyle = "#f3faff"; g.font = "800 62px Segoe UI, sans-serif"; g.fillText(fit(g, it.title, it.on == null ? W - 330 : W - 480), 255, 128);
  g.fillStyle = "#7f93a8"; g.font = "500 28px Consolas"; g.fillText(fit(g, it.sub, W - 340), 258, 178);
  if (it.on != null) { const sx = W - 210, sy = 78; g.fillStyle = it.on ? "#0a2a1a" : "#0d1626"; rr(g, sx, sy, 140, 70, 35); g.fill(); g.lineWidth = 4; g.strokeStyle = it.on ? "#3bff9a" : "#2a3a52"; rr(g, sx, sy, 140, 70, 35); g.stroke();
    g.fillStyle = it.on ? "#3bff9a" : "#3a4a60"; g.beginPath(); g.arc(it.on ? sx + 105 : sx + 35, sy + 35, 24, 0, Math.PI * 2); g.fill(); }
  g.fillStyle = "#a9bdd2"; g.font = "400 34px Segoe UI, sans-serif"; wrap(g, it.desc, 72, 290, W - 144, 46, 3);
  it.stats.forEach(([kk, v], j) => { const x = 72 + j * 380; g.lineWidth = 3; g.strokeStyle = hexA(a, 0.6); rr(g, x, 470, 350, 110, 14); g.stroke();
    g.fillStyle = "#7f93a8"; g.font = "600 26px Consolas"; g.fillText(kk, x + 22, 512); g.fillStyle = "#f3faff"; g.font = "800 44px Consolas"; g.fillText(fit(g, v, 310), x + 22, 562); });
  if (it.meter) {
    const m = it.meter, segs = 24, lit = m.value == null ? 0 : Math.min(segs, Math.max(1, Math.round(m.value / 1.8)));
    const col = m.value == null ? "#1c2a40" : m.value > 10 ? LV.bad : m.value > 3 ? LV.mid : LV.ok;
    g.fillStyle = "#7f93a8"; g.font = "600 26px Consolas"; g.fillText(m.label, 72, 650);
    for (let s = 0; s < segs; s++) { g.fillStyle = s < lit ? col : "#141f33"; g.fillRect(72 + s * 36, 672, 30, 34); }
    g.fillStyle = m.value == null ? "#7f93a8" : col; g.font = "800 38px Consolas"; g.textAlign = "right"; g.fillText(m.text, W - 72, 705); g.textAlign = "left";
  }
  g.font = "700 26px Consolas"; const tw = g.measureText(it.tag.t).width + 36, tc = LV[it.tag.lv] || LV.dim;
  g.lineWidth = 3; g.strokeStyle = tc; rr(g, 72, 740, tw, 50, 8); g.stroke(); g.fillStyle = tc; g.fillText(it.tag.t, 90, 774);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = aniso; t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter;
  return t;
}

// ---------- three.js stack ----------
const canvas = q(".pb-gl");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(devicePixelRatio || 1); renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.autoClear = false;
const aniso = renderer.capabilities.getMaxAnisotropy();
const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
const geo = new THREE.PlaneGeometry(3.2, 2.05);
const bgScene = new THREE.Scene(), bgCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
const bgMat = new THREE.ShaderMaterial({ depthTest: false, depthWrite: false,
  uniforms: { uMood: { value: new THREE.Color("#04070f") }, uAcc: { value: new THREE.Color("#2ad4ff") }, uRes: { value: new THREE.Vector2(1, 1) }, uDepth: { value: 0 } },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.,1.); }`,
  fragmentShader: `varying vec2 vUv; uniform vec3 uMood,uAcc; uniform vec2 uRes; uniform float uDepth;
    float line(float x,float w){ float d=abs(fract(x)-.5); float aa=fwidth(x); return 1.-smoothstep(w-aa,w+aa,.5-d); }
    void main(){ vec2 p=vUv*uRes/90.; p.y+=uDepth*3.; vec3 c=uMood; float gl=max(line(p.x,.012),line(p.y,.012));
      c=mix(c,uAcc,gl*.16); float vg=smoothstep(1.1,.2,length(vUv-.5)*1.6); c*=.55+.45*vg; gl_FragColor=vec4(c,1.); }` });
bgScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), bgMat));

let planes = [], scrollT = 0, scrollC = 0, maxScroll = 0, dirty = true;
const F = 0.01, startZ = CAM_OFF;
function rebuildStack() {
  for (const p of planes) { p.material.map?.dispose(); p.material.dispose(); scene.remove(p); }
  planes = B.items.map((it, i) => { const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, opacity: 0 }));
    m.position.set(i % 2 ? 0.55 : -0.55, 0, -i * GAP); m.userData = { it, baseX: m.position.x, tex: false }; scene.add(m); return m; });
  maxScroll = Math.max(0, (planes.length - 1) * GAP) / F; scrollT = scrollC = 0; shown = -1;
  q(".pb-rail").replaceChildren(...B.items.slice(0, 60).map(() => document.createElement("i")));
  dirty = true;
}
function ensureTextures(ci) {
  planes.forEach((m, i) => {
    const near = Math.abs(i - ci) <= 3;
    if (near && !m.userData.tex) { m.material.map = cardTexture(m.userData.it, aniso); m.material.needsUpdate = true; m.userData.tex = true; }
    else if (!near && m.userData.tex) { m.material.map.dispose(); m.material.map = null; m.material.needsUpdate = true; m.userData.tex = false; }
  });
}
let shown = -1;
function spec(i) {
  if (i === shown || !B.items[i]) return; shown = i; const it = B.items[i];
  root.style.setProperty("--acc", it.accent);
  q(".pb-idx").textContent = String(i + 1).padStart(2, "0"); q(".pb-of").textContent = `of ${B.items.length}`;
  [...q(".pb-rail").children].forEach((e, k) => e.classList.toggle("on", k === Math.min(i, 59)));
  q(".pb-spec h2").textContent = it.title; q(".pb-id").textContent = it.sub;
  q(".pb-spec dl").replaceChildren(...it.rows.map(([k, v]) => { const d = document.createElement("div"); d.className = "row"; const dt = document.createElement("dt"); dt.textContent = k; const dd = document.createElement("dd"); dd.textContent = v; d.append(dt, dd); return d; }));
  q(".pb-acts").replaceChildren(...it.actions.map(([t, fn], k) => { const b = document.createElement("button"); b.textContent = t; if (!k) b.className = "main"; b.onclick = fn; return b; }));
  setOut("");
}
function resize() { const w = canvas.clientWidth, h = canvas.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); bgMat.uniforms.uRes.value.set(w, h); dirty = true; }
new ResizeObserver(resize).observe(canvas);
const moodA = new THREE.Color(), moodB = new THREE.Color(), accA = new THREE.Color(), accB = new THREE.Color();
let raf = 0;
function frame() {
  raf = B.open ? requestAnimationFrame(frame) : 0; if (!B.open) return;
  const prev = scrollC; scrollC = lerp(scrollC, scrollT, 0.1); if (Math.abs(scrollC - scrollT) < 0.05) scrollC = scrollT;
  const moving = scrollC !== prev;
  let fading = false;
  camera.position.z = startZ - scrollC * F;
  const n = planes.length;
  const nd = n ? clamp(-(camera.position.z - CAM_OFF) / GAP, 0, n - 1) : 0, ci = Math.floor(nd), ni = Math.min(ci + 1, Math.max(n - 1, 0)), bl = nd - ci;
  if (n) {
    ensureTextures(Math.round(nd));
    planes.forEach((m, i) => { let t = 0; if (i === ci) t = 1 - bl; if (i === ni) t = Math.max(t, bl); const o = lerp(m.material.opacity, t, 0.18); if (Math.abs(o - t) > 0.002) fading = true; m.material.opacity = Math.abs(o - t) <= 0.002 ? t : o; m.visible = m.material.opacity > 0.002; });
    const A = B.items[ci], N = B.items[ni];
    moodA.set(moodOf(A.accent)).lerp(moodB.set(moodOf(N.accent)), bl); accA.set(A.accent).lerp(accB.set(N.accent), bl);
    bgMat.uniforms.uMood.value.copy(moodA); bgMat.uniforms.uAcc.value.copy(accA); bgMat.uniforms.uDepth.value = nd;
    spec(bl >= 0.5 ? ni : ci);
  }
  if (!(moving || fading || dirty)) return; // nothing changed: draw nothing (static)
  dirty = false;
  renderer.clear(); renderer.render(bgScene, bgCam); renderer.clearDepth(); renderer.render(scene, camera);
}
canvas.addEventListener("wheel", (e) => { e.preventDefault(); scrollT = clamp(scrollT + e.deltaY * (e.deltaMode === 1 ? 16 : 1), 0, maxScroll); }, { passive: false });
const step = (d) => { const cur = Math.round(scrollT * F / GAP); scrollT = clamp((cur + d) * GAP / F, 0, maxScroll); };
addEventListener("keydown", (e) => {
  if (!B.open || e.target.tagName === "INPUT") return;
  if (e.key === "Escape") close(); else if (e.key === "ArrowDown" || e.key === "PageDown") { step(1); e.preventDefault(); }
  else if (e.key === "ArrowUp" || e.key === "PageUp") { step(-1); e.preventDefault(); }
  else if (e.key === "Enter") { const it = B.items[shown]; it?.actions[0]?.[1](); }
});
q(".pb-q").addEventListener("input", (e) => { B.q = e.target.value; build(); });
q(".pb-x").onclick = () => close();

function open(tab) { if (tab) B.tab = tab; root.hidden = false; B.open = true; window.__bayOpen = true; dirty = true; resize(); load(); if (!raf) raf = requestAnimationFrame(frame); }
function close() { root.hidden = true; B.open = false; window.__bayOpen = false; }
window.openPluginBay = open;
