const os = require('node:os');

// Delta counters represent actual sampled host utilisation, not a decorative waveform.
function createSampler() {
  let previous = os.cpus().map(cpu => ({ ...cpu.times }));
  return () => {
    const cpus = os.cpus();
    const cores = cpus.map((cpu, i) => {
      const old = previous[i];
      if (!old) return null;
      const total = Object.keys(cpu.times).reduce((n, k) => n + Math.max(0, cpu.times[k] - old[k]), 0);
      return total ? Math.max(0, Math.min(100, 100 * (1 - (cpu.times.idle - old.idle) / total))) : null;
    });
    previous = cpus.map(cpu => ({ ...cpu.times }));
    const measured = cores.filter(n => n !== null);
    const total = os.totalmem(), free = os.freemem();
    return { at: Date.now(), cpuPercent: measured.length ? measured.reduce((a, b) => a + b, 0) / measured.length : null, cores, cpuModel: cpus[0]?.model || 'Unknown CPU', memory: { total, free, used: total - free, percent: (total - free) / total * 100 }, uptime: os.uptime(), processBytes: process.memoryUsage().rss, hostname: os.hostname() };
  };
}
module.exports = { createSampler };
