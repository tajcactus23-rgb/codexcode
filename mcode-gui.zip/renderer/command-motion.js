import * as THREE from '../node_modules/three/build/three.module.js';

// Original command-centre scenes. The CODE deck's motion modules are independent.
const state = { paused: matchMedia('(prefers-reduced-motion: reduce)').matches, ready: false, error: null, fps: 0 };
const pageVisible = id => !document.hidden && !window.__bayOpen && document.getElementById(id)?.classList.contains('on');
const mission = () => pageVisible('page-mission'), gallery = () => pageVisible('page-showcase');
const effects = []; let energy = .25, targetEnergy = .25, pulse = 0, paletteShift = 0;
function mount(name, fn) { try { effects.push(fn()); } catch (e) { state.error = name + ': ' + e.message; const warning = document.createElement('div'); warning.className = 'mc-motion-warning'; warning.textContent = 'Motion renderer unavailable: ' + name + '. Enable hardware acceleration.'; document.getElementById('mc-scene')?.parentElement.append(warning); } }
const vertex = 'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
const fragment = `
 precision highp float;
 varying vec2 vUv;
 uniform vec2 uRes,uPointer;uniform float uTime,uEnergy,uPulse,uMode,uHue;
 mat2 rot(float a){return mat2(cos(a),-sin(a),sin(a),cos(a));}
 float torus(vec3 p,vec2 r){return length(vec2(length(p.xz)-r.x,p.y))-r.y;}
 float smin(float a,float b,float k){float h=clamp(.5+.5*(b-a)/k,0.,1.);return mix(b,a,h)-k*h*(1.-h);}
 float shape(vec3 p){
   p.xz=rot(uTime*.19+uPointer.x*.32)*p.xz;
   p.yz=rot(.28+uPointer.y*.2+sin(uTime*.17)*.15)*p.yz;
   if(uMode>.5){
     float d=10.;
     for(int i=0;i<5;i++){float f=float(i);vec3 c=vec3(sin(uTime*.38+f*2.4)*.6,cos(uTime*.29+f*3.1)*.5,sin(uTime*.33+f)*.25);d=smin(d,length(p-c)-(.28+.05*sin(uTime+f)),.25);}
     return d;
   }
   vec3 q=p;
   float gyroid=abs(dot(sin(q*3.4+uTime*.27),cos(q.zxy*3.4-uTime*.16)))/3.4-.18;
   float sphere=length(p)-(.96+.035*sin(uTime*1.3)+uPulse*.03);
   float inner=max(sphere,gyroid);
   vec3 a=p;a.xy=rot(uTime*.31)*a.xy;
   float hoop=torus(a,vec2(1.22,.026));
   a=p;a.yz=rot(1.05+uTime*.12)*a.yz;
   hoop=min(hoop,torus(a,vec2(1.14,.031)));
   return min(inner,hoop);
 }
 vec3 normalAt(vec3 p){vec2 e=vec2(.0015,0);return normalize(vec3(shape(p+e.xyy)-shape(p-e.xyy),shape(p+e.yxy)-shape(p-e.yxy),shape(p+e.yyx)-shape(p-e.yyx)));}
 vec3 spectrum(float t){return .55+.45*cos(6.28318*(vec3(.0,.32,.63)+t));}
 void main(){
   vec2 uv=(vUv-.5)*vec2(uRes.x/uRes.y,1.);
   vec3 ro=vec3(0,0,3.7),rd=normalize(vec3(uv*3.4,-3.0));
   // Analytic bounding sphere skips empty pixels and the space before the object.
   float b=dot(ro,rd),c=dot(ro,ro)-1.85,h=b*b-c;
   if(h<0.){gl_FragColor=vec4(0.);return;}
   float travel=max(0.,-b-sqrt(h)),end=-b+sqrt(h),distance=0.;bool hit=false;
   for(int i=0;i<64;i++){distance=shape(ro+rd*travel);if(distance<.0014){hit=true;break;}travel+=distance*.85;if(travel>end)break;}
   vec3 col=vec3(0.);float alpha=0.;
   if(hit){
     vec3 p=ro+rd*travel,n=normalAt(p),v=-rd;
     vec3 l=normalize(vec3(-.4,.7,1.)),l2=normalize(vec3(.8,-.2,.6));
     float fres=pow(1.-max(dot(n,v),0.),2.1),spec=pow(max(dot(reflect(-l,n),v),0.),95.);
     float spec2=pow(max(dot(reflect(-l2,n),v),0.),65.);
     vec3 metal=spectrum(p.y*.11+p.x*.17+uTime*.04+uHue);
     float bands=.5+.5*sin(n.y*9.+n.x*6.+uTime*.6);
     vec3 reflection=mix(vec3(.018,.045,.08),vec3(.55,.92,1.),smoothstep(.4,.55,bands));
     col=metal*(.05+max(dot(n,l),0.)*.26)+reflection*.3;
     col+=fres*mix(vec3(.03,.93,1.),vec3(1.,.07,.55),.5+.5*sin(p.y*3.+uTime*.3))*(1.1+uEnergy*.4);
     col+=spec*vec3(2.6,2.8,3.)+spec2*vec3(1.4,.9,.38);
     col+=metal*uPulse*.06;
     col=vec3(1.)-exp(-col*1.25);alpha=1.;
   }
   float glow=exp(-length(uv)*5.)*.04;col+=vec3(.04,.6,1.)*glow;
   gl_FragColor=vec4(col,max(alpha,glow));
 }`;
function phaseShader(canvas, active, mode) {
  let dirty = true;
  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, premultipliedAlpha: false });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  const uniforms = { uRes: { value: new THREE.Vector2(1, 1) }, uPointer: { value: new THREE.Vector2() }, uTime: { value: 0 }, uEnergy: { value: .25 }, uPulse: { value: 0 }, uMode: { value: mode }, uHue: { value: 0 } };
  const scene = new THREE.Scene(), camera = new THREE.Camera();
  const material = new THREE.ShaderMaterial({ uniforms, vertexShader: vertex, fragmentShader: fragment, transparent: true, depthTest: false });
  scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material));
  new ResizeObserver(() => { renderer.setSize(canvas.clientWidth || 1, canvas.clientHeight || 1, false); renderer.getDrawingBufferSize(uniforms.uRes.value); dirty = true; }).observe(canvas);
  canvas.addEventListener('pointermove', e => { const r = canvas.getBoundingClientRect(); uniforms.uPointer.value.set((e.clientX - r.left) / r.width * 2 - 1, 1 - (e.clientY - r.top) / r.height * 2); });
  canvas.addEventListener('pointerdown', () => { pulse = 1.7; });
  let last = performance.now(), time = 0;
  renderer.setAnimationLoop(now => {
    const dt = Math.min(.05, (now - last) / 1000); last = now;
    if (!active() || !canvas.getClientRects().length || state.paused && !dirty && +canvas.dataset.frames > 0) return;
    if (!state.paused) time += dt;
    uniforms.uTime.value = time; uniforms.uEnergy.value = energy; uniforms.uPulse.value = pulse; uniforms.uHue.value = paletteShift;
    renderer.render(scene, camera); dirty = false; canvas.dataset.frames = String((+canvas.dataset.frames || 0) + 1);
  });
  return { renderer };
}
mount('Chrome phase core', () => phaseShader(document.getElementById('mc-crystal'), mission, 0));
mount('Liquid alloy', () => phaseShader(document.getElementById('mc-fluid'), mission, 1));

mount('Orbital architecture', () => {
  let dirty = true;
  const canvas = document.getElementById('mc-scene'), renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(48, 1, .1, 100);
  camera.position.set(0, 7, 12); camera.lookAt(0, 0, 0);
  const group = new THREE.Group(); scene.add(group);
  const colors = ['#2eeaff', '#ff38c6', '#c8ff66', '#ffa341'];
  const grid = new THREE.GridHelper(25, 30, '#29c5dd', '#182940'); grid.position.y = -1.8; scene.add(grid); grid.material.transparent = true; grid.material.opacity = .22;
  const rings = [];
  for (let i = 0; i < 5; i++) { const ring = new THREE.Mesh(new THREE.TorusGeometry(3.6 + i * .55, .013, 5, 160, Math.PI * (1.5 + i * .06)), new THREE.MeshBasicMaterial({ color: colors[i % 4], transparent: true, opacity: .42, blending: THREE.AdditiveBlending })); ring.rotation.x = Math.PI / 2; ring.position.y = -1.6 + i * .06; group.add(ring); rings.push(ring); }
  const count = 380, pos = new Float32Array(count * 3), cols = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) { const a = Math.random() * 6.28, r = 4 + Math.random() * 7; pos.set([Math.cos(a) * r, Math.random() * 4 - 1.5, Math.sin(a) * r], i * 3); const c = new THREE.Color(colors[i % 4]); cols.set([c.r, c.g, c.b], i * 3); }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(cols, 3));
  const particles = new THREE.Points(g, new THREE.PointsMaterial({ size: .04, vertexColors: true, transparent: true, opacity: .85, blending: THREE.AdditiveBlending, depthWrite: false })); scene.add(particles);
  const beacons = [];
  for (let i = 0; i < 12; i++) { const b = new THREE.Mesh(new THREE.OctahedronGeometry(.055), new THREE.MeshBasicMaterial({ color: colors[i % 4] })); scene.add(b); beacons.push(b); }
  new ResizeObserver(() => { renderer.setSize(canvas.clientWidth || 1, canvas.clientHeight || 1, false); camera.aspect = (canvas.clientWidth || 1) / (canvas.clientHeight || 1); camera.updateProjectionMatrix(); dirty = true; }).observe(canvas);
  let frames = 0, last = performance.now(), previous = last, time = 0;
  renderer.setAnimationLoop(now => {
    const dt = Math.min(.05, (now - previous) / 1000); previous = now;
    if (!mission() || state.paused && !dirty && +canvas.dataset.frames > 0) { frames = 0; last = now; return; }
    energy += (targetEnergy - energy) * .04; pulse *= .95; if (!state.paused) time += dt;
    rings.forEach((r, i) => { r.rotation.z = time * (i % 2 ? -.16 : .11) * (i + 1); }); particles.rotation.y = time * .025;
    beacons.forEach((b, i) => { const a = time * (.1 + i % 3 * .05) + i * .53, r = 3.6 + i % 5 * .55; b.position.set(Math.sin(a) * r, -.7 + Math.cos(a * 1.3) * .5, Math.cos(a) * r); b.rotation.y = time; });
    camera.position.x = Math.sin(time * .12) * .5; camera.lookAt(0, 0, 0); renderer.render(scene, camera);
    dirty = false; canvas.dataset.frames = String((+canvas.dataset.frames || 0) + 1); frames++;
    if (now - last >= 1000) { state.fps = Math.round(frames * 1000 / (now - last)); frames = 0; last = now; document.getElementById('mc-fps').textContent = state.fps + ' FPS'; }
  });
  return { renderer };
});
// A new steering field: paired species orbit a moving attractor and separate on proximity.
function swarm(canvas, active, count, showcase = false) {
  let dirty = true;
  const ctx = canvas.getContext('2d'), pointer = { x: -10, y: -10 };
  const dots = Array.from({ length: count }, (_, i) => ({ x: Math.random(), y: Math.random(), vx: (Math.random() - .5) * .07, vy: (Math.random() - .5) * .07, kind: i % 3 }));
  let width = 1, height = 1, ratio = 1, previous = performance.now(), time = 0;
  new ResizeObserver(() => { width = canvas.clientWidth || 1; height = canvas.clientHeight || 1; ratio = Math.min(2, devicePixelRatio); canvas.width = width * ratio; canvas.height = height * ratio; ctx.setTransform(ratio, 0, 0, ratio, 0, 0); dirty = true; }).observe(canvas);
  canvas.parentElement.addEventListener('pointermove', e => { const r = canvas.getBoundingClientRect(); pointer.x = (e.clientX - r.left) / r.width; pointer.y = (e.clientY - r.top) / r.height; });
  canvas.parentElement.addEventListener('pointerleave', () => { pointer.x = -10; });
  function frame(now) {
    const dt = Math.min(.04, (now - previous) / 1000); previous = now;
    if (active() && canvas.getClientRects().length && (!state.paused || dirty || !+canvas.dataset.frames)) {
      if (!state.paused) time += dt;
      ctx.fillStyle = showcase ? 'rgba(5,8,18,.2)' : 'rgba(5,12,23,.19)'; ctx.fillRect(0, 0, width, height);
      const aim = { x: .5 + Math.sin(time * .3) * .3, y: .5 + Math.cos(time * .23) * .27 };
      for (const b of dots) {
        let sx = 0, sy = 0, ax = 0, ay = 0, cx = 0, cy = 0, neighbors = 0;
        for (const o of dots) { if (o === b) continue; const dx = b.x - o.x, dy = b.y - o.y, d = dx * dx + dy * dy; if (d < .012) { ax += o.vx; ay += o.vy; cx += o.x; cy += o.y; neighbors++; if (d < .0016) { sx += dx / Math.max(.0001, d); sy += dy / Math.max(.0001, d); } } }
        const repel = (b.x - pointer.x) ** 2 + (b.y - pointer.y) ** 2;
        b.vx += dt * ((aim.x - b.x) * .12 + sx * .0015 + (neighbors ? (ax / neighbors - b.vx) * .5 + (cx / neighbors - b.x) * .18 : 0));
        b.vy += dt * ((aim.y - b.y) * .12 + sy * .0015 + (neighbors ? (ay / neighbors - b.vy) * .5 + (cy / neighbors - b.y) * .18 : 0));
        if (repel < .02) { b.vx += dt * (b.x - pointer.x) * 1.3; b.vy += dt * (b.y - pointer.y) * 1.3; }
        const speed = Math.hypot(b.vx, b.vy), max = showcase ? .04 : .13; if (speed > max) { b.vx *= max / speed; b.vy *= max / speed; }
        if (!state.paused) { b.x = (b.x + b.vx * dt + 1) % 1; b.y = (b.y + b.vy * dt + 1) % 1; }
        const x = b.x * width, y = b.y * height, color = ['#7dffff', '#fe4abb', '#d2ff66'][b.kind]; ctx.fillStyle = color; ctx.shadowColor = color; ctx.shadowBlur = showcase ? 4 : 8;
        ctx.save(); ctx.translate(x, y); ctx.rotate(Math.atan2(b.vy * height, b.vx * width)); ctx.beginPath(); ctx.moveTo(5, 0); ctx.lineTo(-3, 2.1); ctx.lineTo(-1, 0); ctx.lineTo(-3, -2.1); ctx.closePath(); ctx.fill(); ctx.restore();
      }
      ctx.shadowBlur = 0; dirty = false; canvas.dataset.frames = String((+canvas.dataset.frames || 0) + 1);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame); return {};
}
mount('Steering field', () => swarm(document.getElementById('mc-flock'), mission, 65));
mount('Gallery constellation', () => swarm(document.getElementById('sc-flock'), gallery, 65, true));
function applyPause() { document.querySelectorAll('.mc-page').forEach(p => p.classList.toggle('motion-paused', state.paused)); const b = document.getElementById('mc-motion'); if (b) { b.textContent = state.paused ? '▶ MOTION' : 'Ⅱ MOTION'; b.setAttribute('aria-pressed', String(!state.paused)); } }
state.ready = true; applyPause();
window.ForgeMotion = { state, toggle() { state.paused = !state.paused; applyPause(); }, setPalette(i) { paletteShift = i * .19; pulse = .8; }, pulse(n = .7) { pulse = Math.min(2.5, pulse + n); }, busy(on) { targetEnergy = on ? 1 : .25; } };
addEventListener('forge-turn-ended', () => window.ForgeMotion.pulse(1));
dispatchEvent(new Event('forge-motion-ready'));
