param([string]$Payload)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new()
$a=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload)) | ConvertFrom-Json
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Windows.Forms
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public class ForgeDesktop {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(uint f,uint x,uint y,uint d,UIntPtr e);
 [DllImport("user32.dll")] public static extern uint SendInput(uint n,INPUT[] a,int size);
 [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public UNION u; }
 [StructLayout(LayoutKind.Explicit)] public struct UNION {
  [FieldOffset(0)] public KEY k;
  [FieldOffset(0)] public MOUSE m;
 }
 [StructLayout(LayoutKind.Sequential)] public struct KEY { public ushort vk,scan; public uint flags,time; public IntPtr extra; }
 [StructLayout(LayoutKind.Sequential)] public struct MOUSE { public int dx,dy; public uint data,flags,time; public IntPtr extra; }
 public static void Text(string s) { foreach(char c in s) { INPUT a=new INPUT();a.type=1;a.u.k.scan=c;a.u.k.flags=4;INPUT b=a;b.u.k.flags=6; if(SendInput(2,new INPUT[]{a,b},Marshal.SizeOf(typeof(INPUT)))!=2)throw new Exception("OS rejected keyboard input"); } }
}
'@
function Window($h){[System.Windows.Automation.AutomationElement]::FromHandle([IntPtr][long]$h)}
switch($a.action){
 'windows' { $out=@(Get-Process | Where-Object {$_.MainWindowHandle -ne 0} | ForEach-Object {@{handle=$_.MainWindowHandle.ToInt64().ToString();pid=$_.Id;name=$_.ProcessName;title=$_.MainWindowTitle}}); ConvertTo-Json -InputObject $out -Depth 5 -Compress }
 'inspect' { $root=Window $a.windowHandle; $all=$root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition);$rows=@();for($i=0;$i -lt [Math]::Min(1000,$all.Count);$i++) { try {$c=$all[$i].Current;$rows+=@{name=$c.Name;automationId=$c.AutomationId;type=$c.ControlType.ProgrammaticName;enabled=$c.IsEnabled;offscreen=$c.IsOffscreen;x=$c.BoundingRectangle.X;y=$c.BoundingRectangle.Y;width=$c.BoundingRectangle.Width;height=$c.BoundingRectangle.Height}}catch{}};ConvertTo-Json -InputObject @{window=$a.windowHandle;elements=$rows;truncated=($all.Count -gt 1000)} -Depth 5 -Compress }
 {$_ -in 'type','key','click'} { if(!$a.windowHandle){throw 'Target window handle required'};$h=[IntPtr][long]$a.windowHandle;[void][ForgeDesktop]::SetForegroundWindow($h);Start-Sleep -Milliseconds 150;if([ForgeDesktop]::GetForegroundWindow() -ne $h){throw 'Target window did not receive focus; no input was sent'}
 if($a.action -eq 'type'){if($a.automationId){$e=(Window $a.windowHandle).FindFirst([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::AutomationIdProperty,[string]$a.automationId));if(!$e){throw 'Editable element not found'};$e.SetFocus()};[ForgeDesktop]::Text([string]$a.text)}
 elseif($a.action -eq 'key'){[System.Windows.Forms.SendKeys]::SendWait([string]$a.key)}
 else { [void][ForgeDesktop]::SetCursorPos([int]$a.x,[int]$a.y);$down=2;$up=4;if($a.button -eq 'right'){$down=8;$up=16};[ForgeDesktop]::mouse_event($down,0,0,0,[UIntPtr]::Zero);[ForgeDesktop]::mouse_event($up,0,0,0,[UIntPtr]::Zero) };'{"ok":true}' }
 default {throw 'Unsupported desktop action'}
}
