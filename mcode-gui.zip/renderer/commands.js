// Every top-level CLI command and option (mcode <cmd> --help for 0.5.2)
(() => {
const T = (name, label, extra = {}) => ({ name, label, type: "text", ...extra });
const B = (name, label) => ({ name, label, type: "bool" });
const S = (name, label, options) => ({ name, label, type: "select", options });
const REGION = S("--region", "Account region", ["", "global", "cn"]);
const MKT = S("--marketplace", "Marketplace", ["", "official", "local"]);
const plug = (verb, title) => ({ id: "plugin-" + verb, title, base: ["plugin", verb], fields: [T("_pos", "Plugin (name or name@marketplace)", { required: true }), MKT, B("--json", "JSON output")] });

window.CLI = [
  { group: "Headless run", items: [
    { id: "exec", title: "exec — run one prompt", base: ["exec"], fields: [
      T("_pos", "Prompt", { area: true, required: true }), T("--model", "Model (provider/model)"),
      S("--effort", "Reasoning effort", ["", "low", "medium", "high", "xhigh", "max"]),
      S("--prompt-mode", "Prompt mode", ["", "tui", "coding", "work"]), S("--permission", "Permission", ["", "smart", "full", "off"]),
      T("--session", "Session id"), B("--continue", "Continue latest session"), T("--file", "Attach files (comma separated)", { multi: true }),
      T("--timeout", "Timeout (30s, 2m)"), T("--max-steps", "Max steps"), S("--output-format", "Output format", ["", "text", "json", "stream-json"]),
      S("--input-format", "Input format", ["", "text", "json"]), T("--config", "Runtime config file"), T("--output-schema", "Output JSON schema"),
      T("-o", "Write final message to file"), T("--diagnostics-dir", "Diagnostics directory") ] },
    { id: "exec-review", title: "exec review — review local changes", base: ["exec", "review"], fields: [T("--model", "Model")] },
    { id: "init", title: "init — generate AGENTS.md", base: ["init"], fields: [T("_pos", "Project directory (default: project folder)")] },
  ] },
  { group: "Providers", items: [
    { id: "prov-list", title: "List providers", base: ["provider", "list"], fields: [B("--json", "JSON output")] },
    { id: "prov-add", title: "Add custom provider", base: ["provider", "add"], fields: [
      T("--name", "Display name", { required: true }), T("--base-url", "API base URL", { required: true }),
      S("--api-format", "API format", ["", "anthropic-messages", "openai-completions", "openai-responses"]),
      T("--model", "Model ids (comma separated)", { multi: true }), T("--api-key-env", "Env var holding the API key"),
      T("--context-limit", "Context limit tokens"), T("--output-limit", "Output limit tokens"),
      B("--support-image", "Supports image input"), B("--use", "Test and set as default") ] },
    { id: "prov-remove", title: "Remove provider", base: ["provider", "remove"], fields: [T("_pos", "custom_provider:<id>", { required: true }), B("--yes", "Confirm removal")] },
    { id: "prov-test", title: "Test provider", base: ["provider", "test"], fields: [T("_pos", "Provider id", { required: true }), T("--model", "Single model"), B("--json", "JSON output")] },
    { id: "prov-use", title: "MiniMax credential source", base: ["provider", "use"], fields: [S("_pos", "Source", ["token-plan", "api-key"])] },
    { id: "prov-key", title: "Set MiniMax API key", base: ["provider", "set-minimax-key"], fields: [T("--api-key-env", "Env var holding the key", { required: true })] },
  ] },
  { group: "Plugins", items: [
    { id: "plugin-list", title: "List plugins", base: ["plugin", "list"], fields: [MKT, B("--available", "Include uninstalled"), B("--json", "JSON output")] },
    plug("add", "Install plugin"), plug("remove", "Uninstall plugin"), plug("enable", "Enable plugin"), plug("disable", "Disable plugin"),
    { id: "mkt-list", title: "Plugin sources", base: ["plugin", "marketplace", "list"], fields: [] },
    { id: "mkt-up", title: "Refresh plugin sources", base: ["plugin", "marketplace", "upgrade"], fields: [] },
  ] },
  { group: "Account", items: [
    { id: "login", title: "Sign in", base: ["login"], fields: [REGION, B("--no-browser", "Print URL instead of opening browser")] },
    { id: "logout", title: "Sign out", base: ["logout"], fields: [REGION] },
  ] },
  { group: "System", items: [
    { id: "update", title: "Update MCode", base: ["update"], fields: [] },
    { id: "tel-status", title: "Telemetry status", base: ["telemetry", "status"], fields: [] },
    { id: "tel-preview", title: "Telemetry request preview", base: ["telemetry", "preview"], fields: [] },
    { id: "version", title: "Version", base: ["--version"], fields: [] },
    { id: "help", title: "CLI help", base: ["--help"], fields: [] },
  ] },
];
})();
