const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
module.exports = function ({ app, ipcMain, send, getSettings, review, cancel }) {
  const file = path.join(app.getPath('userData'), 'supervisor.json');
  let run = null, reviewJob = null;
  const collectors = new Set();
  try { run = JSON.parse(fs.readFileSync(file, 'utf8')); if (['running', 'reviewing', 'awaiting-review'].includes(run?.status)) run.status = 'interrupted'; } catch {}
  const persist = () => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(run, null, 2)); send('monitor:event', run); };
  const settings = () => ({ idleSeconds: 180, maxMinutes: 30, reviewSeconds: 90, maxReviews: 8, failureLimit: 3, reviewer: 'codex', ...getSettings().monitor });
  function stop(reason = 'Stopped by user') {
    if (!run) return;
    run.status = 'stopped'; run.reason = reason; cancel(run.engine, run.sessionId);
    for (const collector of collectors) if (collector.run === run) cancel(collector.engine, collector.sessionId);
    persist();
  }
  function observe(ch, ...args) {
    if (ch === 'acp:exit' && run?.engine === args[0] && ['running', 'reviewing'].includes(run.status)) return stop('Worker process exited');
    if (ch === 'acp:notify') {
      const [engine, method, p] = args;
      for (const collector of collectors) if (engine === collector.engine && p?.sessionId === collector.sessionId && p.update?.sessionUpdate === 'agent_message_chunk') collector.text = (collector.text + (p.update.content?.text || '')).slice(-64000);
      if (!run || !['running', 'reviewing'].includes(run.status) || engine !== run.engine || p?.sessionId !== run.sessionId) return;
      const u = p.update; if (!u) return;
      run.lastProgress = Date.now(); run.revision = (run.revision || 0) + 1;
      if (u.sessionUpdate === 'tool_call') run.tools++;
      if (u.sessionUpdate === 'tool_call_update' && u.status === 'failed') { run.failures++; run.events.push({ at: Date.now(), kind: 'failure', text: u.title || 'Tool failed' }); if (run.failures >= settings().failureLimit) stop('Repeated tool failures'); }
      if (u.sessionUpdate === 'agent_message_chunk') run.output = (run.output + (u.content?.text || '')).slice(-18000);
      if (/tool_call/.test(u.sessionUpdate)) { run.events.push({ at: Date.now(), kind: u.sessionUpdate, text: u.title || u.status || u.kind || 'tool' }); run.events = run.events.slice(-80); }
    } else if (ch === 'runtime:event' && run?.status === 'running') {
      run.lastProgress = Date.now(); run.events.push({ at: Date.now(), kind: args[0]?.kind, text: args[0]?.action || args[0]?.command || '' }); run.events = run.events.slice(-80);
    }
  }
  function check() {
    if (!run || !['running', 'reviewing', 'awaiting-review'].includes(run.status)) return Promise.resolve(null);
    if (reviewJob?.run === run) return reviewJob.promise;
    const active = run, s = settings();
    if (active.reviews >= s.maxReviews) { stop('Supervisor review budget exhausted'); return Promise.resolve({ ok: false, reason: run.reason }); }
    const job = { run: active, revision: active.revision || 0, collector: null, promise: null }; reviewJob = job;
    active.status = 'reviewing'; active.reviews++; persist();
    job.promise = (async () => {
      try {
        const result = await review({ engine: s.reviewer, model: s.reviewerModel, cwd: active.cwd,
          prompt: `You are Forge's independent runtime supervisor. Read the actual workspace when needed. Review this active task for concrete errors, loops, scope drift and unsupported completion claims. Do not edit files or operate the desktop/browser. Goal: ${active.goal}\nWorker: ${active.engine}\nRecent actual events: ${JSON.stringify(active.events).slice(-12000)}\nRecent worker output:\n${active.output}\nRespond with findings, then exactly FORGE_MONITOR: OK or FORGE_MONITOR: STOP. STOP cancels this run. OK permits continuing, not automatic source deployment.`,
          onSession: sessionId => {
            if (run !== active || active.status === 'stopped') { cancel(s.reviewer, sessionId); return; }
            job.collector = { run: active, engine: s.reviewer, sessionId, text: '' }; collectors.add(job.collector);
          } });
        if (run !== active || active.status === 'stopped') return { ok: false, reason: 'Run stopped or replaced' };
        active.lastReview = { at: Date.now(), engine: s.reviewer, text: result.text || job.collector?.text || '', completed: !!result.ok };
        const verdict = active.lastReview.text.trim().match(/FORGE_MONITOR:\s*(OK|STOP)\s*$/)?.[1];
        if (!result.ok || verdict !== 'OK') { stop(!result.ok ? 'Supervisor could not complete: ' + (result.error || 'no response') : 'Supervisor requested stop or returned no valid verdict'); return { ok: false, review: active.lastReview }; }
        if (active.turnEnded && (active.revision || 0) !== job.revision) {
          active.lastReview.stale = true; active.status = 'awaiting-review'; persist();
          if (reviewJob === job) reviewJob = null;
          return check(); // Completion must review the final worker output, never a periodic snapshot.
        }
        active.status = active.turnEnded ? 'ready' : 'running'; active.lastProgress = Date.now(); persist(); return { ok: true, review: active.lastReview };
      } catch (e) {
        if (run === active && active.status !== 'stopped') stop('Supervisor unavailable: ' + e.message);
        return { ok: false, error: e.message };
      } finally {
        if (job.collector) collectors.delete(job.collector);
        if (reviewJob === job) reviewJob = null;
      }
    })();
    return job.promise;
  }
  ipcMain.handle('monitor:start', (_e, config) => {
    if (run && ['running', 'reviewing', 'awaiting-review'].includes(run.status)) throw Error('Stop the existing monitored run first.');
    if (!config.sessionId || !config.engine) throw Error('Create a provider session first.');
    run = { id: crypto.randomUUID(), status: 'running', startedAt: Date.now(), expiresAt: Math.min(Date.now() + settings().maxMinutes * 60000, Number(config.deadline) || Infinity), lastProgress: Date.now(), reviews: 0, revision: 0, tools: 0, failures: 0, output: '', events: [], engine: config.engine, sessionId: config.sessionId, cwd: config.cwd, goal: String(config.goal || '').slice(0, 12000) }; persist(); return run;
  });
  ipcMain.handle('monitor:state', () => run); ipcMain.handle('monitor:stop', () => stop()); ipcMain.handle('monitor:review', () => check());
  ipcMain.handle('monitor:turn-ended', () => { if (run && ['running', 'reviewing'].includes(run.status)) { run.turnEnded = true; run.revision = (run.revision || 0) + 1; if (run.status === 'running') run.status = 'awaiting-review'; persist(); } return run; });
  ipcMain.handle('monitor:complete', () => { if (run?.status !== 'ready' || !run?.turnEnded || !run?.lastReview?.completed || run.lastReview.stale || !run.lastReview.text.trim().endsWith('FORGE_MONITOR: OK')) throw Error('Supervisor approval is required to complete the mission.'); run.status = 'complete'; persist(); return run; });
  const timer = setInterval(() => {
    if (!run || !['running', 'reviewing', 'awaiting-review'].includes(run.status)) return;
    const s = settings(), now = Date.now();
    if (now > (run.expiresAt || run.startedAt + s.maxMinutes * 60000)) return stop('Mission runtime limit reached');
    if (run.status === 'running' && now - run.lastProgress > s.idleSeconds * 1000) return stop('No progress / possible stalled tool');
    if (run.status === 'running' && reviewJob?.run !== run && now - (run.lastReview?.at || run.startedAt) > s.reviewSeconds * 1000) check();
  }, 2500); timer.unref();
  app.on('before-quit', () => { clearInterval(timer); if (run && ['running', 'reviewing', 'awaiting-review'].includes(run.status)) { run.status = 'interrupted'; persist(); } });
  return { observe, stop, check, get: () => run };
};
