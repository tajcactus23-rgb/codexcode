"""Local Whisper transcription; the reference recording never leaves this computer."""
import json
import sys
from faster_whisper import WhisperModel

if __name__ == '__main__':
    model = WhisperModel(sys.argv[2], device='cpu', compute_type='int8')
    language = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] != 'auto' else None
    segments, info = model.transcribe(sys.argv[1], language=language, vad_filter=True)
    text = ' '.join(s.text.strip() for s in segments).strip()
    print('FORGE_TRANSCRIPT:' + json.dumps(text), flush=True)
