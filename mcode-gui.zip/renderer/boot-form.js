import { mountForm } from "./form.js";
import { mountBoids } from "./boids.js";
import { mountFluid } from "./fluid.js";
const leftBoids = mountBoids(document.getElementById("boidsLeft"));
const fluid = mountFluid(document.getElementById("fluidRight"));
const form = mountForm(document.getElementById("formCanvas"));
const boids = mountBoids(document.getElementById("boids"));
window.FORM = {
  setColors: (a, b) => { form.setColors(a, b); boids.pulse(1); leftBoids.pulse(1); fluid.pulse(1); },
  pulse: (a) => { form.pulse(a); boids.pulse(a); leftBoids.pulse(a); fluid.pulse(a); },
  busy: (on) => { form.busy(on); boids.busy(on); leftBoids.busy(on); fluid.busy(on); },
  config: (c) => { form.config?.(c); boids.config?.(c); leftBoids.config?.(c); },   // Settings: show reactor / intensity (applyCfg calls this)
};
window.dispatchEvent(new Event("form-ready"));
