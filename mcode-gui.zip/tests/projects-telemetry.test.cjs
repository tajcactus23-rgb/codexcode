const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), os = require('node:os');
const { createStore, previewURL } = require('../projects.cjs');
const { createSampler } = require('../telemetry.cjs');
const { pathToFileURL } = require('node:url');
function fixture(t) { const root = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-project-')); t.after(() => fs.rmSync(root, { recursive: true, force: true })); return root; }
test('project showcase discovers actual workspaces/builds, persists edits and imports, and hides without deleting source', async t => {
  const root = fixture(t), workspace = path.join(root, 'workspace'), build = path.join(root, 'forged.html'), userData = path.join(root, 'profile');
  fs.mkdirSync(workspace); fs.writeFileSync(path.join(workspace, 'package.json'), JSON.stringify({ name: 'Actual project', description: 'Actual project metadata', dependencies: { three: '^0.160' } })); fs.writeFileSync(path.join(workspace, 'index.html'), '<title>Actual HTML</title><p>Project content</p>'); fs.writeFileSync(build, '<p>Built project</p>');
  let store = createStore({ userData, getRoots: () => [workspace] }); let items = await store.list(); assert.equal(items.length, 1); assert.equal(items[0].name, 'Actual project'); assert.equal(items[0].previewUrl, pathToFileURL(path.join(workspace, 'index.html')).href); assert.deepEqual(items[0].tags, ['three']);
  const imported = await store.add(build); await store.update(imported.id, { name: 'Built masterpiece', status: 'ready', pinned: true, tags: 'WebGL, game', summary: 'A real build', previewUrl: 'http://127.0.0.1:3000' });
  store = createStore({ userData, getRoots: () => [workspace] }); items = await store.list(); assert.equal(items.length, 2); assert.equal(items[0].name, 'Built masterpiece'); assert.deepEqual(items[0].tags, ['WebGL', 'game']); assert.equal(items[0].status, 'ready');
  await store.remove(imported.id); assert.equal((await store.list()).length, 1); assert.ok(fs.existsSync(build)); await store.add(build); assert.equal((await store.list()).length, 2);
});
test('project metadata rejects executable preview schemes and bad statuses; missing workspaces stay explicit; covers are bounded images', async t => {
  const root = fixture(t), workspace = path.join(root, 'app'); fs.mkdirSync(workspace); const png = path.join(workspace, 'preview.png'); fs.writeFileSync(png, Buffer.from('89504e470d0a1a0a', 'hex')); const store = createStore({ userData: path.join(root, 'profile'), getRoots: () => [workspace] }); const p = (await store.list())[0];
  assert.match(await store.thumbnail(p.id), /^data:image\/png;base64,/); await assert.rejects(store.update(p.id, { previewUrl: 'javascript:alert(1)' }), /HTTP/); await assert.rejects(store.update(p.id, { status: 'invented' }), /status/); assert.throws(() => previewURL('data:text/html,hello'), /HTTP/);
  fs.rmSync(workspace, { recursive: true }); assert.equal((await store.list())[0].missing, true); assert.equal(await store.thumbnail(p.id), null);
});
test('host telemetry samples actual bounded delta utilisation, system memory and per-core counters', async () => {
  const sample = createSampler(); sample(); await new Promise(r => setTimeout(r, 40)); const result = sample(); assert.ok(result.cores.length > 0); assert.ok(result.cpuPercent === null || result.cpuPercent >= 0 && result.cpuPercent <= 100); assert.ok(result.memory.total > 0); assert.equal(result.memory.used + result.memory.free, result.memory.total); assert.ok(result.processBytes > 0); assert.ok(result.uptime > 0); assert.ok(result.hostname);
});
test('project registry recovers valid JSON with damaged shapes and individual cover reads do not rescan other workspaces', async t => {
  const root = fixture(t), userData = path.join(root, 'profile'); fs.mkdirSync(userData);
  for (const broken of [null, [], { items: 'broken', hidden: null }, { items: { invalid: null }, hidden: {} }]) { fs.writeFileSync(path.join(userData, 'showcase-projects.json'), JSON.stringify(broken)); assert.deepEqual(await createStore({ userData }).list(), []); }
  const workspaces = Array.from({ length: 12 }, (_, i) => { const dir = path.join(root, 'app-' + i); fs.mkdirSync(dir); fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'Actual app ' + i })); return dir; });
  fs.writeFileSync(path.join(workspaces[3], 'package.json'), 'null');
  fs.writeFileSync(path.join(workspaces[3], 'README.md'), '# App\n\nActual description survives damaged package metadata.');
  const store = createStore({ userData, getRoots: () => workspaces }), items = await store.list();
  assert.equal(items.length, 12);
  assert.equal(items.find(item => item.path === workspaces[3]).summary, 'Actual description survives damaged package metadata.');
  const calls = [], original = fs.promises.stat; fs.promises.stat = async (...args) => { calls.push(String(args[0])); return original(...args); }; t.after(() => { fs.promises.stat = original; });
  await store.thumbnail(items[0].id); assert.ok(calls.length > 0); assert.ok(calls.every(file => file === items[0].path || file.startsWith(items[0].path + path.sep)), 'cover read inspected another workspace');
});
