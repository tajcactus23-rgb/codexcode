const $ = (id) => document.getElementById(id);
const h = (tag, attrs = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (k === "class") e.className = v;
    else if (k === "html") e.innerHTML = v;
    else if (v !== undefined && v !== null && v !== false) e.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) e.append(k.nodeType ? k : String(k));
  return e;
};
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const api = window.mcode;
let S = {};
let engine = "mcode";
let cur = null; // { engine, sessionId, cwd, config, modes, commands, busy, started }
const history = []; let histIdx = -1;

// ---------------- global error surface ----------------
// Nothing here should fail silently. A thrown error or rejected promise inside a click
// handler or during init used to vanish with no feedback, which made working-but-erroring
// buttons look like missing features (steer, queue, upload, local all "do nothing"). Surface
// every one as a dismissible banner + console line so any runtime failure is diagnosable.
(() => {
  let box;
  const show = (label, detail) => {
    try {
      if (!box || !box.isConnected) box = document.body.appendChild(h("div", { id: "errBar" }));
      box.style.cssText = "position:fixed;left:50%;bottom:14px;transform:translateX(-50%);z-index:99999;max-width:min(680px,92vw);background:#2a0810;border:1px solid #ff3b5c;color:#ffd7df;font:12px/1.5 ui-monospace,monospace;padding:10px 12px;border-radius:10px;box-shadow:0 8px 30px #000a;white-space:pre-wrap;cursor:pointer";
      box.title = "click to dismiss";
      box.onclick = () => { box.remove(); box = null; };
      box.textContent = "⚠ " + label + (detail ? "\n" + detail : "");
    } catch {}
    try { console.error("[app]", label, detail); } catch {}
  };
  addEventListener("error", (e) => show(e.message || "script error", [e.filename, e.lineno && ("line " + e.lineno)].filter(Boolean).join("  ")));
  addEventListener("unhandledrejection", (e) => { const r = e.reason; show("unhandled rejection", (r && (r.stack || r.message)) || String(r)); });
})();

// ---------------- markdown (escaped first, then formatted) ----------------
function md(src) {
  const blocks = [];
  let t = esc(src).replace(/```(\w*)\n?([\s\S]*?)```/g, (_, l, code) => { blocks.push(`<pre><code>${code.replace(/\n$/, "")}</code></pre>`); return `\u0000${blocks.length - 1}\u0000`; });
  t = t.replace(/`([^`\n]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>")
    .replace(/(^|\s)\*([^*\n]+)\*/g, "$1<i>$2</i>")
    .replace(/^#{1,3} (.*)$/gm, "<h3>$1</h3>")
    .replace(/^(?:[-*] .*(?:\n|$))+/gm, (m) => "<ul>" + m.trim().split("\n").map((l) => `<li>${l.replace(/^[-*] /, "")}</li>`).join("") + "</ul>")
    .replace(/^(?:\d+\. .*(?:\n|$))+/gm, (m) => "<ol>" + m.trim().split("\n").map((l) => `<li>${l.replace(/^\d+\. /, "")}</li>`).join("") + "</ol>")
    .split(/\n{2,}/).map((p) => (/^<(h3|ul|ol|pre)|^\u0000/.test(p) ? p : `<p>${p.replace(/\n/g, "<br>")}</p>`)).join("");
  return t.replace(/\u0000(\d+)\u0000/g, (_, i) => blocks[i]);
}

// ---------------- thread rendering ----------------
const nodes = new Map(); // messageId/toolCallId -> {el, text}
let transcript = [];
function thread() { return $("thread"); }
function scroll() { const t = thread(); if (t.scrollHeight - t.scrollTop - t.clientHeight < 240) t.scrollTop = t.scrollHeight; }
function add(el) { $("welcome")?.remove(); document.body.classList.add("chatting"); thread().append(el); scroll(); window.FORM?.pulse(0.4); return el; }
function clearThread() { thread().replaceChildren(); nodes.clear(); transcript = []; document.body.classList.remove("chatting"); }
function sys(text) { add(h("div", { class: "sysmsg" }, text)); }
function err(text) { add(h("div", { class: "errmsg" }, "⚠ " + text)); }
function userMsg(text, id) {
  const el = add(h("div", { class: "msg user" }, text));
  if (id) nodes.set("u:" + id, { el, text });
  transcript.push({ role: "user", text, engine, model: $("model").value });
  window.ForgeChat?.changed();
}
function chunk(kind, id, text) {
  const key = kind + ":" + (id || "x");
  let n = nodes.get(key);
  if (!n) {
    const el = kind === "agent" ? h("div", { class: "msg agent" }) : kind === "think" ? h("div", { class: "think" }) : h("div", { class: "msg user" });
    if (kind === "agent") {
      const body = h("div");
      el.append(body, h("button", { class: "copy", title: "Copy as Markdown", onclick: () => api.copy(n.text) }, "copy"));
      el._body = body;
      el.append(h("small", { class: "message-route" }, (ENGINE_LABEL?.[engine] || engine).toUpperCase() + " / " + ($("model").value || "model")));
    }
    n = { el, text: "", entry: { role: kind === "agent" ? "assistant" : kind, text: "", engine, model: $("model").value } };
    nodes.set(key, n); add(el); transcript.push(n.entry);
  }
  n.text += text; n.entry.text = n.text;
  window.ForgeChat?.changed();
  // stream OFF: hold the reply hidden until the turn ends, then show it whole (spinner shows meanwhile)
  if (kind === "agent" && cur?.busy && S.cfg?.streamReplies === false) { n.held = true; n.el.style.display = "none"; return; }
  n.el.style.display = n.text.trim() ? "" : "none";
  if (kind === "agent") { cancelAnimationFrame(n.raf); n.raf = requestAnimationFrame(() => { n.el._body.innerHTML = md(n.text); scroll(); }); }
  else { n.el.textContent = n.text; scroll(); }
}
const KIND_ICON = { read: "📖", edit: "✎", delete: "🗑", move: "⇄", search: "🔍", execute: "⚡", think: "💭", fetch: "🌐", other: "⚙" };
function toolText(u) {
  const parts = [];
  const i = u.rawInput || {};
  if (i.command) parts.push("$ " + i.command);
  else if (Object.keys(i).length) parts.push(JSON.stringify(i, null, 2));
  for (const c of u.content || []) {
    if (c.type === "diff") parts.push(`--- ${c.path}\n${(c.newText || "").slice(0, 6000)}`);
    else if (c.content?.text) parts.push(c.content.text);
  }
  const out = u.rawOutput?.content?.map((c) => c.text || "").join("\n").trim();
  if (out) parts.push(out.slice(0, 8000));
  return parts.join("\n\n");
}
function tool(u) {
  let n = nodes.get("t:" + u.toolCallId);
  if (!n) {
    const summary = h("summary", {}, h("span", { class: "ico" }, KIND_ICON[u.kind] || "⚙"), h("span", { class: "tt" }), h("span", { class: "st pending" }, "pending"));
    const el = h("details", { class: "tool" }, summary, h("pre"));
    n = { el, data: {} }; nodes.set("t:" + u.toolCallId, n); add(el);
    transcript.push({ role: "tool", get text() { return (n.data.title || "") + "\n" + toolText(n.data); } });
  }
  Object.assign(n.data, Object.fromEntries(Object.entries(u).filter(([, v]) => v !== undefined)));
  const d = n.data, i = d.rawInput || {};
  const target = i.path || i.file_path || i.filePath || i.command || i.pattern || i.url || "";
  n.el.querySelector(".tt").textContent = `${d.title || d.name || "tool"}${target ? "  —  " + String(target).slice(0, 140) : ""}`;
  window.ForgeChat?.changed();
  const st = n.el.querySelector(".st"); st.className = "st " + (d.status || "pending"); st.textContent = d.status || "pending";
  n.el.querySelector("pre").textContent = toolText(d);
  if (d.status === "completed") { noteHtml(i.path || i.file_path || i.filePath); window.FORM?.pulse(0.9); }
  scroll();
}
// ---------------- built-in browser + inline previews ----------------
const fileUrl = (p) => "file:///" + String(p).replace(/\\/g, "/").split("/").map((s, i) => (i === 0 ? s : encodeURIComponent(s))).join("/");
let browserPath = null, turnHtml = null;
const shownCards = new Set();
function openBrowser(p) {
  browserPath = p;
  $("browser").hidden = false;
  $("bTitle").textContent = p;
  $("bView").src = fileUrl(p);
  window.FORM?.pulse(1.2);
}
function noteHtml(p) {
  if (!p || !/\.html?$/i.test(p)) return;
  turnHtml = p;
  if (shownCards.has(p)) return;
  shownCards.add(p);
  const card = h("div", { class: "pcard" },
    h("div", { class: "ph" }, "▶", h("span", { title: p }, p),
      h("button", { onclick: () => openBrowser(p) }, "OPEN"),
      h("button", { title: "Own app window", onclick: () => api.openWindow(p).catch((e) => toast(e.message)) }, "⤢")),
    h("webview", { src: fileUrl(p), class: "pview" }));
  add(card);
  const wv = card.querySelector("webview");
  wv.addEventListener("dom-ready", () => { try { wv.setZoomFactor(0.5); } catch {} });
}
$("bClose").onclick = () => { $("browser").hidden = true; $("bView").src = "about:blank"; };
$("bReload").onclick = () => $("bView").reload();
$("bExt").onclick = () => browserPath && api.openWindow(browserPath).catch((e) => toast(e.message));
if ($("killBtn")) $("killBtn").onclick = async () => {
  const n = await api.killAll();
  if (cur) setBusy(false);
  cur = null;
  sys(`KILL SERVER — stopped ${n} process${n === 1 ? "" : "es"}. Next action restarts what it needs.`);
  window.FORM?.pulse(2.5);
  $("stProxy").textContent = "proxy stopped"; $("stProxy").style.color = "var(--bad)";
};
const PICK_JS = `new Promise((resolve) => {
  const box = document.createElement("div");
  box.style.cssText = "position:fixed;pointer-events:none;z-index:2147483647;border:2px solid #ff3fb4;background:rgba(255,63,180,.12);transition:all .06s";
  document.body.appendChild(box);
  const sel = (el) => { const parts = []; while (el && el.nodeType === 1 && parts.length < 5) { let s = el.tagName.toLowerCase(); if (el.id) { s += "#" + el.id; parts.unshift(s); break; } const c = [...el.classList].slice(0, 2).join("."); if (c) s += "." + c; const sib = el.parentElement ? [...el.parentElement.children].filter((x) => x.tagName === el.tagName) : []; if (sib.length > 1) s += ":nth-of-type(" + (sib.indexOf(el) + 1) + ")"; parts.unshift(s); el = el.parentElement; } return parts.join(" > "); };
  const move = (e) => { const r = e.target.getBoundingClientRect(); Object.assign(box.style, { left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px" }); };
  const done = (v) => { removeEventListener("mousemove", move, true); removeEventListener("click", click, true); removeEventListener("keydown", key, true); box.remove(); resolve(v); };
  const click = (e) => { e.preventDefault(); e.stopPropagation(); const el = e.target; done({ selector: sel(el), tag: el.tagName.toLowerCase(), text: (el.innerText || "").trim().slice(0, 120), html: el.outerHTML.slice(0, 400) }); };
  const key = (e) => { if (e.key === "Escape") done(null); };
  addEventListener("mousemove", move, true); addEventListener("click", click, true); addEventListener("keydown", key, true);
})`;
$("bPick").onclick = async () => {
  if (!browserPath) return;
  $("bPick").classList.add("on"); $("bHint").hidden = false;
  let info = null;
  try { info = await $("bView").executeJavaScript(PICK_JS, true); } catch (e) { toast("Picker failed: " + e.message); }
  $("bPick").classList.remove("on"); $("bHint").hidden = true;
  if (!info) return;
  ask(`Change <${info.tag}>${info.text ? " “" + info.text.slice(0, 40) + "”" : ""}`, [{ name: "note", label: "What should change about this element?", type: "text", area: true }], (v) => {
    if (!v.note) return;
    sendText(`Edit the GUI file:\n${browserPath}\n\nTarget element (CSS selector): ${info.selector}\nElement: <${info.tag}> ${info.text ? "text “" + info.text + "”" : ""}\nSnippet: ${info.html}\n\nChange requested: ${v.note}\n\nEdit the file in place. Keep everything else unchanged.`);
  }, "Send to agent");
};
function plan(entries) {
  let n = nodes.get("plan");
  if (!n) { n = { el: h("div", { class: "plan" }) }; nodes.set("plan", n); add(n.el); }
  n.el.replaceChildren(h("div", { class: "dim" }, "PLAN"), h("ul", {}, entries.map((e) => h("li", { class: e.status }, (e.status === "completed" ? "☑ " : e.status === "in_progress" ? "◐ " : "☐ ") + e.content))));
}

// ---------------- session state ----------------
function showHeld() {
  for (const n of nodes.values()) if (n.held) { n.held = false; n.el._body.innerHTML = md(n.text); n.el.style.display = n.text.trim() ? "" : "none"; }
  scroll();
}
function setBusy(b) {
  if (!cur) return;
  cur.busy = b;
  // working spinner pinned under the latest message while the model thinks / writes
  $("workSpin")?.remove();
  if (b) thread().append(h("div", { id: "workSpin", class: "spinner-container" }, h("div", { class: "spinner" })));
  else showHeld();
  $("stopBtn").disabled = !b;
  const mc = cur.engine === "mcode";
  $("steerBtn").disabled = !b; $("queueBtn").disabled = !b;
  $("steerBtn").title = mc ? "Inject guidance into the running turn" : "Redirect: stop this turn and send your guidance as the next message";
  $("queueBtn").title = mc ? "Queue this message to run after the current turn" : "Hold this message and send it automatically when the turn ends";
  $("stState").textContent = b ? "● working" : "● idle";
  $("stState").style.color = b ? "var(--warn)" : "var(--ok)";
  bg.energy = b ? 1 : 0;
  window.FORM?.busy(b);
}
function applyConfig(configOptions, modes) {
  if (!cur) return;
  if (configOptions) cur.config = configOptions;
  if (modes) cur.modes = modes;
  const model = cur.config?.find((c) => c.id === "model" || c.category === "model");
  const free = $("freeOnly").checked;
  const opts = (model?.options || []).filter((o) => !free || /free|local-/i.test(o.name + o.value) || o.value === model.currentValue);
  $("model").replaceChildren(...opts.map((o) => h("option", { value: o.value, ...(o.value === model.currentValue ? { selected: true } : {}) }, o.name)));
  $("model").disabled = !model;
  const perm = cur.config?.find((c) => c.id === "permissionMode");
  $("perm").style.display = perm ? "" : "none";
  if (perm) $("perm").replaceChildren(...perm.options.map((o) => h("option", { value: o.value, ...(o.value === perm.currentValue ? { selected: true } : {}) }, "🔒 " + o.name)));
  const m = cur.modes;
  $("modeSeg").replaceChildren(...(m?.availableModes || []).map((x) => h("button", { class: x.id === m.currentModeId ? "on" : "", title: x.description, onclick: () => setMode(x.id) }, x.name)));
}
const BUILTIN = new Set(["help", "new", "model", "status", "doctor", "context", "skills", "mcp", "usage", "compact", "review", "init"]);
function renderChips() {
  const cmds = cur?.commands || [];
  const core = cmds.filter((c) => BUILTIN.has(c.name));
  const skills = cmds.length - core.length;
  $("cmdChips").replaceChildren(...[
    ...core.map((c) => h("button", { title: c.description + (c.input?.hint ? "  " + c.input.hint : ""), onclick: () => runAgentCommand(c) }, "/" + c.name)),
    skills > 0 ? h("button", { class: "acc", title: "Browse all Skills with descriptions", onclick: openSkills }, `⋯ ${skills} skills`) : null].filter(Boolean));
}
function openSkills() {
  $("skillsPop").hidden = false; $("skFilter").value = ""; renderSkills(); $("skFilter").focus();
}
function renderSkills() {
  const q = $("skFilter").value.toLowerCase().trim();
  const cmds = (cur?.commands || []).filter((c) => !q || (c.name + " " + c.description).toLowerCase().includes(q));
  $("skList").replaceChildren(...(cmds.length ? cmds.map((c) => {
    const [plugin, name] = c.name.includes(":") ? c.name.split(":") : [BUILTIN.has(c.name) ? "built-in" : "skill", c.name];
    const full = (c.description || "No description provided.") + (c.input?.hint ? "\n\ntakes: " + c.input.hint : "");
    const short = (c.description || "").replace(/^\s*\[[^\]]+\]\s*/, "").replace(/\s+/g, " ").split(/(?<=[.!?])\s|\s[-—–]\s|;\s/)[0];
    return h("button", { class: "sk", title: full, onclick: () => { $("skillsPop").hidden = true; runAgentCommand(c); } },
      h("div", {}, h("span", { class: "nm" }, "/" + name), h("span", { class: "grp" }, plugin.toUpperCase())),
      h("div", { class: "ds" }, short || "—"));
  }) : [h("div", { class: "note" }, cur ? "No match." : "Start a session to load skills.")]));
}
$("skFilter").oninput = renderSkills;
$("skClose").onclick = () => ($("skillsPop").hidden = true);
$("skillsPop").onclick = (e) => { if (e.target.id === "skillsPop") $("skillsPop").hidden = true; };
function runAgentCommand(c) {
  if (!c.input?.hint) return sendText("/" + c.name);
  ask("/" + c.name, [{ name: "arg", label: c.description + " — " + c.input.hint, type: "text" }], (v) => sendText(("/" + c.name + " " + (v.arg || "")).trim()), "Send");
}
async function call(method, params, eng = engine) {
  try { return await api.acpCall(eng, method, params); }
  catch (e) { err(`${method}: ${e.message.replace(/^Error invoking remote method '[^']+': (Error: )?/, "")}`); throw e; }
}
async function newSession() {
  if (cur?.busy) return toast('Stop the current turn before creating another conversation.');
  await window.ForgeChat?.flush();
  const r = await call("session/new", { cwd: S.cwd, mcpServers: [] });
  openSession(r.sessionId, S.cwd, r);
  await window.ForgeChat?.newChat(r);
  const mc = r.configOptions?.find((c) => c.id === "model" || c.category === "model");
  if (mc) {
    const pref = (S.prefModel || {})[engine];
    const isFree = (v) => /free|local-/i.test(v + " " + (mc.options.find((o) => o.value === v)?.name || ""));
    let want = pref && mc.options.some((o) => o.value === pref) ? pref : null;
    if ($("freeOnly").checked && !(want && isFree(want)) && !isFree(mc.currentValue)) want = mc.options.find((o) => isFree(o.value))?.value || want;
    if (want && want !== mc.currentValue) await setModel(want);
  }
  listSessions();
  return r;
}
function openSession(sessionId, cwd, r = {}) {
  cur = { engine, sessionId, cwd, config: r.configOptions, modes: r.modes, commands: cur?.engine === engine ? cur.commands : [], busy: false };
  clearThread(); applyConfig(); renderChips(); setBusy(false);
  $("sessTitle").textContent = sessionId;
  document.querySelectorAll(".sess").forEach((b) => b.classList.toggle("on", b.dataset.id === sessionId));
  refreshMcodePanels();
}
async function loadSession(s) {
  if (s.chatId) return window.ForgeChat.load(s).catch((e) => toast(e.message));
  if (cur?.busy) return toast("Agent is working — stop it first.");
  if (s.engine && s.engine !== engine) {
    // clicked a session that lives on another provider — switch to it first
    engine = s.engine;
    $("engine").value = engine; $("stEngine").textContent = "engine " + engine;
    $("model").replaceChildren(); $("modeSeg").replaceChildren(); $("perm").style.display = "none"; $("cmdChips").replaceChildren();
    try { await api.acpStart(engine); } catch (e) { return err(e.message); }
  }
  openSession(s.sessionId, s.cwd);
  $("sessTitle").textContent = s.title || s.sessionId;
  sys("loading session…");
  try {
    const r = await call("session/load", { sessionId: s.sessionId, cwd: s.cwd || S.cwd, mcpServers: [] });
    applyConfig(r?.configOptions, r?.modes);
    thread().querySelector(".sysmsg")?.remove();
  } catch {}
}
async function ensureSession() { await window.ForgeChat?.ensureBinding(); if (!cur || cur.engine !== engine) await newSession(); }
// ---------------- attachments: any file type ----------------
// mcode ACP (P0) takes only text + resource_link blocks, so files go by path plus a manifest the agent can act on.
const attached = [];
const FILE_ICON = { code: "⌥", web: "◈", data: "▤", archive: "▣", image: "▨", doc: "▥", media: "▶", binary: "⚙", folder: "▦", other: "▫" };
const fmtSize = (n) => (n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(1) + " KB" : n < 1073741824 ? (n / 1048576).toFixed(1) + " MB" : (n / 1073741824).toFixed(2) + " GB");
function archiveBadge(f) {
  const a = f.archive; if (!a) return null;
  if (a.extractor === null) return { txt: "no extractor", warn: true };
  if (a.extractor) return { txt: "7z/rar ok", warn: false };
  return a.total >= 0 ? { txt: a.total + " entries", warn: false } : { txt: "zip", warn: !!a.note };
}
function renderAttach() {
  const bar = $("attachBar");
  bar.classList.toggle("has", attached.length > 0);
  $("attachHint").hidden = attached.length > 0;
  $("attachChips").replaceChildren(...attached.map((f) => {
    const b = archiveBadge(f);
    return h("span", { class: "achip k-" + f.kind, title: f.path + (f.archive?.note ? "\n" + f.archive.note : "") },
      h("i", {}, FILE_ICON[f.kind] || "▫"), h("b", {}, f.name), h("em", {}, f.dir ? "folder" : fmtSize(f.size)),
      b ? h("u", { class: b.warn ? "warn" : "" }, b.txt) : null,
      h("button", { title: "Remove", onclick: () => { attached.splice(attached.indexOf(f), 1); renderAttach(); } }, "✕"));
  }));
}
async function addAttachments(list) {
  let n = 0;
  for (const f of list || []) { if (!f.dir && !f.chunks) { try { f.chunks = await api.filePrepare(f.path); } catch (e) { toast('Attachment preparation failed: ' + e.message); throw e; } } }
  for (const f of list || []) if (!attached.some((a) => a.path === f.path)) { attached.push(f); n++; }
  renderAttach();
  if (n) toast(`📎 ${n} attached${n < list.length ? " (duplicates skipped)" : ""}`);
  return n;
}
async function ingestFiles(files) {
  const paths = [], blobs = [];
  for (const f of files) { const p = api.pathForFile(f); p ? paths.push(p) : blobs.push(f); }
  const out = paths.length ? await api.uploadDescribe(paths) : [];
  for (const f of blobs) {
    const id = await api.uploadBegin(f.name || 'pasted.bin', f.size);
    try { for (let offset = 0; offset < f.size; offset += 1048576) await api.uploadAppend(id, offset, await f.slice(offset, offset + 1048576).arrayBuffer());
      const path = await api.uploadFinish(id); out.push(...await api.uploadDescribe([path]));
    } catch (e) { await api.uploadAbort(id); toast(e.message); throw e; }
  }
  if (!out.length) return toast("Couldn't read that drop — use the ATTACH button.");
  await addAttachments(out);
}
function manifestText(files) {
  if (!files.length) return "";
  const lines = ["[Attached files — open and read them with your own tools; paths are on this PC]"];
  for (const f of files) {
    lines.push(`- ${f.path}  (${f.dir ? "folder" : f.kind + ", " + fmtSize(f.size)})`);
    if (f.chunks) lines.push(`  Lossless chunk manifest: ${f.chunks.manifestPath} (${f.chunks.parts.length} parts, SHA256 ${f.chunks.sha256}). Use file.merge to reassemble into a new output; use file.read/extract for bounded context. Entire file is on disk, not in model context.`);
    const a = f.archive;
    if (a?.names?.length) lines.push(`  archive contents (${a.total > a.names.length ? "first " + a.names.length + " of " + a.total : a.names.length}): ${a.names.join(", ").slice(0, 2500)}`);
    if (a?.note) lines.push("  note: " + a.note);
    else if (a && !a.names?.length) lines.push("  note: archive — extract it with your shell before reading");
  }
  return lines.join("\n");
}
const buildPrompt = (text, files) => [
  { type: "text", text: [text, manifestText(files)].filter(Boolean).join("\n\n") },
  ...files.map((f) => ({ type: "resource_link", uri: f.uri, name: f.name, ...(f.dir ? {} : { size: f.size }) })),
];
$("attachBtn").onclick = async () => addAttachments(await api.uploadPick());
$("attachDirBtn").onclick = async () => addAttachments(await api.uploadPickFolder());
let dragDepth = 0;
const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes("Files");
document.addEventListener("dragenter", (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragDepth++; $("dropVeil").hidden = false; });
document.addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
document.addEventListener("dragleave", (e) => { if (!hasFiles(e)) return; if (--dragDepth <= 0) { dragDepth = 0; $("dropVeil").hidden = true; } });
document.addEventListener("drop", (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragDepth = 0; $("dropVeil").hidden = true; ingestFiles([...e.dataTransfer.files]); });
$("prompt").addEventListener("paste", (e) => { const fs = [...(e.clipboardData?.files || [])]; if (fs.length) { e.preventDefault(); ingestFiles(fs); } });

async function sendText(text) {
  text = text.trim();
  if (!text && !attached.length) return;
  await ensureSession();
  if (cur.busy) return toast("Agent is working — use STEER or QUEUE, or STOP.");
  const files = attached.splice(0); renderAttach();
  userMsg([text, ...files.map((f) => `📎 ${f.name} (${f.dir ? "folder" : fmtSize(f.size)}) · ${f.path}`)].filter(Boolean).join("\n"));
  if (text) { history.unshift(text); histIdx = -1; }
  setBusy(true);
  turnHtml = null;
  const turnIndex = transcript.length;
  const started = Date.now(), sid = cur.sessionId, eng = cur.engine;
  let outcome = { ok: false };
  try {
    if (/local-llama/.test($("model").value)) {   // local model: make sure its server is up before MiniMax Code calls it
      const lr = await api.localEnsure();
      if (lr.started) sys("⬢ local model server was stopped — restarted " + lr.alias);
    }
    const seed = cur.pendingHandoff;
    const r = await api.acpCall(eng, "session/prompt", { sessionId: sid, prompt: buildPrompt([seed, text].filter(Boolean).join('\n\n[Latest user message]\n'), files) });
    outcome = { ok: !r?.stopReason || r.stopReason === 'end_turn', stopReason: r?.stopReason };
    if (cur?.sessionId === sid) cur.pendingHandoff = '';
    if (r?.stopReason && r.stopReason !== "end_turn") sys("stopped: " + r.stopReason);
  } catch (e) { outcome = { ok: false, error: e.message }; attached.push(...files); renderAttach(); err(e.message.replace(/^Error invoking remote method '[^']+': (Error: )?/, "")); }
  finally {
    if (cur?.sessionId === sid) { setBusy(false); window.dispatchEvent(new CustomEvent('forge-turn-ended', { detail: { text: transcript.slice(turnIndex).filter((t) => t.role === 'assistant').map((t) => t.text).join("\n"), engine: eng, sessionId: sid } })); }
    if (!turnHtml) { const m = [...transcript].reverse().find((t) => t.role === "assistant")?.text?.match(/[A-Za-z]:\\[^\s"'`<>|]+\.html?/); if (m) noteHtml(m[0]); }
    if (turnHtml) { if (!$("browser").hidden && browserPath === turnHtml) $("bView").reload(); else openBrowser(turnHtml); }
    if (Date.now() - started > 8000 && notifyOn()) api.notify("BM23-TOOLZ", "Agent finished");
    await window.ForgeChat?.flush(); listSessions(); refreshMcodePanels();
    // client-side queue / redirect for engines without native steer+queue: send the next held message
    if (cur?.sessionId === sid && cur.pending?.length) { const nx = cur.pending.shift(); setTimeout(() => sendText(nx.text), 250); }
  }
  return outcome;
}
async function setModel(value) {
  if (cur?.busy) return toast("Stop the current turn before changing models.");
  await ensureSession();
  const r = await call("session/set_config_option", { sessionId: cur.sessionId, configId: "model", value }, cur.engine);
  applyConfig(r?.configOptions);
  const task = window.ForgeChat?.current(); if (task) { const binding = task.bindings.findLast((b) => b.sessionId === cur.sessionId); if (binding) binding.model = value; await window.ForgeChat.flush(); }
  window.dispatchEvent(new Event('forge-model-changed'));
  await saveSettings({ prefModel: { ...(S.prefModel || {}), [cur.engine]: value } });
}
async function setMode(modeId) {
  await ensureSession();
  await call("session/set_mode", { sessionId: cur.sessionId, modeId }, cur.engine);
  if (cur.modes) { cur.modes.currentModeId = modeId; applyConfig(); }
  sys("mode → " + modeId + " (applies from the next message)");
}

// ---------------- ACP events ----------------
api.onAcpNotify((eng, method, p) => {
  if (window.ForgeChat?.suppressReplay() && method === "session/update") return;
  if (method === "session/update" && dock.active && p.sessionId === dock.sid) dockEvent(p.update);
  if (method === "session/update") {
    if (!cur || eng !== cur.engine || p.sessionId !== cur.sessionId) return;
    const u = p.update;
    switch (u.sessionUpdate) {
      case "user_message_chunk": chunk("user", u.messageId, u.content?.text || ""); break;
      case "agent_message_chunk": chunk("agent", u.messageId, u.content?.text || ""); break;
      case "agent_thought_chunk": chunk("think", u.messageId, u.content?.text || ""); break;
      case "tool_call": case "tool_call_update": tool(u); break;
      case "plan": plan(u.entries || []); break;
      case "available_commands_update": cur.commands = u.availableCommands || []; renderChips(); break;
      case "current_mode_update": if (cur.modes) { cur.modes.currentModeId = u.currentModeId; applyConfig(); } break;
      case "config_option_update": applyConfig(u.configOptions); break;
      case "usage_update": {
        const pct = u.size ? Math.min(100, (u.used / u.size) * 100) : 0;
        $("usageFill").style.width = pct + "%";
        $("usageTxt").textContent = `${(u.used || 0).toLocaleString()} / ${(u.size || 0).toLocaleString()} tokens${u.cost ? " · " + u.cost.amount + " " + u.cost.currency : ""}`;
        break;
      }
      case "session_info_update": if (u.title) $("sessTitle").textContent = u.title; break;
    }
  } else if (/queue_update/.test(method)) renderQueue();
  else if (/goal_update/.test(method)) renderGoal();
  else if (/delegation_update/.test(method)) renderTasks();
});
api.onAcpRequest((eng, id, method, p) => {
  const tc = p.toolCall || {};
  const card = h("div", { class: "perm" },
    h("div", { class: "t" }, "⚠ Permission needed: " + (tc.title || tc.name || "tool")),
    h("pre", { style: "white-space:pre-wrap;font:12px Consolas,monospace" }, toolText(tc) || ""));
  const done = (result, label) => { card.querySelector(".opts").replaceChildren(h("span", { class: "dim" }, "→ " + label)); api.acpRespond(eng, id, result); };
  card.append(h("div", { class: "opts" },
    (p.options || []).map((o) => h("button", { class: /allow/.test(o.kind) ? "acc" : "hot", onclick: () => done({ outcome: { outcome: "selected", optionId: o.optionId } }, o.name) }, o.name)),
    h("button", { onclick: () => done({ outcome: { outcome: "cancelled" } }, "cancelled") }, "Cancel turn")));
  add(card);
  api.notify("BM23-TOOLZ", "Permission needed: " + (tc.title || "tool"));
});
api.onAcpExit((eng, code, tail) => { if (cur?.engine === eng) { setBusy(false); err(`${eng} engine stopped (code ${code}). ${tail || ""}\nIt restarts automatically on the next action.`); } });

// ---------------- composer ----------------
$("sendBtn").onclick = () => { const t = $("prompt").value; $("prompt").value = ""; sendText(t); };
$("stopBtn").onclick = () => { if (cur) { api.acpCancel(cur.engine, cur.sessionId); sys("stop requested"); } };
// Steer / queue work on every engine. MiniMax Code has native ACP extensions for both; OpenCode and Kilo
// don't, so queue holds messages client-side (sent when the turn ends) and steer interrupts the turn and
// sends the guidance next. If a native call fails, the attachments go back on the bar instead of being lost.
$("steerBtn").onclick = async () => {
  let text = $("prompt").value.trim(); if (!text || !cur) return toast("Type the guidance first.");
  const files = attached.splice(0); renderAttach(); text = [text, manifestText(files)].filter(Boolean).join("\n\n");
  if (cur.engine !== "mcode") {
    (cur.pending ||= []).unshift({ text }); $("prompt").value = "";
    api.acpCancel(cur.engine, cur.sessionId); sys("↪ redirect: stopping this turn, your guidance runs next");
    return;
  }
  try { await call("mcode/session/steer", { sessionId: cur.sessionId, text }, cur.engine); }
  catch { attached.push(...files); renderAttach(); return; }   // call() already showed the error
  $("prompt").value = ""; sys("steered: " + text);
};
$("queueBtn").onclick = async () => {
  let text = $("prompt").value.trim(); if (!text || !cur) return toast("Type the message to queue first.");
  const files = attached.splice(0); renderAttach(); text = [text, manifestText(files)].filter(Boolean).join("\n\n");
  if (cur.engine !== "mcode") {
    (cur.pending ||= []).push({ text }); $("prompt").value = "";
    sys(`queued #${cur.pending.length} (sends when this turn ends): ${text}`);
    return;
  }
  try { await call("mcode/session/queue/enqueue", { sessionId: cur.sessionId, text }, cur.engine); }
  catch { attached.push(...files); renderAttach(); return; }
  $("prompt").value = ""; sys("queued: " + text); renderQueue();
};
$("prompt").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("sendBtn").click(); }
  else if (e.key === "ArrowUp" && !$("prompt").value.includes("\n") && history.length) { histIdx = Math.min(histIdx + 1, history.length - 1); $("prompt").value = history[histIdx]; e.preventDefault(); }
  else if (e.key === "ArrowDown" && histIdx >= 0) { histIdx--; $("prompt").value = histIdx >= 0 ? history[histIdx] : ""; e.preventDefault(); }
});
$("prompt").addEventListener("input", () => { if ($("prompt").value === "/") { $("prompt").value = ""; openSkills(); } });

// ---------------- header controls ----------------
$("model").onchange = (e) => setModel(e.target.value);
$("perm").onchange = async (e) => { if (!cur) return; const r = await call("session/set_config_option", { sessionId: cur.sessionId, configId: "permissionMode", value: e.target.value }, cur.engine); applyConfig(r?.configOptions); };
$("freeOnly").onchange = (e) => { saveSettings({ freeOnly: e.target.checked }); applyConfig(); };
// Condense the live conversation into a seed prompt so a different provider can continue the
// same task instead of starting blank. Capped so it never blows a small free-model context.
function buildHandoff() {
  const body = transcript
    .filter((t) => t.role !== "think" && t.text && t.text.trim())   // private reasoning stays with the old provider
    .map((t) => (t.role === "tool" ? "[tool output]\n" + (t.text.length > 600 ? t.text.slice(0, 600) + " …" : t.text) : t.role.toUpperCase() + ": " + t.text))
    .join("\n\n");
  if (!body.trim()) return null;
  const capped = body.length > 12000 ? "…(earlier context trimmed for length)…\n\n" + body.slice(-12000) : body;
  return "[Continuing an in-progress coding task handed off from another provider. The conversation so far is below. Pick up exactly where it left off and keep working toward the same goal — do not restart or re-ask what is already settled.]\n\n"
    + capped + "\n\n[End of prior conversation — continue the task now.]";
}
$("engine").onchange = async (e) => {
  try { await window.ForgeChat.switchTo(e.target.value); } catch (x) { toast(x.message); }
};
$("newSess").onclick = () => newSession();
$("refreshSess").onclick = () => listSessions();
$("sessFilter").oninput = () => renderSessions();
$("sessHere").onchange = () => renderSessions();
$("forkBtn").onclick = async () => {
  if (!cur || cur.busy) return;
  const r = await call("session/fork", { sessionId: cur.sessionId, cwd: cur.cwd, mcpServers: [] }, cur.engine);
  await window.ForgeChat.fork(r); listSessions(); sys("forked");
};
$("closeSess").onclick = async () => { if (!cur) return; if (cur.busy) return toast("Stop the turn first."); await call("session/close", { sessionId: cur.sessionId }, cur.engine).catch(() => {}); await window.ForgeChat.detach(); clearThread(); sys("session closed"); listSessions(); };
$("exportBtn").onclick = () => {
  if (!transcript.length) return toast("Nothing to export.");
  const text = `# ${$("sessTitle").textContent}\n\n` + transcript.map((t) => t.role === "tool" ? "```\n" + t.text + "\n```" : `**${t.role}:**\n\n${t.text}`).join("\n\n");
  const a = h("a", { href: URL.createObjectURL(new Blob([text], { type: "text/markdown" })), download: `mcode-session-${Date.now()}.md` }); a.click();
};

// ---------------- sessions list (unified across every installed provider) ----------------
let sessions = [];
const ENGINE_LABEL = { mcode: "MiniMax", opencode: "OpenCode", kilo: "Kilo", codex: "Codex", claude: "Claude", hermes: "Hermes", native: "Direct" };
async function listSessions() {
  let avail = {};
  try { avail = await api.engines(); } catch {}
  // always include the current engine; include the others only when installed, so we never
  // spawn an agent for a provider the user doesn't have. One provider failing never empties
  // the list — each is isolated in its own try/catch.
  const engs = ["mcode", "opencode", "kilo", "hermes", "codex", "claude", "native"].filter((e) => e === engine || avail[e]);
  const all = [];
  await Promise.all(engs.map(async (e) => {
    try {
      const out = []; let cursor;
      for (let i = 0; i < 4; i++) { const r = await api.acpCall(e, "session/list", cursor ? { cursor } : {}); out.push(...(r.sessions || [])); cursor = r.nextCursor; if (!cursor) break; }
      for (const s of out) all.push({ ...s, engine: e });
    } catch {}
  }));
  all.sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
  if (window.ForgeChat) await window.ForgeChat.importSessions(all);
  else { sessions = all; renderSessions(); }
}
function renderSessions() {
  const q = $("sessFilter").value.toLowerCase(), here = $("sessHere").checked;
  const list = sessions.filter((s) => (!here || !s.cwd || s.cwd.toLowerCase() === String(S.cwd).toLowerCase()) && (!q || JSON.stringify(s).toLowerCase().includes(q)));
  const ago = (t) => { const s = (Date.now() - new Date(t)) / 1000; return s < 60 ? "now" : s < 3600 ? Math.floor(s / 60) + "m" : s < 86400 ? Math.floor(s / 3600) + "h" : Math.floor(s / 86400) + "d"; };
  const hue = (id) => { let x = 0; for (const c of String(id)) x = (x * 31 + c.charCodeAt(0)) % 360; return `hsl(${x} 90% 62%)`; };
  $("sessCount").textContent = list.length;
  $("sessList").replaceChildren(...(list.length ? list.map((s) => {
    const b = h("button", { class: "sess" + ((window.ForgeChat?.isActive(s) || cur?.sessionId === s.sessionId) ? " on" : "") + (s.engine && s.engine !== engine ? " other-engine" : ""), "data-id": s.sessionId, onclick: () => loadSession(s) },
      h("b", {}, (s.pinned ? "⌖ " : "") + (s.title || s.sessionId)),
      h("small", {}, h("span", { class: "eng-tag", "data-e": s.engine || engine }, [...new Set((s.bindings || [{ engine: s.engine || engine }]).map((b) => ENGINE_LABEL[b.engine] || b.engine))].join(" → ")), h("span", { class: "ago" }, s.updatedAt ? ago(s.updatedAt) : ""), (s.cwd || "").split(/[\\/]/).pop()));
    b.style.setProperty("--sh", hue(s.sessionId));
    return b;
  }) : [h("div", { class: "note" }, "No sessions yet.")]));
}

// ---------------- mcode-only panels: goal, queue, tasks ----------------
function mcodeOnly(pane) {
  if (cur?.engine === "mcode" && cur.sessionId) return false;
  $(pane).replaceChildren(h("p", { class: "note" }, engine === "mcode" ? "Start a session first." : "Goal, queue and background tasks are MiniMax Code features — switch ENGINE to MiniMax Code."));
  return true;
}
function refreshMcodePanels() { renderGoal(); renderQueue(); renderTasks(); }
async function renderGoal() {
  if (mcodeOnly("p-goal")) return;
  const r = await api.acpCall("mcode", "mcode/session/goal/get", { sessionId: cur.sessionId }).catch((e) => ({ error: e.message }));
  const g = r.goal;
  $("p-goal").replaceChildren(h("h3", {}, "SESSION GOAL"),
    g ? h("div", { class: "goalcard" }, h("div", { class: "badge " + (g.status === "active" ? "b-ok" : "b-warn") }, g.status), h("div", { class: "obj" }, g.objective),
      h("div", { class: "kv" }, "turns", String(g.turnsUsed), "tokens", String(g.tokensUsed), "time", g.timeUsedSeconds + "s", "budget", String(g.tokenBudget ?? "none"), ...(g.statusReason ? ["reason", g.statusReason] : [])),
      h("div", { class: "row" }, h("button", { class: "hot", onclick: async () => { await call("mcode/session/goal/clear", { sessionId: cur.sessionId }, "mcode"); renderGoal(); } }, "Clear goal")))
      : h("p", { class: "note" }, "No goal. A goal keeps the agent working toward an objective across turns."),
    h("label", {}, "New objective"), h("textarea", { id: "goalObj", rows: 3 }),
    h("div", { class: "row" }, h("button", { class: "acc", onclick: async () => {
      const objective = $("goalObj").value.trim(); if (!objective) return;
      await call("mcode/session/goal/create", { sessionId: cur.sessionId, objective }, "mcode"); renderGoal();
    } }, g ? "Replace goal" : "Set goal")));
}
async function renderQueue() {
  if (mcodeOnly("p-queue")) return;
  const r = await api.acpCall("mcode", "mcode/session/queue/list", { sessionId: cur.sessionId }).catch(() => ({ items: [] }));
  const items = r.items || [];
  $("p-queue").replaceChildren(h("h3", {}, "MESSAGE QUEUE"), h("p", { class: "note" }, "Messages here run after the current response. Use ⧉ QUEUE while the agent works."),
    ...(items.length ? items.map((it) => h("div", { class: "item" }, h("span", { title: it.content }, `${it.status} · ${it.content}`),
      h("button", { title: "Send now as steering", onclick: async () => { await call("mcode/session/queue/steer", { sessionId: cur.sessionId, itemId: it.itemId }, "mcode"); renderQueue(); } }, "steer"),
      h("button", { onclick: async () => { await call("mcode/session/queue/delete", { sessionId: cur.sessionId, itemId: it.itemId }, "mcode"); renderQueue(); } }, "✕"))) : [h("p", { class: "note" }, "Queue empty.")]),
    h("label", {}, "Add to queue"), h("input", { id: "qText" }),
    h("div", { class: "row" }, h("button", { class: "acc", onclick: async () => { const text = $("qText").value.trim(); if (!text) return; await call("mcode/session/queue/enqueue", { sessionId: cur.sessionId, text }, "mcode"); renderQueue(); } }, "Queue")));
}
async function renderTasks() {
  if (mcodeOnly("p-tasks")) return;
  const r = await api.acpCall("mcode", "mcode/session/delegation/get", { sessionId: cur.sessionId }).catch(() => ({}));
  const members = r.snapshot?.members || [];
  $("p-tasks").replaceChildren(h("h3", {}, "BACKGROUND AGENTS & TASKS"),
    ...(members.length ? members.map((m) => h("div", { class: "item" }, h("span", { title: JSON.stringify(m) }, `${m.status || ""} · ${m.title || m.name || m.sessionId || m.id}`), h("span"),
      h("button", { class: "hot", onclick: async () => { await call("mcode/session/delegation/stop", { sessionId: cur.sessionId, memberSessionId: m.sessionId, memberId: m.id }, "mcode"); renderTasks(); } }, "stop"))) : [h("p", { class: "note" }, "No background agents running.")]),
    h("div", { class: "row" }, h("button", { onclick: renderTasks }, "↻ Refresh")));
}

// ---------------- CLI-backed panels ----------------
const cliOut = {};
function outBox(pane) { return (cliOut[pane] ||= h("pre", { class: "out" }, "Output appears here.")); }
let cliRun = null;
function argsFrom(spec, v) {
  const args = [...spec.base], pos = [];
  for (const f of spec.fields) {
    const val = v[f.name];
    if (f.type === "bool") { if (val) args.push(f.name); continue; }
    if (!val) continue;
    if (f.name === "_pos") pos.push(val);
    else if (f.multi) val.split(",").map((x) => x.trim()).filter(Boolean).forEach((x) => args.push(f.name, x));
    else args.push(f.name, val);
  }
  return [...args, ...pos];
}
async function runCli(args, pane) {
  if (cliRun) api.cliStop(cliRun.id);
  const box = outBox(pane); box.textContent = `> mcode ${args.join(" ")}\n`;
  cliRun = { id: await api.cliRun(args, S.cwd), box };
  return new Promise((res) => (cliRun.done = res));
}
api.onCliData((id, text) => { if (cliRun?.id === id) { cliRun.box.textContent += text; cliRun.box.scrollTop = cliRun.box.scrollHeight; } });
api.onCliExit((id, code) => { if (cliRun?.id === id) { cliRun.box.textContent += `\n[exit ${code}]`; const d = cliRun.done; cliRun = null; d?.(code); } });
function openCli(spec, pane) {
  if (!spec.fields.length) return runCli(spec.base, pane);
  ask(spec.title, spec.fields, (v) => {
    const miss = spec.fields.filter((f) => f.required && !v[f.name]).map((f) => f.label);
    if (miss.length) return toast("Missing: " + miss.join(", "));
    runCli(argsFrom(spec, v), pane);
  });
}
function cliPane(pane, groups, extra = []) {
  $(pane).replaceChildren(...extra, ...CLI.filter((g) => groups.includes(g.group)).flatMap((g) => [h("h3", {}, g.group.toUpperCase()), ...g.items.map((s) => h("button", { class: "clitem", onclick: () => { showPane(pane.slice(2)); openCli(s, pane); } }, s.title))]),
    h("div", { class: "row" }, h("button", { onclick: () => cliRun && api.cliStop(cliRun.id) }, "■ Stop"), h("button", { onclick: () => api.copy(outBox(pane).textContent) }, "Copy output")), outBox(pane));
}
function agentBtn(label, text) { return h("button", { class: "clitem", onclick: () => sendText(text) }, label); }
function renderCliPanes() {
  cliPane("p-plugins", ["Plugins"], [h("button", { class: "acc", onclick: () => window.openPluginBay?.("plugins") }, "⬢ OPEN PLUGIN BAY"), h("p", { class: "note" }, "After installing or enabling, press “Restart engine” in SYSTEM so sessions pick up new Skills/commands.")]);
  cliPane("p-providers", ["Providers"]);
  cliPane("p-account", ["Account"], [h("h3", {}, "IN-SESSION"), agentBtn("Account & model status (/status)", "/status"), agentBtn("Usage (/usage)", "/usage")]);
  cliPane("p-system", ["System", "Headless run"], [
    h("h3", {}, "ENGINE"),
    h("button", { class: "clitem", onclick: async () => { if (cur?.busy) return toast("Stop the turn first."); await window.ForgeChat.flush(); await api.acpRestart(engine); cur = null; setTimeout(() => window.ForgeChat.switchTo(engine, true).catch((e) => toast(e.message)), 500); } }, "↻ Restart engine (reload config & plugins)"),
    h("h3", {}, "IN-SESSION DIAGNOSTICS"),
    agentBtn("Check config (/doctor)", "/doctor"), agentBtn("Context snapshot (/context)", "/context"), agentBtn("Skills (/skills)", "/skills"), agentBtn("MCP servers (/mcp)", "/mcp"), agentBtn("Compact conversation (/compact)", "/compact"), agentBtn("Help (/help)", "/help"),
  ]);
}

// ---------------- FREE models ----------------
const PROXY_PROVIDER = "custom_provider:free-proxy";
async function renderFree() {
  $("p-free").replaceChildren(
    h("h3", {}, "HOW FREE MODELS WORK HERE"),
    h("p", { class: "note" }, "Tick FREE in the header, then pick from MODEL. MiniMax Code uses verified free Kilo models through the local proxy. Nous inference requires credentials and is not automatically free. Hermes Agent is a separate engine with its own configured providers. OpenCode and Kilo engines use their own free models directly."),
    h("div", { class: "row" },
      h("button", { class: "acc", onclick: () => switchEngine("mcode") }, "MiniMax Code + Kilo free"),
      h("button", { class: "acc", onclick: () => switchEngine("opencode") }, "OpenCode Zen free"),
      h("button", { class: "acc", onclick: () => switchEngine("kilo") }, "Kilo free")),
    h("h3", {}, "GATEWAY MODELS (for MiniMax Code)"),
    h("div", { class: "row" }, h("button", { onclick: renderFree }, "↻ Refresh"), h("button", { class: "acc", onclick: registerKilo }, "Register all in MiniMax Code")),
    h("div", { id: "kiloProxyList" }, h("p", { class: "note" }, "loading…")), outBox("p-free"));
  const status = await api.proxyEnsure();
  $("stProxy").textContent = "proxy " + status; $("stProxy").style.color = status === "online" ? "var(--ok)" : "var(--bad)";
  try {
    const ids = await api.proxyModels();
    $("kiloProxyList").replaceChildren(...ids.map((id) => {
      const b = h("button", {}, "test");
      b.onclick = async () => { b.textContent = "…"; const s = await api.proxyTest(id); b.textContent = s === 200 ? "✓ ok" : "✗ " + s; b.className = "badge " + (s === 200 ? "b-ok" : s === 429 ? "b-warn" : "b-bad"); };
      return h("div", { class: "item" }, h("span", { title: id }, id), b, h("span"));
    }));
  } catch (e) { $("kiloProxyList").replaceChildren(h("p", { class: "note" }, "Proxy unavailable: " + e.message)); }
}
async function registerKilo() {
  const ids = await api.proxyModels();
  await runCli(["provider", "remove", PROXY_PROVIDER, "--yes"], "p-free");
  await runCli(["provider", "add", "--name", "free-proxy", "--base-url", "http://127.0.0.1:7799/v1", "--api-format", "openai-completions", "--api-key-env", "FREE_PROXY_KEY",
    "--context-limit", "128000", "--output-limit", "16000", ...ids.flatMap((id) => ["--model", id])], "p-free");
  if (engine === "mcode") { await window.ForgeChat.flush(); await api.acpRestart("mcode"); cur = null; setTimeout(() => window.ForgeChat.switchTo("mcode", true).catch((e) => toast(e.message)), 500); }
}
function switchEngine(e) { $("engine").value = e; $("freeOnly").checked = true; $("engine").onchange({ target: $("engine") }); }

// ---------------- files, snippets ----------------
async function loadFiles() {
  $("p-files").replaceChildren(h("h3", {}, "PROJECT FILES"), h("p", { class: "note" }, "Click = mention in message · double-click = open · right-click = attach to message"), h("div", { id: "tree" }));
  if (S.cwd) $("tree").append(...await dirNodes(S.cwd, 0));
}
async function dirNodes(dir, depth) {
  return (await api.listDir(dir)).slice(0, 400).map((it) => {
    const pad = `padding-left:${6 + depth * 14}px`;
    if (it.dir) {
      const kids = h("div"); let open = false;
      const b = h("button", { class: "file", style: pad, oncontextmenu: async (e) => { e.preventDefault(); addAttachments(await api.uploadDescribe([it.path])); }, onclick: async () => { open = !open; b.firstChild.textContent = open ? "▾ " : "▸ "; kids.replaceChildren(...(open ? await dirNodes(it.path, depth + 1) : [])); } }, h("span", {}, "▸ "), it.name + "/");
      return h("div", {}, b, kids);
    }
    return h("button", { class: "file", style: pad, "data-path": it.path, oncontextmenu: async (e) => { e.preventDefault(); addAttachments(await api.uploadDescribe([it.path])); }, onclick: () => { const p = $("prompt"); p.value += (p.value && !p.value.endsWith(" ") ? " " : "") + "@" + it.path + " "; p.focus(); }, ondblclick: () => api.openPath(it.path) }, "  " + it.name);
  });
}
function renderSnips() {
  $("p-snips").replaceChildren(h("h3", {}, "PROMPT SNIPPETS"),
    ...(S.snippets || []).map((s, i) => h("div", { class: "item" }, h("span", { title: s.text }, s.name),
      h("button", { onclick: () => { $("prompt").value = s.text; $("prompt").focus(); } }, "use"),
      h("button", { onclick: () => saveSettings({ snippets: S.snippets.filter((_, j) => j !== i) }).then(renderSnips) }, "✕"))),
    h("div", { class: "row" },
      h("button", { class: "acc", onclick: () => ask("New snippet", [{ name: "name", label: "Name", type: "text" }, { name: "text", label: "Prompt", type: "text", area: true }], (v) => v.name && v.text && saveSettings({ snippets: [...(S.snippets || []), v] }).then(renderSnips), "Save") }, "＋ New"),
      h("button", { onclick: () => { const t = $("prompt").value.trim(); if (t) ask("Save message as snippet", [{ name: "name", label: "Name", type: "text" }], (v) => v.name && saveSettings({ snippets: [...(S.snippets || []), { name: v.name, text: t }] }).then(renderSnips), "Save"); } }, "Save current message")),
    h("h3", {}, "SETTINGS"),
    h("label", {}, "MiniMax Code source folder"), h("input", { id: "prefDir", value: S.mcodeDir }),
    h("p", { class: "note" }, S.cliExists ? "✓ dist/cli.js found" : "✗ dist/cli.js missing — run pnpm build there"),
    h("label", { class: "chk" }, h("input", { id: "prefNotify", type: "checkbox", ...(S.notify !== false ? { checked: true } : {}) }), "Desktop notification when the agent finishes or needs permission"),
    h("div", { class: "row" }, h("button", { class: "acc", onclick: async () => { await saveSettings({ mcodeDir: $("prefDir").value.trim(), notify: $("prefNotify").checked }); renderSnips(); toast("Saved."); } }, "Save settings")));
}

// ---------------- feature map: every TUI command → where it lives ----------------
const MAP = [
  ["/new, /clear", "＋ NEW SESSION"], ["/sessions, /resume, /history", "Sessions list (left) with search"], ["/fork", "⑂ Fork (top bar)"],
  ["/export", "⤓ Export (top bar)"], ["/transcript", "The conversation view itself"], ["/copy", "copy button on each reply"],
  ["/rename, /archive", "✕ Close session; rename/archive are terminal-only (not exposed over ACP)", 1],
  ["/rewind, /edit, /retry", "Not exposed over ACP; use ↑ in the message box to resend", 1],
  ["/compact /usage /context /status /doctor /skills /mcp /help /model", "Command chips above the message box + SYSTEM/ACCOUNT panels"],
  ["/goal", "GOAL panel"], ["/plan", "Default / Plan switch (top bar)"], ["/steer", "➤ STEER while the agent works"], ["/queue", "⧉ QUEUE button + QUEUE panel"],
  ["/stop", "■ STOP"], ["/tasks", "TASKS panel"], ["/btw, /side, /parent", "⑂ Fork gives a side branch; live side-chat is terminal-only", 1],
  ["/review", "SYSTEM → exec review"], ["/permission, /permissions, /allow, /always, /deny", "🔒 permission selector + inline permission cards"],
  ["/model, /provider", "MODEL selector + PROVIDERS panel"], ["/login, /logout", "ACCOUNT panel"], ["/checkin, /feedback", "Terminal-only (no CLI/ACP entry point)", 1],
  ["/plugins, /reload", "PLUGINS panel + Restart engine"], ["/add-dir", "Change project with 📁; extra dirs are terminal-only", 1],
  ["/settings /theme /statusline /hotkeys /config", "This app's own look & SNIPPETS → Settings; terminal cosmetics don't apply", 1],
  ["/update, /changelog", "SYSTEM → Update"], ["/decision", "Inline permission cards"], ["/quit", "Close the window"],
  ["mcode exec / init / telemetry", "SYSTEM panel forms"], ["mcode acp", "This app runs on it"],
];
function renderMap() {
  $("p-map").replaceChildren(h("h3", {}, "EVERY MINIMAX CODE FEATURE → WHERE IT IS"), h("table", { class: "map" }, MAP.map(([k, v, na]) => h("tr", {}, h("td", {}, k), h("td", { class: na ? "na" : "" }, v)))));
}

// ---------------- modal / toast ----------------
function fieldEl(f, i) {
  const id = "fld" + i;
  if (f.type === "bool") return h("label", { class: "chk" }, h("input", { type: "checkbox", id }), f.label);
  const lab = h("label", { for: id }, f.label + (f.required ? " *" : ""));
  if (f.type === "select") return [lab, h("select", { id }, f.options.map((o) => h("option", { value: o }, o || "(default)")))];
  return [lab, f.area ? h("textarea", { id, rows: 4 }) : h("input", { id })];
}
function ask(title, fields, onOk, okLabel = "Run") {
  $("mTitle").textContent = title;
  $("mBody").replaceChildren(...fields.flatMap((f, i) => [fieldEl(f, i)].flat()));
  $("mOk").textContent = okLabel; $("modal").hidden = false;
  $("mBody").querySelector("input,textarea,select")?.focus();
  const done = (ok) => {
    $("modal").hidden = true; document.removeEventListener("keydown", key);
    if (!ok) return;
    const v = {}; fields.forEach((f, i) => { const e = $("fld" + i); v[f.name] = f.type === "bool" ? e.checked : e.value.trim(); }); onOk(v);
  };
  const key = (e) => { if (e.key === "Escape") done(false); if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") done(true); };
  document.addEventListener("keydown", key);
  $("mOk").onclick = () => done(true); $("mCancel").onclick = () => done(false);
}
function toast(msg) { const t = h("div", { role: "status", style: "position:fixed;bottom:40px;left:50%;transform:translateX(-50%);z-index:82;background:var(--panel2);border:1px solid var(--hot);padding:9px 16px;border-radius:9px" }, msg); document.body.append(t); setTimeout(() => t.remove(), 3200); }

// ---------------- panes, project, palette ----------------
const TAB_COLORS = {
  control: ["#27d8ff", "#ff355e"],
  goal: ["#ffc83a", "#ff6a3d"], queue: ["#a78bff", "#ff5fd2"], tasks: ["#b6ff3b", "#2affc4"], free: ["#2ad4ff", "#3bff9a"],
  plugins: ["#ff3fb4", "#8a7dff"], providers: ["#ff8a3d", "#ffd23a"], account: ["#4aa3ff", "#2ad4ff"], system: ["#ff4f5e", "#ffb020"],
  files: ["#3bffc4", "#4aa3ff"], snips: ["#ff7ccf", "#ffc83a"], map: ["#e8f6ff", "#2ad4ff"],
};
document.querySelectorAll("#rtabs button").forEach((b) => b.style.setProperty("--tc", (TAB_COLORS[b.dataset.p] || [])[0]));
function applyTabColor(p) {
  const c = (S && S.cfg) || {};
  const [a, b] = c.accent ? [c.accent, c.accent2 || c.accent] : (TAB_COLORS[p] || TAB_COLORS.free);
  document.documentElement.style.setProperty("--tab", a);
  document.documentElement.style.setProperty("--tab2", b);
  window.FORM?.setColors(a, b);
}
function showPane(p) {
  document.querySelectorAll("#rtabs button").forEach((b) => b.classList.toggle("on", b.dataset.p === p));
  document.querySelectorAll(".pane").forEach((x) => x.classList.toggle("on", x.id === "p-" + p));
  applyTabColor(p);
}
addEventListener("form-ready", () => applyTabColor(document.querySelector("#rtabs button.on")?.dataset.p || "goal"));
document.querySelectorAll("#rtabs button").forEach((b) => (b.onclick = () => showPane(b.dataset.p)));
async function saveSettings(patch) { S = await api.saveSettings(patch); renderProject(); }
// Settings > Behaviour writes cfg.notify; the SNIPPETS pane writes top-level notify. The cfg one wins when set.
function notifyOn() { return (S.cfg?.notify ?? S.notify) !== false; }
function renderProject() {
  $("projName").textContent = S.cwd; $("projBtn").title = S.cwd;
  $("recents").innerHTML = `<option value="">recent…</option>` + (S.recents || []).map((r) => `<option>${esc(r)}</option>`).join("");
}
async function setProject(dir) {
  if (!dir) return;
  if (cur?.busy) throw new Error('Stop the current turn before changing workspaces.');
  await window.ForgeChat?.detach();
  await saveSettings({ cwd: dir, recents: [dir, ...(S.recents || []).filter((r) => r !== dir)].slice(0, 12) });
  cur = null; clearThread(); loadFiles(); await newSession(); listSessions();
}
$("projBtn").onclick = async () => setProject(await api.pickFolder());
$("recents").onchange = (e) => { setProject(e.target.value); e.target.value = ""; };

function paletteItems() {
  return [
    { t: "New session", s: "session", run: newSession },
    { t: "Stop agent", s: "session", run: () => $("stopBtn").click() },
    { t: "Fork session", s: "session", run: () => $("forkBtn").click() },
    { t: "Export conversation", s: "session", run: () => $("exportBtn").click() },
    { t: "Change project folder", s: "project", run: () => $("projBtn").click() },
    { t: "Toggle zen mode", s: "view", run: toggleZen },
    ...["mcode", "opencode", "kilo", "hermes", "codex", "claude", "native"].map((e) => ({ t: "Engine: " + e, s: "engine", run: () => switchEngine(e) })),
    ...(cur?.modes?.availableModes || []).map((m) => ({ t: "Mode: " + m.name, s: m.description, run: () => setMode(m.id) })),
    ...(cur?.commands || []).map((c) => ({ t: "/" + c.name, s: c.description, run: () => runAgentCommand(c) })),
    ...[...$("model").options].map((o) => ({ t: "Model: " + o.text, s: "model", run: () => { $("model").value = o.value; setModel(o.value); } })),
    ...[...document.querySelectorAll("#rtabs button")].map((b) => ({ t: "Panel: " + b.textContent, s: "panel", run: () => showPane(b.dataset.p) })),
    ...CLI.flatMap((g) => g.items.map((spec) => ({ t: spec.title, s: "mcode " + spec.base.join(" "), run: () => openCli(spec, "p-system") }))),
    ...sessions.slice(0, 30).map((s) => ({ t: "Open session " + (s.title || s.sessionId), s: (s.cwd || "").split(/[\\/]/).pop(), run: () => loadSession(s) })),
    ...(S.snippets || []).map((sn) => ({ t: "Snippet: " + sn.name, s: "insert", run: () => { $("prompt").value = sn.text; $("prompt").focus(); } })),
  ];
}
let pSel = 0, pShown = [];
function renderPalette() {
  const q = $("pInput").value.toLowerCase().split(/\s+/).filter(Boolean);
  pShown = paletteItems().filter((i) => q.every((w) => (i.t + " " + i.s).toLowerCase().includes(w))).slice(0, 80);
  pSel = Math.min(pSel, Math.max(0, pShown.length - 1));
  $("pList").replaceChildren(...pShown.map((i, k) => h("div", { class: "pi" + (k === pSel ? " sel" : ""), onclick: () => { closePalette(); i.run(); } }, h("span", {}, i.t), h("small", {}, i.s || ""))));
}
function openPalette(prefill = "") { $("palette").hidden = false; $("pInput").value = prefill; pSel = 0; renderPalette(); $("pInput").focus(); if (prefill === "/" && $("prompt").value === "/") $("prompt").value = ""; }
function closePalette() { $("palette").hidden = true; }
$("pInput").oninput = () => { pSel = 0; renderPalette(); };
$("pInput").onkeydown = (e) => {
  if (e.key === "ArrowDown") { pSel = Math.min(pSel + 1, pShown.length - 1); renderPalette(); e.preventDefault(); }
  else if (e.key === "ArrowUp") { pSel = Math.max(pSel - 1, 0); renderPalette(); e.preventDefault(); }
  else if (e.key === "Enter" && pShown[pSel]) { const i = pShown[pSel]; closePalette(); i.run(); }
  else if (e.key === "Escape") closePalette();
};
$("palette").onclick = (e) => { if (e.target.id === "palette") closePalette(); };
$("paletteBtn").onclick = () => openPalette();
function setSide(side, collapsed) {
  document.body.classList.toggle(side + "col", collapsed);
  $(side + "Tog").textContent = side === "l" ? (collapsed ? "▶" : "◀") : (collapsed ? "◀" : "▶");
  try { localStorage.setItem("side-" + side, collapsed ? "1" : "0"); } catch {}
  window.FORM?.pulse(0.6);
}
$("lTog").onclick = () => setSide("l", !document.body.classList.contains("lcol"));
$("rTog").onclick = () => setSide("r", !document.body.classList.contains("rcol"));
try { if (localStorage.getItem("side-l") === "1") setSide("l", true); if (localStorage.getItem("side-r") === "1") setSide("r", true); } catch {}
addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key === "[") { e.preventDefault(); $("lTog").click(); }
  if (e.ctrlKey && e.key === "]") { e.preventDefault(); $("rTog").click(); }
});
function toggleZen() {
  const on = document.body.classList.toggle("zen");
  $("zenHud").hidden = !on;
  window.FORM?.pulse(1.5);
}
$("zenExit").onclick = toggleZen;
const bootT = Date.now();
setInterval(() => {
  if ($("zenHud").hidden) return;
  $("zhState").textContent = cur?.busy ? "WORKING" : "IDLE";
  $("zhEngine").textContent = engine;
  $("zhModel").textContent = $("model").selectedOptions[0]?.text || "—";
  $("zhTok").textContent = $("usageTxt").textContent.split(" tokens")[0] || "—";
  const s = Math.floor((Date.now() - bootT) / 1000);
  $("zhUp").textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
}, 500);
$("zenBtn").onclick = toggleZen;
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); }
  else if (e.key === "F11") { e.preventDefault(); toggleZen(); }
  else if (e.ctrlKey && e.key.toLowerCase() === "n") { e.preventDefault(); newSession(); }
  else if (e.key === "Escape" && cur?.busy && $("palette").hidden && $("modal").hidden) $("stopBtn").click();
});

// ---------------- background ----------------
const bg = { energy: 0, e: 0 };
(function animate() {
  const c = $("bg"), g = c.getContext("2d");
  const pts = Array.from({ length: 90 }, () => ({ x: Math.random(), y: Math.random(), v: 0.0002 + Math.random() * 0.0006 }));
  function frame(t) {
    const w = (c.width = innerWidth), hh = (c.height = innerHeight);
    bg.e += (bg.energy - bg.e) * 0.03;
    g.fillStyle = "#04060c"; g.fillRect(0, 0, w, hh);
    const horizon = hh * 0.55, speed = t * (0.02 + bg.e * 0.06);
    g.strokeStyle = `rgba(42,212,255,${0.08 + bg.e * 0.1})`; g.lineWidth = 1;
    for (let i = 0; i < 26; i++) { const y = horizon + Math.pow(((i * 40 + speed) % 1040) / 1040, 2.2) * (hh - horizon); g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
    for (let i = -20; i <= 20; i++) { g.beginPath(); g.moveTo(w / 2 + i * 18, horizon); g.lineTo(w / 2 + i * w * 0.09, hh); g.stroke(); }
    const grd = g.createRadialGradient(w / 2, horizon, 0, w / 2, horizon, w * 0.5);
    grd.addColorStop(0, `rgba(255,63,180,${0.12 + bg.e * 0.14})`); grd.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = grd; g.fillRect(0, 0, w, hh);
    for (const p of pts) { p.y -= p.v * (1 + bg.e * 4); if (p.y < 0) p.y = 1; g.fillStyle = `rgba(120,210,255,${0.25 + 0.5 * Math.sin(t * 0.002 + p.x * 9) ** 2})`; g.fillRect(p.x * w, p.y * hh, 1.6, 1.6); }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
setInterval(() => { $("stClock").textContent = new Date().toLocaleTimeString(); }, 1000);

// ---------------- right-click menu ----------------
function insertPrompt(text) { const p = $("prompt"); p.value += (p.value && !p.value.endsWith(" ") ? " " : "") + text; p.focus(); }
document.addEventListener("contextmenu", (e) => {
  e.preventDefault();
  const sel = String(getSelection() || "").trim();
  const editable = e.target.closest("input,textarea");
  const file = e.target.closest(".file[data-path]");
  const msg = e.target.closest(".msg");
  const sess = e.target.closest(".sess");
  const items = [];
  const it = (label, fn, enabled = true) => items.push({ label, fn, enabled });
  const sep = () => items.push(null);
  it("Cut", () => api.edit("cut"), !!editable && !!sel);
  it("Copy", () => api.edit("copy"), !!sel);
  it("Paste", () => api.edit("paste"), !!editable);
  it("Select all", () => api.edit("selectAll"));
  if (sel) {
    sep();
    it("Send selection to agent", () => sendText(sel));
    it("Ask agent to explain selection", () => sendText("Explain this:\n\n" + sel));
    it("Put selection in message box", () => insertPrompt(sel));
    it("Save selection as snippet", () => ask("Save snippet", [{ name: "name", label: "Name", type: "text" }], (v) => v.name && saveSettings({ snippets: [...(S.snippets || []), { name: v.name, text: sel }] }).then(renderSnips), "Save"));
  }
  if (file) {
    const p = file.dataset.path;
    sep();
    it("@mention file in message", () => insertPrompt("@" + p + " "));
    it("Ask agent to review this file", () => sendText(`Review @${p} and list any bugs or improvements.`));
    it("Ask agent to explain this file", () => sendText(`Explain what @${p} does.`));
    it("Open file", () => api.openPath(p));
    it("Copy path", () => api.copy(p));
  }
  if (msg) {
    const text = msg.classList.contains("agent") ? msg.firstChild?.innerText || msg.innerText : msg.innerText;
    sep();
    it("Copy message", () => api.copy(text));
    if (msg.classList.contains("user")) it("Resend message", () => sendText(text));
  }
  if (sess) {
    sep();
    it("Open session", () => sess.click());
    it("Copy session id", () => api.copy(sess.dataset.id));
  }
  sep();
  it("New session", () => newSession());
  it("Skills…", openSkills);
  it("Command palette (Ctrl+K)", () => openPalette());
  const m = $("ctx");
  const clean = items.filter((x, i, a) => x || (i > 0 && a[i - 1] && i < a.length - 1));
  m.replaceChildren(...clean.map((x) => x ? h("button", { disabled: !x.enabled, onclick: () => { m.hidden = true; x.fn(); } }, x.label) : h("hr")));
  m.hidden = false;
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(e.clientX, innerWidth - r.width - 6) + "px";
  m.style.top = Math.min(e.clientY, innerHeight - r.height - 6) + "px";
});
addEventListener("mousedown", (e) => { if (!e.target.closest("#ctx")) $("ctx").hidden = true; });
addEventListener("blur", () => ($("ctx").hidden = true));

// ---------------- pages ----------------
let labBuilt = false;
async function buildLab() {
  try { const r = await api.labBuildPage(); $("page-guilab").src = "lab/gui-lab.html?t=" + Date.now(); labBuilt = true; return r; }
  catch (e) { toast("GUI Lab scan failed: " + e.message); }
}
function showPage(name) {
  document.querySelectorAll("#pages button").forEach((b) => b.classList.toggle("on", b.dataset.page === name));
  document.querySelectorAll(".page").forEach((f) => {
    const on = f.id === "page-" + name;
    if (on && f.id === "page-guilab" && !labBuilt) buildLab();
    else if (on && f.tagName === "IFRAME" && !f.src) f.src = f.dataset.src;
    f.classList.toggle("on", on);
  });
  document.body.classList.toggle("onpage", name !== "code");
  dispatchEvent(new CustomEvent("forge-page", { detail: name }));
}
// ---------------- AUTO-BUILD: churn GUIs from the Forge, one fresh session each ----------------
const auto = { on: false, done: 0, total: 0, files: [] };
function autoChip() {
  let c = $("autoChip");
  if (!c) {
    c = h("div", { id: "autoChip" }, h("span", { class: "ac-dot" }), h("span", { id: "autoTxt" }),
      h("button", { id: "autoStop", onclick: () => { auto.on = false; window.ForgeMission?.stop(); $("autoTxt").textContent = "stopping…"; } }, "■ STOP"));
    document.body.append(c);
  }
  c.hidden = !auto.on;
  $("autoTxt").textContent = `AUTO-BUILD ${auto.done}/${auto.total || "∞"} · ${auto.files.length} saved`;
}
function pick(arr, n) { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a.slice(0, n); }
async function runAuto(d) {
  if (auto.on) return toast("Auto-build already running.");
  const group = await askGroup(d.name); if (group === null) return;
  Object.assign(auto, { on: true, done: 0, total: d.count || 0, files: [] });
  autoChip();
  const dir = await api.labForgedDir(group);
  const slug = (d.name || "gui").replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "").toUpperCase().slice(0, 30) || "GUI";
  while (auto.on && (!auto.total || auto.done < auto.total)) {
    const n = auto.done + 1;
    const file = `${dir}\\FORGED_${slug}_${Date.now().toString(36)}.html`;
    const refs = pick(d.pool, 4).map((p) => `- ${p}`).join("\n");
    const text = d.template.replace("- {{REFS}}", refs) +
      `\n\nAUTO-BUILD #${n}: pick a theme, palette and centrepiece that is clearly DIFFERENT from any previous build in this run.` +
      `\n\nWrite the finished GUI as ONE self-contained HTML file and save it to:\n${file}\nThen reply with the file path.`;
    await newSession();
    dockStart(`AUTO ${n}/${auto.total || "∞"} · ${d.name || "GUI"} → ${group || "FORGED"}`, file);
    await window.ForgeMission.startMonitor(text);
    const result = await sendText(text);
    await api.monitorTurnEnded(); const reviewed = await api.monitorReview();
    if (!result?.ok || !reviewed?.ok) { auto.on = false; sys('Auto-build stopped by its supervisor or worker failure.'); break; }
    await dockEnd();
    if (await fileExists(file)) auto.files.push(file);
    auto.done++; labBuilt = false; autoChip();
    window.FORM?.pulse(2);
  }
  auto.on = false; autoChip();
  sys(`AUTO-BUILD finished — ${auto.files.length} of ${auto.done} saved to ${dir}. They appear in GUI LAB under FORGED.`);
  if (notifyOn()) api.notify("BM23-TOOLZ", `Auto-build done: ${auto.files.length} GUIs`);
}
async function fileExists(p) { try { return (await api.listDir(p.replace(/\\[^\\]+$/, ""))).some((f) => f.path === p); } catch { return false; } }

// bridge from the GUI Lab iframe (sandboxed, no IPC of its own)
addEventListener("message", async (e) => {
  const d = e.data;
  if (!d || typeof d !== "object") return;
  if (d.lab === "copy" && typeof d.text === "string") api.copy(d.text);
  else if (d.lab === "auto" && typeof d.template === "string" && Array.isArray(d.pool)) runAuto(d);
  else if (d.lab === "build" && typeof d.text === "string") {
    const group = await askGroup(d.name); if (group === null) return;
    const dir = await api.labForgedDir(group);
    const slug = (d.name || "gui").replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "").toUpperCase().slice(0, 40) || "GUI";
    const file = `${dir}\\FORGED_${slug}_${Date.now().toString(36)}.html`;
    await newSession();
    dockStart(`${d.name || "GUI"} → ${group || "FORGED"}`, file);
    await sendText(d.text + `

Write the finished GUI as ONE self-contained HTML file and save it to:
${file}
Then reply with the file path.`);
    await dockEnd(); labBuilt = false;
  }

  else if (d.lab === "import") {
    const dir = await api.labAddFolder();
    if (dir) { const r = await buildLab(); toast(`Imported ${dir.split(/[\\/]/).pop()} — ${r?.count || 0} designs, ${r?.dupes || 0} dupes hidden`); }
  }
});
document.querySelectorAll("#pages button").forEach((b) => (b.onclick = () => showPage(b.dataset.page)));

// ---------------- boot ----------------
(async () => {
  if (document.readyState === 'loading') await new Promise((resolve) => document.addEventListener('DOMContentLoaded', resolve, { once: true }));
  S = await api.settings();
  applyCfg();   // saved font/theme/opacity/reactor/boids settings take effect at startup, not only after a change
  addEventListener("form-ready", () => window.FORM?.config?.(cfg()));   // the reactor module can mount after this
  $("freeOnly").checked = S.freeOnly !== false;
  renderProject(); renderCliPanes(); renderSnips(); renderMap(); loadFiles(); renderFree();
  $("stEngine").textContent = "engine " + engine;
  const installed = await api.engines();
  engine = installed[S.defaultEngine] ? S.defaultEngine : installed.codex ? 'codex' : installed.claude ? 'claude' : installed.mcode ? 'mcode' : installed.hermes ? 'hermes' : installed.opencode ? 'opencode' : installed.kilo ? 'kilo' : 'native';
  $('engine').value = engine; $('stEngine').textContent = 'engine ' + engine;
  await window.ForgeChat?.init();
  window.dispatchEvent(new Event('forge-ready'));
  try { await api.acpStart(engine); await listSessions(); refreshMcodePanels(); }
  catch (e) { err(e.message); }
})();

// ---------------- annotator: draw on the live UI, send a precise change list to the agent ----------------
(() => {
  const ov = $("anno"), cv = $("annoCanvas"), g = cv.getContext("2d");
  let pen = document.querySelector("#annoBar .pen.on"), strokes = [], cur = null, textMode = false;
  const notes = [];
  const size = () => { cv.width = innerWidth * devicePixelRatio; cv.height = innerHeight * devicePixelRatio; g.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0); redraw(); };
  function redraw() {
    g.clearRect(0, 0, cv.width, cv.height);
    for (const s of strokes) {
      g.strokeStyle = s.c; g.lineWidth = 4; g.lineJoin = g.lineCap = "round";
      g.beginPath(); s.pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.stroke();
    }
  }
  function open() { ov.hidden = false; size(); window.FORM?.pulse(1); }
  function close() { ov.hidden = true; strokes = []; notes.splice(0).forEach((n) => n.el.remove()); redraw(); }
  $("annoBtn").onclick = open;
  addEventListener("keydown", (e) => { if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "a") { e.preventDefault(); ov.hidden ? open() : close(); } if (e.key === "Escape" && !ov.hidden && !e.target.classList.contains("annoNote")) close(); });
  addEventListener("resize", () => { if (!ov.hidden) size(); });
  document.querySelectorAll("#annoBar .pen").forEach((b) => (b.onclick = (e) => {
    if (e.target.tagName === "INPUT") return;
    document.querySelectorAll("#annoBar .pen").forEach((x) => x.classList.toggle("on", x === b)); pen = b;
  }));
  $("annoText").onclick = () => { textMode = !textMode; $("annoText").classList.toggle("on", textMode); };
  $("annoUndo").onclick = () => { strokes.pop(); redraw(); };
  $("annoClear").onclick = () => { strokes = []; notes.splice(0).forEach((n) => n.el.remove()); redraw(); };
  $("annoCancel").onclick = close;
  cv.addEventListener("pointerdown", (e) => {
    if (textMode) {
      const el = h("div", { class: "annoNote", contenteditable: "true", style: `left:${e.clientX}px;top:${e.clientY}px;color:${pen.dataset.c}` });
      document.body.append(el); el.focus();
      notes.push({ el, x: e.clientX, y: e.clientY, k: pen.dataset.k });
      textMode = false; $("annoText").classList.remove("on");
      return;
    }
    cur = { c: pen.dataset.c, k: pen.dataset.k, pts: [[e.clientX, e.clientY]] }; strokes.push(cur);
  });
  cv.addEventListener("pointermove", (e) => { if (cur) { cur.pts.push([e.clientX, e.clientY]); redraw(); } });
  addEventListener("pointerup", () => (cur = null));

  const describe = (el) => {
    let s = el.tagName.toLowerCase();
    if (el.id) return s + "#" + el.id;
    const c = [...el.classList].filter((x) => !/^(on|in)$/.test(x)).slice(0, 2).join(".");
    if (c) s += "." + c;
    const label = (el.getAttribute("title") || el.innerText || el.placeholder || "").trim().split("\n")[0].slice(0, 40);
    return label ? `${s} “${label}”` : s;
  };
  function elementsAt(pts) {
    const found = new Map();
    ov.style.pointerEvents = "none"; cv.style.pointerEvents = "none";
    const step = Math.max(1, Math.floor(pts.length / 40));
    for (let i = 0; i < pts.length; i += step) {
      const el = document.elementFromPoint(pts[i][0], pts[i][1]);
      if (!el || el.closest("#anno")) continue;
      const key = el.closest("[id]") || el;
      const d = describe(key);
      found.set(d, (found.get(d) || 0) + 1);
    }
    ov.style.pointerEvents = ""; cv.style.pointerEvents = "";
    return [...found.entries()].sort((a, b) => b[1] - a[1]).map(([d]) => d);
  }
  $("annoSend").onclick = async () => {
    if (!strokes.length && !notes.length) return toast("Draw on the UI or drop a note first.");
    const legend = {};
    document.querySelectorAll("#annoBar .pen").forEach((b) => (legend[b.dataset.k] = b.querySelector("input").value));
    const byColour = {};
    for (const s of strokes) (byColour[s.k] ||= new Set()) && elementsAt(s.pts).forEach((d) => byColour[s.k].add(d));
    const shot = await api.captureWindow();
    const noteLines = notes.map((n) => {
      ov.style.pointerEvents = "none"; n.el.style.display = "none";
      const el = document.elementFromPoint(n.x, n.y);
      n.el.style.display = ""; ov.style.pointerEvents = "";
      return `- [${n.k.toUpperCase()}] on ${el && !el.closest("#anno") ? describe(el.closest("[id]") || el) : "screen"}: ${n.el.innerText.trim()}`;
    }).filter((l) => !l.endsWith(": "));
    const text = [
      `UI annotations for the BM23-TOOLZ Coder IDE (source: C:\dev\mcode-gui\renderer — index.html, style.css, app.js).`,
      `Marked-up screenshot: ${shot}`, ``, `Legend:`,
      ...Object.entries(legend).map(([k, v]) => `- ${k.toUpperCase()} = ${v}`), ``, `Marked elements:`,
      ...Object.entries(byColour).map(([k, set]) => `- ${k.toUpperCase()}: ${[...set].join(", ") || "(empty area)"}`),
      ...(noteLines.length ? ["", "Notes:", ...noteLines] : []),
      ``, `Apply the changes per the legend. Keep the layout unless a note says otherwise. No blur anywhere.`,
    ].join("\n");
    close();
    showPage("code");
    sendText(text);
  };
})();


// ---------------- Forge build dock: live progress, draft preview, STOP, FIX NOW ----------------
const dock = { active: false, sid: null, file: null, t0: 0, timer: 0 };
function askGroup(name) {
  return new Promise(async (resolve) => {
    const groups = await api.labGroups().catch(() => []);
    const NEW = "＋ new group…", NONE = "(no group — FORGED root)";
    ask("Where should the new GUI go?", [
      { name: "group", label: "Group (a family in GUI LAB)", type: "select", options: [...groups, NEW, NONE] },
      { name: "fresh", label: "New group name (if ＋ new group)", type: "text" },
    ], (v) => {
      if (v.group === NONE) return resolve("");
      if (v.group === NEW) return resolve((v.fresh || name || "NEW").trim());
      resolve(v.group);
    }, "Start build");
    const sel = $("fld0"); if (sel && !groups.length) sel.value = NEW;
    const prevCancel = $("mCancel").onclick;
    $("mCancel").onclick = () => { prevCancel?.(); resolve(null); };
  });
}
function feed(text, cls = "") {
  const f = $("dkFeed"); const d = h("div", { class: cls }, text); f.append(d);
  while (f.children.length > 60) f.firstChild.remove();
  f.scrollTop = f.scrollHeight;
}
function dockStart(title, file) {
  Object.assign(dock, { active: true, sid: cur?.sessionId, file, t0: Date.now() });
  const el = $("dock"); el.hidden = false; el.classList.remove("done", "fail", "min");
  $("dkTitle").textContent = title; $("dkStatus").textContent = "sending brief to the agent…";
  $("dkFeed").replaceChildren(); $("dkPrev").src = "about:blank"; $("dkNoPrev").hidden = false;
  feed("→ saving to " + file);
  clearInterval(dock.timer);
  dock.timer = setInterval(() => { const s = Math.floor((Date.now() - dock.t0) / 1000); $("dkTime").textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0"); }, 500);
}
async function dockEnd() {
  dock.active = false; clearInterval(dock.timer);
  const ok = !!dock.file && await fileExists(dock.file);
  $("dock").classList.add(ok ? "done" : "fail");
  $("dkStatus").textContent = ok ? "✓ built — saved to " + dock.file : "✗ no file written — type a FIX and send, or check CHAT";
  if (ok) loadDraft(); window.FORM?.pulse(2);
}
function loadDraft() { if (!dock.file) return; $("dkNoPrev").hidden = true; $("dkPrev").src = fileUrl(dock.file) + "?t=" + Date.now(); }
function dockEvent(u) {
  switch (u.sessionUpdate) {
    case "agent_thought_chunk": $("dkStatus").textContent = "thinking…"; break;
    case "agent_message_chunk": if ((u.content?.text || "").trim()) $("dkStatus").textContent = "replying…"; break;
    case "tool_call": { const t = u.title || u.name || "tool"; $("dkStatus").textContent = "⚙ " + t + "…"; feed("⚙ " + t, "tl"); break; }
    case "tool_call_update":
      if (u.status === "completed") {
        const i = u.rawInput || {}, p = i.path || i.file_path || i.filePath || i.command || "";
        feed("✓ " + String(p).split(/[\/]/).pop().slice(0, 60), "ok");
        if (dock.file && String(p).toLowerCase() === dock.file.toLowerCase()) { loadDraft(); $("dkStatus").textContent = "draft written — agent still working…"; }
      }
      break;
    case "plan": feed("☐ plan updated"); break;
  }
}
$("dkStop").onclick = () => { if (cur) { api.acpCancel(cur.engine, cur.sessionId); feed("■ stop requested", "tl"); } if (auto.on) { auto.on = false; autoChip(); } };
async function dockFix() {
  const t = $("dkFix").value.trim(); if (!t) return;
  $("dkFix").value = "";
  if (cur?.busy && cur.engine === "mcode") { await call("mcode/session/steer", { sessionId: cur.sessionId, text: t }, cur.engine).catch(() => {}); feed("➤ steered: " + t, "tl"); }
  else { feed("➤ fix sent: " + t, "tl"); dockStart($("dkTitle").textContent + " · fix", dock.file); await sendText((dock.file ? `In ${dock.file}: ` : "") + t); dockEnd(); }
}
$("dkSend").onclick = dockFix;
$("dkFix").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); dockFix(); } });
$("dkOpen").onclick = () => dock.file && openBrowser(dock.file);
$("dkChat").onclick = () => showPage("code");
$("dkMin").onclick = () => $("dock").classList.toggle("min");
$("dkClose").onclick = () => ($("dock").hidden = true);

// ---------------- MODEL BAY: model cards with real specs + unofficial measured score ----------------
(() => {
  let catalog = [], rows = [];
  const bench = () => S.bench || {};
  const idFromValue = (v) => {
    const s = String(v || "");
    if (s.startsWith("m:")) { const p = s.split(":"); return decodeURIComponent(p[2] || ""); }
    return s;
  };
  const fmtK = (n) => (!n ? "—" : n >= 1e6 ? (n / 1e6).toFixed(n % 1e6 ? 1 : 0) + "M" : Math.round(n / 1024) + "K");
  const ICON = { text: "✎ text", image: "◧ image", video: "▶ video", audio: "♪ audio", file: "⎘ file" };
  function score(m) {
    const b = bench()[m.cid];
    const ctx = m.context ? Math.max(0, Math.min(1, Math.log2(m.context / 8192) / Math.log2(1048576 / 8192))) : 0;
    if (!b || !b.runs) return { ctx, total: null };
    const speed = Math.min(1, (b.tps || 0) / 80);
    const lat = Math.max(0, Math.min(1, 1 - ((b.ms || 0) - 800) / 15000));
    const rel = b.ok / b.runs;
    return { ctx, speed, lat, rel, total: Math.round((ctx * 0.3 + speed * 0.3 + lat * 0.2 + rel * 0.2) * 100) };
  }
  function hueOf(id) { let x = 0; for (const c of String(id)) x = (x * 31 + c.charCodeAt(0)) % 360; return `hsl(${x} 95% 62%)`; }
  async function load() {
    try { catalog = await api.modelsCatalog(); } catch { catalog = []; }
    const opts = [...$("model").options].map((o) => ({ value: o.value, name: o.text }));
    // Tolerant catalog index. Each engine names the same gateway model differently than the
    // proxy /models catalog does: OpenCode reports "openai/gpt-x" while the catalog lists it
    // as "zen/openai/gpt-x"; mcode+proxy uses "kilo/..."; Hermes uses "hermes/...". Index every
    // catalog entry by its full id, its id minus the leading prefix segment, and its last path
    // segment, so a dropdown id from any engine still resolves to real specs instead of {}.
    const norm = (s) => String(s || "").toLowerCase();
    const byId = new Map(), byTail = new Map();
    for (const c of catalog) {
      const id = String(c.id);
      byId.set(norm(id), c);
      byId.set(norm(id.replace(/^[^/]+\//, "")), c);
      const tail = norm(id.split("/").pop());
      byTail.set(tail, byTail.has(tail) ? null : c); // null marks an ambiguous tail -> don't guess
    }
    const resolve = (cid) => {
      const n = norm(cid);
      if (byId.has(n)) return byId.get(n);
      const stripped = norm(String(cid).replace(/^(kilo|zen|hermes|opencode)\//, ""));
      if (byId.has(stripped)) return byId.get(stripped);
      return byTail.get(norm(String(cid).split("/").pop())) || {};
    };
    rows = (opts.length ? opts : catalog.filter((c) => c.free).map((c) => ({ value: null, name: c.name, id: c.id })))
      .map((o) => { const cid = o.id || idFromValue(o.value); const c = resolve(cid); return { ...c, cid, value: o.value, label: (c.name || o.name).replace(/ · thinking$/, ""), provider: vendorOf(cid) }; });
    icons = await api.modelsIcons([...new Set(rows.map((r) => vendorOf(r.cid)))]).catch(() => ({}));
  }
  function render() {
    const q = $("mdlSearch").value.toLowerCase(), mod = $("mdlMod").value, sort = $("mdlSort").value;
    const cur = $("model").value;
    let list = rows.filter((r) => (!q || (r.label + " " + r.cid + " " + r.description).toLowerCase().includes(q)) && (!mod || (r.input || []).includes(mod)));
    list.sort((a, b) => sort === "name" ? a.label.localeCompare(b.label) : sort === "context" ? (b.context || 0) - (a.context || 0)
      : sort === "speed" ? ((bench()[b.cid]?.tps || 0) - (bench()[a.cid]?.tps || 0)) : ((score(b).total ?? -1) - (score(a).total ?? -1)));
    $("mdlCount").textContent = `${list.length} models`;
    $("mdlGrid").replaceChildren(...list.map((m, i) => card(m, i, m.value && m.value === cur)));
  }
  const vendorOf = (cid) => { const p = String(cid).split("/"); return (p[0] === "kilo" || p[0] === "opencode") && p.length > 2 ? p[1] : p[0]; };
  let icons = {};
  const KEY = [["text","✎"],["image","◧"],["video","▶"],["audio","♪"],["file","⎘"],["tools","⚙"],["reasoning","◎"],["structured","{}"]];
  function symbolsOf(m) {
    const have = new Set([...(m.input || []), ...((m.params || []).includes("tools") ? ["tools"] : []), ...((m.params || []).includes("reasoning") ? ["reasoning"] : []), ...((m.params || []).includes("structured_outputs") ? ["structured"] : [])]);
    return KEY.filter(([k]) => have.has(k));
  }
  function logo(m, big) {
    const v = vendorOf(m.cid), src = icons[v];
    return src ? h("img", { class: "logo" + (big ? " big" : ""), src, alt: v }) : h("span", { class: "logo mono" + (big ? " big" : "") }, v.slice(0, 2).toUpperCase());
  }
  function ring(total) {
    const v = total == null ? 0 : total, C = 2 * Math.PI * 16;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 40 40"); svg.setAttribute("class", "ring");
    svg.innerHTML = `<circle cx="20" cy="20" r="16" class="rb"/><circle cx="20" cy="20" r="16" class="rf" stroke-dasharray="${(C * v) / 100} ${C}"/><text x="20" y="24">${total == null ? "—" : total}</text>`;
    return svg;
  }
  function card(m, i, isCur) {
    const b = bench()[m.cid], sc = score(m);
    const led = m._run ? "run" : b ? (b.lastOk ? "ok" : "bad") : "";
    return h("button", { class: "mc" + (isCur ? " cur" : ""), style: `--mh:${hueOf(m.cid)};animation-delay:${Math.min(i, 24) * 0.025}s`, title: "Click for full details", onclick: (e) => openDetail(m, e.currentTarget) },
      h("span", { class: "led " + led }),
      logo(m),
      h("span", { class: "mid" }, h("span", { class: "nm" }, m.label), h("span", { class: "syms" }, ...symbolsOf(m).map(([k, g]) => h("i", { title: k }, g)), m.free ? h("i", { class: "free", title: "free" }, "FREE") : null)),
      ring(sc.total),
      h("span", { class: "minisheet" }, ...[["CTX", sc.ctx], ["SPD", sc.speed], ["LAT", sc.lat], ["REL", sc.rel]].map(([k, v]) => h("span", { class: "mrow" }, h("em", {}, k), h("span", { class: "bar" }, h("i", { style: `width:${v == null ? 0 : Math.round(v * 100)}%` }))))));
  }
  function openDetail(m, from) {
    const b = bench()[m.cid], sc = score(m);
    const bar = (label, v, txt) => h("div", { class: "row" }, h("span", {}, label), h("div", { class: "bar" }, h("i", { style: `width:${v == null ? 0 : Math.round(v * 100)}%` })), h("span", {}, txt));
    const isCur = m.value && m.value === $("model").value;
    const panel = h("div", { class: "md-card", style: `--mh:${hueOf(m.cid)}` },
      h("div", { class: "md-top" }, logo(m, true), h("div", {}, h("div", { class: "md-nm" }, m.label), h("div", { class: "md-id" }, m.cid)), h("div", { class: "grow" }), ring(sc.total)),
      h("div", { class: "md-desc" }, m.description || "No description from the provider."),
      h("div", { class: "md-stats" },
        ...[["CONTEXT", fmtK(m.context)], ["MAX OUTPUT", fmtK(m.maxOut)], ["RELEASED", m.created ? new Date(m.created * 1000).toISOString().slice(0, 10) : "—"], ["VENDOR", vendorOf(m.cid)]]
          .map(([k, v]) => h("div", { class: "st" }, h("span", {}, k), h("b", {}, v)))),
      h("div", { class: "md-sec" }, "ACCEPTS"), h("div", { class: "chips" }, ...(m.input || []).map((x) => h("span", { class: "chip in" }, (KEY.find(([k]) => k === x)?.[1] || "•") + " " + x)), !(m.input || []).length ? h("span", { class: "chip warn" }, "no gateway specs") : null),
      h("div", { class: "md-sec" }, "PRODUCES"), h("div", { class: "chips" }, ...(m.output || []).map((x) => h("span", { class: "chip" }, (KEY.find(([k]) => k === x)?.[1] || "•") + " " + x))),
      h("div", { class: "md-sec" }, "CAPABILITIES"), h("div", { class: "chips" }, ...(m.params || []).map((x) => h("span", { class: "chip" }, x.replace(/_/g, " "))), m.free ? h("span", { class: "chip" }, "FREE") : null, m.trains ? h("span", { class: "chip warn" }, "⚠ may train on your prompts") : null),
      h("div", { class: "md-sec" }, "UNOFFICIAL SCORE SHEET — measured by your bench runs"),
      h("div", { class: "sheet" },
        bar("CONTEXT", sc.ctx, fmtK(m.context)), bar("SPEED", sc.speed, b ? Math.round(b.tps) + " t/s" : "—"),
        bar("LATENCY", sc.lat, b ? (b.ms / 1000).toFixed(1) + " s" : "—"), bar("RELIABLE", sc.rel, b ? `${b.ok}/${b.runs}` : "—"),
        h("div", { class: "md-when" }, b ? "last bench " + new Date(b.at).toLocaleString() : "not benched yet")),
      h("div", { class: "acts" },
        h("button", { onclick: async (e) => { e.stopPropagation(); await runBench(m); closeDetail(); openDetail(m); } }, "⚡ BENCH"),
        m.value ? h("button", { class: "sel", onclick: async () => { await setModel(m.value); closeDetail(); $("mdl").hidden = true; toast("Model: " + m.label); } }, isCur ? "✓ CURRENT" : "SELECT") : h("button", { disabled: true }, "not in engine"),
        h("button", { onclick: closeDetail }, "CLOSE")));
    const ov = h("div", { id: "mdDetail", onclick: (e) => { if (e.target.id === "mdDetail") closeDetail(); } }, panel);
    if (from) { const r = from.getBoundingClientRect(); panel.style.setProperty("--fx", r.left + r.width / 2 - innerWidth / 2 + "px"); panel.style.setProperty("--fy", r.top + r.height / 2 - innerHeight / 2 + "px"); }
    ov.addEventListener("pointermove", (e) => { const r = panel.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5; panel.style.transform = `perspective(1100px) rotateY(${x * 10}deg) rotateX(${-y * 8}deg)`; });
    ov.addEventListener("pointerleave", () => (panel.style.transform = ""));
    document.body.append(ov);
  }
  function closeDetail() { $("mdDetail")?.remove(); }
  async function runBench(m) {
    if (!/^kilo\//.test(m.cid) && !catalog.some((c) => c.id === m.cid)) return toast("Bench works for gateway models only.");
    m._run = true; render();
    const r = await api.modelsBench(m.cid);
    const prev = bench()[m.cid] || { runs: 0, ok: 0 };
    const nb = { runs: prev.runs + 1, ok: prev.ok + (r.ok ? 1 : 0), lastOk: r.ok, at: Date.now(),
      ms: r.ok ? Math.round(prev.ms ? prev.ms * 0.5 + r.ms * 0.5 : r.ms) : prev.ms, tps: r.ok ? (prev.tps ? prev.tps * 0.5 + r.tps * 0.5 : r.tps) : prev.tps };
    await saveSettings({ bench: { ...bench(), [m.cid]: nb } });
    m._run = false; render();
  }
  $("mdlBtn").onclick = async () => {
    await ensureSession().catch(() => {});
    $("mdl").hidden = false; $("mdlGrid").replaceChildren(h("div", { class: "note" }, "loading model specs…"));
    await load(); render();
  };
  $("pbBtn").onclick = () => window.openPluginBay?.("plugins");
  $("mdlClose").onclick = () => { $("mdl").hidden = true; window.__bayOpen = false; window.BayLattice?.stop(); };
  $("mdlSearch").oninput = render; $("mdlMod").onchange = render; $("mdlSort").onchange = render;
  $("mdlBenchAll").onclick = async () => {
    const list = rows.filter((r) => r.context);
    $("mdlBenchAll").disabled = true;
    for (const m of list) { if ($("mdl").hidden) break; await runBench(m); }
    $("mdlBenchAll").disabled = false;
  };
  addEventListener("keydown", (e) => { if (e.key !== "Escape") return; if ($("mdDetail")) closeDetail(); else if (!$("mdl").hidden) { $("mdl").hidden = true; window.__bayOpen = false; window.BayLattice?.stop(); } });
})();

// ---------------- SETTINGS: central config, live-applied ----------------
const CFG_DEF = {
  userHue: "", userOpacity: 0.8, panelOpacity: 0.84,
  reactorOn: true, reactorIntensity: 1,
  boidsOn: true, boidsCount: 90, boidsSpeed: 1,
  boidColors: ["", "", ""], hunterColor: "",
  fontSize: 13, notify: true,
  accent: "", accent2: "", font: "Segoe UI", bubbleShape: "rounded",
};
function cfg() { return { ...CFG_DEF, ...(S.cfg || {}) }; }
function applyCfg() {
  const c = cfg(), r = document.documentElement.style;
  r.setProperty("--user-op", c.userOpacity);
  r.setProperty("--panel-op", c.panelOpacity);
  if (c.userHue) r.setProperty("--user-hue", c.userHue); else r.removeProperty("--user-hue");
  document.body.style.fontSize = c.fontSize + "px";
  document.body.style.fontFamily = `"${c.font}", system-ui, sans-serif`;
  r.setProperty("--bubble-r", ({ rounded: "14px", square: "3px", pill: "22px" })[c.bubbleShape] || "14px");
  if (c.accent) { r.setProperty("--theme-accent", c.accent); } else { r.removeProperty("--theme-accent"); }
  if (c.accent2) { r.setProperty("--theme-accent2", c.accent2); } else { r.removeProperty("--theme-accent2"); }
  window.CFG = c;
  window.FORM?.config?.(c);
  window.dispatchEvent(new CustomEvent("cfg", { detail: c }));
}
async function setCfg(patch) { await saveSettings({ cfg: { ...cfg(), ...patch } }); applyCfg(); window._setFluid?.pulse?.(0.6); window._setPrev && window._setPrev(); }
function openSettings() {
  const c = cfg();
  let nav;
  const engines = { mcode: "MiniMax Code", opencode: "OpenCode", kilo: "Kilo Code", codex: "Codex · ChatGPT subscription", claude: "Claude · subscription", hermes: "Hermes Agent", native: "Direct endpoints (ASK)" };
  const range = (label, key, min, max, step, idx) => {
    const val = idx == null ? c[key] : c[key][idx]; const out = h("b", {}, val);
    return h("label", { class: "se-row" }, h("span", {}, label),
      h("input", { type: "range", min, max, step, value: val, oninput: (e) => { out.textContent = e.target.value; idx == null ? setCfg({ [key]: +e.target.value }) : setCfg({ [key]: Object.assign([...c[key]], { [idx]: +e.target.value }) }); } }), out);
  };
  const color = (label, key, idx) => {
    const val = (idx == null ? c[key] : c[key][idx]) || defaultTabColor();
    return h("label", { class: "se-row" }, h("span", {}, label),
      h("input", { type: "color", value: val, oninput: (e) => idx == null ? setCfg({ [key]: e.target.value }) : setCfg({ [key]: Object.assign([...c[key]], { [idx]: e.target.value }) }) }),
      h("button", { class: "se-clr", onclick: () => { idx == null ? setCfg({ [key]: "" }) : setCfg({ [key]: Object.assign([...c[key]], { [idx]: "" }) }); nav(active); } }, "auto"));
  };
  const chk = (label, key) => h("label", { class: "se-row chk" }, h("input", { type: "checkbox", ...(c[key] ? { checked: true } : {}), onchange: (e) => setCfg({ [key]: e.target.checked }) }), h("span", {}, label));
  const pick = (label, key, opts) => h("label", { class: "se-row" }, h("span", {}, label), h("select", { onchange: (e) => setCfg({ [key]: e.target.value }) }, opts.map((o) => h("option", { value: o, ...(c[key] === o ? { selected: true } : {}) }, o))));
  const THEMES = [["Cyan/Pink", "#2ad4ff", "#ff3fb4"], ["Blood", "#ff2b4f", "#ff8a3d"], ["Toxic", "#b6ff3b", "#2affc4"], ["Gold", "#ffc83a", "#ff6a3d"], ["Violet", "#a78bff", "#ff5fd2"], ["Ice", "#7ab8ff", "#e8f6ff"], ["Mono", "#c8d6e6", "#8aa3bd"]];
  const themeRow = h("div", { class: "se-themes" }, ...THEMES.map(([nm, a2, b2]) =>
    h("button", { class: "sw" + (c.accent === a2 ? " on" : ""), style: `--a:${a2};--b:${b2}`, title: nm, onclick: () => { setCfg({ accent: a2, accent2: b2 }); nav("themes"); } }, h("i"), nm)),
    h("button", { class: "sw" + (!c.accent ? " on" : ""), onclick: () => { setCfg({ accent: "", accent2: "" }); nav("themes"); } }, h("i", { style: "--a:#2ad4ff;--b:#ff3fb4" }), "Per-tab"));
  const SECTIONS = {
    themes: ["◈ THEME", h("p", { class: "se-p" }, "Set one accent for the whole app (kills the per-tab colours), or keep per-tab."), themeRow,
      color("Custom accent", "accent"), color("Custom accent 2", "accent2")],
    chat: ["✎ CHAT", pick("Bubble shape", "bubbleShape", ["rounded", "square", "pill"]), range("Your bubble opacity", "userOpacity", 0.2, 1, 0.05),
      h("p", { class: "se-p" }, "Your messages are blue with a neon glow; the agent's are red. Shape and opacity apply to both.")],
    type: ["A TYPOGRAPHY", pick("Font", "font", ["Segoe UI", "Consolas", "Cascadia Mono", "JetBrains Mono", "Georgia", "Courier New", "Arial", "Trebuchet MS"]),
      range("Font size", "fontSize", 11, 18, 1)],
    surfaces: ["▦ SURFACES", range("Panel opacity", "panelOpacity", 0.4, 1, 0.02)],
    reactor: ["⬡ CENTREPIECE", chk("Show reactor", "reactorOn"), range("Reactor intensity", "reactorIntensity", 0.2, 2, 0.05)],
    boids: ["⟠ BOIDS", chk("Show boids scene", "boidsOn"), range("Flock size", "boidsCount", 20, 160, 5), range("Speed", "boidsSpeed", 0.3, 2.5, 0.1),
      color("School 1", "boidColors", 0), color("School 2", "boidColors", 1), color("School 3", "boidColors", 2), color("Hunter", "hunterColor")],
    engines: ["⚙ ENGINES", h("p", { class: "se-p" }, "Coder engines this IDE drives. Skills, source libraries, and update-following per engine are coming."),
      ...Object.entries(engines).map(([k, nm]) => h("div", { class: "se-eng" }, h("b", {}, nm), h("span", { class: "se-tag" }, k === "mcode" ? "primary" : "installed"),
        h("span", { class: "se-soon" }, "skills · libraries · updater — planned"))),
      h("div", { class: "se-eng" }, h("b", {}, "Local models (llama.cpp / Lemonade)"), h("span", { class: "se-tag" }, "installed"), h("span", { class: "se-soon" }, "◈ MODELS → ⬢ LOCAL: scan, download, load, register")),
    ],
    behaviour: ["✦ BEHAVIOUR", chk("Desktop notifications", "notify"),
      h("label", { class: "se-row" }, h("span", {}, "MiniMax Code folder"), h("input", { value: S.mcodeDir, onchange: (e) => saveSettings({ mcodeDir: e.target.value.trim() }) })),
      h("div", { class: "se-row" }, h("button", { onclick: async () => { await saveSettings({ cfg: {} }); applyCfg(); nav(active); } }, "↺ Reset all settings"))],
  };
  const extra = window.ForgeIntegrations?.settingsSections() || {};
  Object.assign(SECTIONS, extra);
  const ORDER = [...Object.entries(extra).map(([id, rows]) => [id, rows[0]]), ["themes", "Theme"], ["chat", "Chat"], ["type", "Type"], ["surfaces", "Surfaces"], ["reactor", "Centrepiece"], ["boids", "Boids"], ["engines", "Engines"], ["behaviour", "Behaviour"]];
  let active = window._setTab || "connections";
  const pane = h("div", { class: "se-pane" });
  nav = function (id) {
    active = id; window._setTab = id;
    document.querySelectorAll(".se-nav button").forEach((x) => x.classList.toggle("on", x.dataset.s === id));
    const [title, ...rows] = SECTIONS[id];
    pane.replaceChildren(h("div", { class: "se-title" }, title), ...rows);
  }
  const preview = h("div", { class: "se-prev" });
  function renderPreview() {
    const cc = cfg();
    preview.replaceChildren(
      h("div", { class: "se-prev-h" }, "LIVE PREVIEW"),
      h("div", { class: "se-chat" },
        h("div", { class: "pm user" }, "my message — blue neon"),
        h("div", { class: "pm agent" }, "agent reply — red glow")),
      h("div", { class: "se-swatches" }, h("span", { style: "background:var(--tab)" }), h("span", { style: "background:var(--tab2)" }),
        ...(cc.boidColors || []).map((x) => h("span", { style: `background:${x || "var(--tab)"}` })), h("span", { style: `background:${cc.hunterColor || "#fff"}` })),
      h("div", { class: "se-prev-note" }, "changes apply instantly across the whole app"));
    preview.querySelectorAll(".pm").forEach((el) => el.style.borderRadius = ({ rounded: "14px", square: "3px", pill: "22px" })[cfg().bubbleShape] || "14px");
  }
  const _nav = nav; nav = (id) => { _nav(id); renderPreview(); }; window._setPrev = renderPreview;
  const page = h("div", { id: "settings" },
    h("canvas", { id: "fluidSet" }),
    h("div", { class: "se-side" }, h("div", { class: "se-brand" }, "⚙ SETTINGS"),
      h('input', { class: 'settings-search', placeholder: 'Search every setting…', oninput: (e) => {
        const q = e.target.value.toLowerCase().trim(); if (!q) return nav(active);
        const hits = Object.entries(SECTIONS).filter(([, contents]) => contents.map((x) => typeof x === 'string' ? x : x.textContent).join(' ').toLowerCase().includes(q));
        pane.replaceChildren(h('div', { class: 'se-title' }, 'SEARCH RESULTS'), ...hits.map(([id, contents]) => h('div', {}, h('button', { onclick: () => { e.target.value = ''; nav(id); } }, contents[0]), ...contents.slice(1).filter((x) => x.textContent.toLowerCase().includes(q)))));
      } }),
      h("div", { class: "se-nav" }, ...ORDER.map(([id, nm]) => h("button", { "data-s": id, onclick: () => nav(id) }, nm))),
      h("div", { class: "grow" }), h("button", { class: "se-done", onclick: () => { page.remove(); window._setFluid = null; } }, "✕ CLOSE")),
    h("div", { class: "se-main" }, pane),
    h("div", { class: "se-rail" }, preview));
  $("settings")?.remove(); document.body.append(page);
  try { window._setFluid = window.mountSetBg?.(document.getElementById("fluidSet")); } catch {}
  nav(active);
}
function defaultTabColor() { return getComputedStyle(document.documentElement).getPropertyValue("--tab").trim() || "#2ad4ff"; }
$("setBtn")?.addEventListener("click", openSettings);
addEventListener("keydown", (e) => { if (e.ctrlKey && e.key === ",") { e.preventDefault(); openSettings(); } });

// stream toggle (claw switch in the composer bar): checked = stream replies live
(() => {
  const t = $("streamToggle"); if (!t) return;
  t.checked = S.cfg?.streamReplies !== false;
  addEventListener("cfg", () => { t.checked = S.cfg?.streamReplies !== false; });
  t.onchange = () => saveSettings({ cfg: { ...(S.cfg || {}), streamReplies: t.checked } }).then(() => toast(t.checked ? "Streaming ON: replies appear as they're written" : "Streaming OFF: replies appear all at once"));
})();
