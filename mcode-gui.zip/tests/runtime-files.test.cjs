const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
const files = require('../file-pipeline.cjs'), { create } = require('../runtime-core.cjs');
function temp(t) { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-runtime-')); t.after(() => fs.rmSync(dir, { recursive: true, force: true })); return dir; }
function host(dir) { const handlers = {}, quit = []; return { handlers, app: { getPath: () => dir, on: (event, f) => quit.push(f) }, ipcMain: { handle: (name, f) => handlers[name] = f }, quit: () => quit.forEach(f => f()) }; }
test('irregular binary chunks reassemble byte-for-byte, preserve order and refuse corruption or overwrite', async t => {
  const dir = temp(t), original = crypto.randomBytes(300013), source = path.join(dir, 'all-types.weird'), output = path.join(dir, 'output.weird'); fs.writeFileSync(source, original);
  const result = await files.split(source, path.join(dir, 'chunks'), { chunkBytes: 65537 }); assert.equal(result.parts.length, 5);
  await files.merge(result.manifestPath, output); assert.deepEqual(fs.readFileSync(output), original); assert.equal(result.sha256, crypto.createHash('sha256').update(original).digest('hex'));
  await assert.rejects(files.merge(result.manifestPath, output), /already exists/);
  fs.appendFileSync(path.join(path.dirname(result.manifestPath), result.parts[0].name), 'corrupt'); const bad = path.join(dir, 'bad.bin'); await assert.rejects(files.merge(result.manifestPath, bad), /Corrupt/); assert.equal(fs.existsSync(bad), false); assert.equal(fs.readdirSync(dir).some(x => x.includes('.partial')), false);
});
test('chunk manifests reject traversal and broken offsets; empty files round-trip', async t => {
  const dir = temp(t), source = path.join(dir, 'empty.bin'); fs.writeFileSync(source, ''); const m = await files.split(source, path.join(dir, 'chunks')); await files.merge(m.manifestPath, path.join(dir, 'empty-output')); assert.equal(fs.statSync(path.join(dir, 'empty-output')).size, 0);
  const bad = { ...m, size: 1, parts: [{ name: '../escape', offset: 0, size: 1, sha256: '0'.repeat(64) }] }; fs.writeFileSync(m.manifestPath, JSON.stringify(bad)); assert.throws(() => files.readManifest(m.manifestPath), /sequence/);
});
test('streamed upload enforces offsets and completion, preserves binary data, autochunks and removes aborted partials', async t => {
  const dir = temp(t), h = host(dir), events = []; files({ app: h.app, ipcMain: h.ipcMain, dialog: {}, getWin: () => null, getSettings: () => ({ files: { thresholdMB: 1, chunkMB: 1 } }), send: (...args) => events.push(args) }); t.after(h.quit);
  const call = (name, ...args) => h.handlers[name](null, ...args), bytes = crypto.randomBytes(2 * 1048576 + 13), id = await call('upload:begin', 'large.anything', bytes.length);
  await assert.rejects(call('upload:append', id, 1, bytes.subarray(0, 13)), /offset/); await assert.rejects(call('upload:finish', id), /incomplete/);
  for (let offset = 0; offset < bytes.length; offset += 1048576) await call('upload:append', id, offset, bytes.subarray(offset, offset + 1048576));
  const file = await call('upload:finish', id); assert.deepEqual(fs.readFileSync(file), bytes); const prepared = await call('file:prepare', file); assert.equal(prepared.parts.length, 3); const reused=await call('file:prepare',file); assert.equal(reused.manifestPath,prepared.manifestPath); fs.appendFileSync(file,'changed'); const refreshed=await call('file:prepare',file); assert.notEqual(refreshed.manifestPath,prepared.manifestPath); assert.ok(events.some(([, e]) => e.state === 'complete'));
  const other = await call('upload:begin', 'abort.bin', 10); await call('upload:abort', other); assert.equal(fs.readdirSync(path.join(dir, 'uploads')).some(x => x.endsWith('.partial')), false);
});
test('actual runtime files and child processes work; large reads stay bounded and writes keep backups', async t => {
  const dir = temp(t), events = [], core = create({ userData: dir, getSettings: () => ({ cwd: dir }), onEvent: e => events.push(e) }); t.after(core.stop); const file = path.join(dir, 'code.js');
  await core.execute('file.write', { path: file, content: 'module.exports = 41;' }); const changed = await core.execute('file.write', { path: file, content: 'module.exports = 42;' }); assert.match(fs.readFileSync(changed.backup, 'utf8'), /41/);
  const result = await core.execute('process.run', { command: process.execPath, args: ['-e', "console.log(require('./code.js'))"], cwd: dir }); assert.equal(result.exitCode, 0); assert.equal(result.output.trim(), '42'); assert.equal(fs.readFileSync(result.logPath, 'utf8').trim(), '42');
  const range = await core.execute('file.read', { path: file, offset: 7, length: 6, encoding: 'base64' }); assert.deepEqual(Buffer.from(range.text, 'base64'), fs.readFileSync(file).subarray(7, 13)); await assert.rejects(core.execute('file.read', { path: file, length: 5 * 1048576 }), /at most/); assert.ok(events.some(e => e.kind === 'tool-failed'));
  const inv = await core.execute('system.inventory'); assert.equal(inv.platform, process.platform); assert.ok(inv.cpus > 0); assert.ok(inv.ramGB > 0);
});
test('runtime cancellation stops an owned process instead of reporting success', async t => {
  const dir = temp(t); let resolveStart; const start = new Promise(r => resolveStart = r), core = create({ userData: dir, getSettings: () => ({ cwd: dir }), onEvent: e => { if (e.kind === 'process-start') resolveStart(e.jobId); } }); t.after(core.stop);
  const pending = core.execute('process.run', { command: process.execPath, args: ['-e', 'setInterval(()=>{},1000)'] }); const jobId = await start; await core.execute('process.cancel', { jobId }); const result = await pending; assert.notEqual(result.exitCode, 0);
});
