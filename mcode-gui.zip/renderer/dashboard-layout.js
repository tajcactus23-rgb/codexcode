(() => {
  const { E, by, button } = ForgeDashboard;
  const columns = [...document.querySelectorAll('#page-mission .mc-grid > .mc-column')];
  const widgets = [...document.querySelectorAll('#page-mission .mc-panel')];
  const defaults = columns.map(c => [...c.children].filter(e => e.classList.contains('mc-panel')).map(e => e.id));
  const palettes = [
    { name: 'PRISM', colors: ['#4eefff', '#ff59c7', '#b9ff65', '#ffc466', '#83a6ff'] },
    { name: 'ION', colors: ['#9affda', '#a78aff', '#fff189', '#ff957e', '#8dcaff'] },
    { name: 'SOLAR', colors: ['#89deff', '#ff9653', '#c1efff', '#ffe288', '#c394ff'] }
  ];
  let editing = false, selectedPalette = 0, queue = Promise.resolve();
  const settings = () => ({ columns: columns.map(c => [...c.children].filter(e => e.classList.contains('mc-panel')).map(e => e.id)), hidden: widgets.filter(w => w.hidden).map(w => w.id), palette: selectedPalette });
  const persist = () => { queue = queue.then(() => saveSettings({ commandCentre: settings() })).catch(e => toast(e.message)); return queue; };
  const drawer = E('div', { id: 'mc-customise', class: 'mc-customise', hidden: true });
  by('page-mission').append(drawer);
  by('page-mission').querySelector('.mc-title-actions').prepend(button('⛭ WIDGETS', () => { editing = !editing; drawer.hidden = !editing; by('page-mission').classList.toggle('widgets-editing', editing); renderDrawer(); }));
  function palette(i) { selectedPalette = Math.max(0, Math.min(palettes.length - 1, Math.trunc(Number(i) || 0))); document.querySelectorAll('.mc-page').forEach(p => ['--cyan', '--pink', '--lime', '--amber', '--blue'].forEach((key, j) => p.style.setProperty(key, palettes[selectedPalette].colors[j]))); window.ForgeMotion?.setPalette(selectedPalette); }
  function renderDrawer() {
    drawer.replaceChildren(E('div', { class: 'mc-customise-title' }, E('strong', {}, 'YOUR CONTROL CENTRE'), button('✕', () => { editing = false; drawer.hidden = true; by('page-mission').classList.remove('widgets-editing'); })), E('p', {}, 'Drag a widget header to another column. Arrow controls move it within a column.'), E('div', { class: 'mc-palette-options' }, ...palettes.map((p, i) => button(p.name, () => { palette(i); persist(); }))), E('div', { class: 'mc-widget-options' }, ...widgets.map(w => E('label', {}, E('input', { type: 'checkbox', checked: !w.hidden, onchange: e => { w.hidden = !e.target.checked; persist(); } }), E('span', {}, w.querySelector('header>span:nth-child(2)').textContent)))), button('RESET LAYOUT', async () => { defaults.forEach((ids, i) => ids.forEach(id => columns[i].append(by(id)))); widgets.forEach(w => { w.hidden = false; }); palette(0); await persist(); renderDrawer(); }));
  }
  function move(widget, direction) {
    const peers = [...widget.parentElement.children].filter(e => e.classList.contains('mc-panel')), index = peers.indexOf(widget), neighbor = peers[index + direction];
    if (!neighbor) return;
    if (direction < 0) widget.parentElement.insertBefore(widget, neighbor); else widget.parentElement.insertBefore(widget, neighbor.nextSibling);
    persist();
  }
  widgets.forEach(w => {
    const header = w.querySelector('header'); header.draggable = true;
    header.append(E('div', { class: 'mc-widget-controls' }, button('↑', () => move(w, -1)), button('↓', () => move(w, 1))));
    header.addEventListener('dragstart', e => { if (!editing) { e.preventDefault(); return; } e.dataTransfer.setData('application/forge-widget', w.id); e.dataTransfer.effectAllowed = 'move'; });
  });
  columns.forEach(c => {
    c.addEventListener('dragover', e => { if (editing && e.dataTransfer.types.includes('application/forge-widget')) { e.preventDefault(); c.classList.add('mc-drop-target'); } });
    c.addEventListener('dragleave', () => c.classList.remove('mc-drop-target'));
    c.addEventListener('drop', e => { c.classList.remove('mc-drop-target'); if (!editing) return; const w = by(e.dataTransfer.getData('application/forge-widget')); if (!widgets.includes(w)) return; e.preventDefault(); const target = e.target.closest('.mc-panel'); if (target && target.parentElement === c && target !== w) c.insertBefore(w, target); else c.append(w); persist(); });
  });
  function restore() { const s = S.commandCentre || {}; const placed = new Set(); (s.columns || []).slice(0, 3).forEach((ids, i) => { if (Array.isArray(ids)) ids.forEach(id => { const w = by(id); if (widgets.includes(w) && !placed.has(id)) { columns[i].append(w); placed.add(id); } }); }); widgets.forEach(w => { w.hidden = (s.hidden || []).includes(w.id); }); palette(s.palette || 0); }
  addEventListener('forge-ready', restore); addEventListener('forge-motion-ready', () => palette(selectedPalette));
  window.ForgeLayout = { restore, persist, settings };
})();
