(() => {
  const { E, by, button, top, rail } = ForgeDashboard;
  const state = { items: [], selected: null, query: '', filter: 'all', error: '', loading: false, playing: false, covers: new Map(), generation: 0 };
  const stage = E('div', { class: 'sc-stage', id: 'sc-stage' });
  const grid = E('div', { class: 'sc-project-grid', id: 'sc-project-grid' });
  by('page-showcase').append(E('canvas', { id: 'sc-flock', 'aria-hidden': 'true' }), top('PROJECT SHOWCASE'), E('div', { class: 'mc-shell sc-shell' }, rail(), E('main', { class: 'sc-main' },
    E('div', { class: 'sc-heading' }, E('div', {}, E('p', { class: 'mc-eyebrow' }, 'BUILT IN FORGE / YOUR PROJECT GALLERY'), E('h1', {}, 'Project ', E('em', {}, 'showcase'), E('span', { class: 'mc-title-dot' }))), E('div', { class: 'sc-heading-actions' }, button('＋ ADD WORKSPACE', async () => { const p = await api.projectImport('folder'); if (p) { state.selected = p.id; await refresh(); } }, 'primary'), button('＋ ADD HTML BUILD', async () => { const p = await api.projectImport('file'); if (p) { state.selected = p.id; await refresh(); } }), button('↻ REFRESH', refresh))),
    E('div', { class: 'sc-library-bar' }, E('div', { class: 'sc-filter-tabs' }, ...[['all', 'ALL PROJECTS'], ['in-progress', 'IN PROGRESS'], ['ready', 'READY'], ['pinned', 'PINNED']].map(([filter, text]) => E('button', { 'data-filter': filter, onclick: () => { state.filter = filter; renderCards(); } }, text))), E('div', { class: 'sc-search' }, E('span', {}, '⌕'), E('input', { id: 'sc-search', placeholder: 'Find a project, tag or workspace…', 'aria-label': 'Search your projects', oninput: e => { state.query = e.target.value.toLowerCase(); renderCards(); } })), E('b', { id: 'sc-count' }, '0 PROJECTS')),
    E('div', { id: 'sc-status', role: 'status', class: 'sc-status' }), stage, E('div', { class: 'sc-section-heading' }, E('span', {}, 'THE COLLECTION'), E('small', {}, 'SELECT A PROJECT TO PREVIEW / OPEN / CONTINUE BUILDING')), grid,
    E('footer', { class: 'mc-footer' }, E('span', {}, 'FORGE / PROJECT GALLERY'), E('span', {}, 'WORKSPACES + FORGED BUILDS'), E('span', {}, 'YOUR WORK ON DISPLAY')))));
  function current() { return state.items.find(p => p.id === state.selected); }
  function status(p) { return p.missing ? 'PATH UNAVAILABLE' : (p.status || 'in-progress').replace('-', ' ').toUpperCase(); }
  function art(p, klass = '') {
    const color = parseInt(p.id?.slice(0, 4) || '00ff', 16) % 360;
    const cover = state.covers.get(p.id);
    return E('div', { class: 'sc-project-art ' + klass, style: '--project-hue:' + color }, cover ? E('img', { src: cover, alt: p.name + ' project screenshot' }) : E('div', { class: 'sc-cover-placeholder' }, E('div', { class: 'sc-cover-orbit' }), E('div', { class: 'sc-cover-orbit orbit-b' }), E('div', { class: 'sc-cover-grid' }), E('b', {}, p.name.slice(0, 2).toUpperCase()), E('small', {}, 'PROJECT COVER / ADD YOUR SCREENSHOT')), E('div', { class: 'sc-cover-gloss' }));
  }
  function stopPreview() { state.playing = false; stage.classList.remove('sc-playing'); const host = by('sc-preview-host'); if (host) host.replaceChildren(); }
  function renderStage() {
    stopPreview(); const p = current(); stage.replaceChildren();
    if (!p) { stage.append(E('div', { class: 'sc-empty' }, E('div', { class: 'sc-empty-icon' }, '◇'), E('h2', {}, 'Your projects belong here.'), E('p', {}, 'Add a workspace or a built HTML project. Recent workspaces and your FORGED builds appear automatically.'), button('＋ ADD YOUR FIRST PROJECT', async () => { const p = await api.projectImport('folder'); if (p) { state.selected = p.id; await refresh(); } }, 'primary'))); return; }
    const visual = art(p, 'sc-featured-art');
    const host = E('div', { id: 'sc-preview-host', class: 'sc-preview-host' }); visual.append(host, E('div', { class: 'sc-preview-chrome' }, E('span', { class: 'sc-chrome-dots' }, E('i'), E('i'), E('i')), E('span', { id: 'sc-preview-address' }, p.previewUrl || 'Add a running app URL or HTML entry'), E('span', { id: 'sc-preview-badge' }, 'PROJECT PREVIEW')), E('div', { class: 'sc-preview-overlay' }, button('▶ PLAY LIVE PROJECT', play, 'primary'), button('⤢ OPEN APP WINDOW', () => api.projectOpen(p.id))));
    stage.append(E('div', { class: 'sc-featured' }, visual, E('div', { class: 'sc-project-details' }, E('div', { class: 'sc-project-kicker' }, E('span', {}, 'SELECTED PROJECT'), E('span', { class: 'sc-status-pill ' + p.status }, status(p))), E('h2', {}, p.name), E('p', {}, p.summary || 'Add a description to introduce this project.'), E('div', { class: 'mc-tags' }, ...(p.tags || []).map(t => E('span', {}, t))), E('div', { class: 'sc-project-location' }, E('span', {}, 'WORKSPACE'), E('code', {}, p.path)), E('div', { class: 'sc-detail-actions' }, button('⌨ CONTINUE IN IDE', async () => { if (p.missing) throw Error('This workspace is unavailable.'); await setProject(p.directory || p.path); showPage('code'); }, 'primary'), button(p.pinned ? '★ PINNED' : '☆ PIN PROJECT', async () => { await api.projectUpdate(p.id, { pinned: !p.pinned }); await refresh(); })), E('div', { class: 'sc-secondary-actions' }, button('EDIT DETAILS', () => edit(p)), button('CHOOSE COVER', async () => { if (await api.projectPickCover(p.id)) { state.covers.delete(p.id); await refresh(); } }), button('CAPTURE PREVIEW', async () => { await api.projectCapture(p.id); state.covers.delete(p.id); await refresh(); }), button('REVEAL FILES', () => api.openPath(p.directory || p.path))), E('div', { class: 'sc-feature-controls' }, button('← PREVIOUS', () => step(-1)), E('span', {}, String(state.items.findIndex(i => i.id === p.id) + 1).padStart(2, '0') + ' / ' + String(state.items.length).padStart(2, '0')), button('NEXT →', () => step(1))))));
  }
  function step(direction) { if (!state.items.length) return; const i = state.items.findIndex(p => p.id === state.selected); state.selected = state.items[(i + direction + state.items.length) % state.items.length].id; renderStage(); renderCards(); }
  async function play() {
    const p = current(); if (!p?.previewUrl || p.missing) throw Error('Build an HTML entry or set your running app URL in Edit details.');
    const host = by('sc-preview-host'); host.replaceChildren();
    const electron = /Electron\//.test(navigator.userAgent);
    const view = electron ? E('webview', { src: p.previewUrl, partition: 'persist:forge-project-preview', allowpopups: false }) : E('iframe', { src: p.previewUrl, title: p.name + ' live project', sandbox: 'allow-scripts', loading: 'eager' });
    state.playing = true; stage.classList.add('sc-playing'); by('sc-preview-badge').textContent = 'LOADING PROJECT';
    const ready = () => { if (state.playing) by('sc-preview-badge').textContent = 'LIVE PROJECT'; };
    view.addEventListener(electron ? 'dom-ready' : 'load', ready);
    view.addEventListener('did-fail-load', e => { by('sc-preview-badge').textContent = 'PREVIEW FAILED'; by('sc-status').textContent = e.errorDescription || 'Project preview failed to load.'; });
    host.append(view, button('■ STOP PREVIEW', () => { stage.classList.remove('sc-playing'); stopPreview(); by('sc-preview-badge').textContent = 'PROJECT PREVIEW'; }));
  }
  function edit(p) {
    const fields = [{ name: 'name', label: 'Project name', type: 'text', value: p.name }, { name: 'summary', label: 'Description', type: 'text', area: true, value: p.summary }, { name: 'tags', label: 'Tags (comma separated)', type: 'text', value: (p.tags || []).join(', ') }, { name: 'status', label: 'Status', type: 'select', options: ['in-progress', 'ready', 'archived'], value: p.status }, { name: 'previewUrl', label: 'Running app URL (or local file URL)', type: 'text', value: p.previewUrl || '' }];
    ask('Project details', fields, values => { api.projectUpdate(p.id, values).then(refresh).catch(e => { by('sc-status').textContent = e.message; toast(e.message); }); }, 'SAVE PROJECT');
    fields.forEach((f, i) => { by('fld' + i).value = f.value || ''; });
  }
  function renderCards() {
    const items = state.items.filter(p => (state.filter === 'all' || state.filter === 'pinned' && p.pinned || p.status === state.filter) && [p.name, p.summary, p.path, ...(p.tags || [])].join(' ').toLowerCase().includes(state.query));
    document.querySelectorAll('.sc-filter-tabs button').forEach(b => b.classList.toggle('selected', b.dataset.filter === state.filter));
    by('sc-count').textContent = state.items.length + ' PROJECT' + (state.items.length === 1 ? '' : 'S');
    grid.replaceChildren(...items.map((p, i) => { const card = E('article', { class: 'sc-project-card ' + (p.id === state.selected ? 'selected' : ''), 'data-project': p.id }, E('button', { class: 'sc-card-cover', 'aria-label': 'Select project ' + p.name, onclick: () => { state.selected = p.id; stage.classList.remove('sc-playing'); renderStage(); renderCards(); } }, art(p), E('span', { class: 'sc-card-number' }, String(i + 1).padStart(2, '0')), E('span', { class: 'sc-card-view' }, 'VIEW PROJECT ↗')), E('div', { class: 'sc-card-meta' }, E('div', { class: 'sc-card-title' }, E('h3', {}, p.name), p.pinned ? E('span', {}, '★') : null), E('p', {}, p.summary || p.source + ' project'), E('div', { class: 'sc-card-footer' }, E('span', { class: 'sc-status-pill ' + p.status }, status(p)), E('span', {}, (p.tags || []).slice(0, 2).join(' / ') || p.source)))); card.addEventListener('pointermove', e => { const r = card.getBoundingClientRect(); card.style.setProperty('--mx', (e.clientX - r.left) / r.width * 100 + '%'); card.style.setProperty('--my', (e.clientY - r.top) / r.height * 100 + '%'); }); return card; }));
    if (!items.length && state.items.length) grid.append(E('div', { class: 'sc-no-match' }, 'No projects match this filter.'));
  }
  async function loadCovers(generation) {
    for (const p of state.items) { if (state.covers.has(p.id)) continue; const cover = await api.projectThumbnail(p.id).catch(() => null); if (generation !== state.generation) return; state.covers.set(p.id, cover); }
    if (generation === state.generation) { if (!state.playing) renderStage(); renderCards(); }
  }
  async function refresh() {
    if (state.loading) return; state.loading = true; by('sc-status').textContent = 'Reading your project workspaces…';
    try { const items = await api.projectsList(); if (!Array.isArray(items)) throw Error('Project inventory is unavailable.'); state.items = items; if (!items.some(p => p.id === state.selected)) state.selected = items.find(p => p.pinned)?.id || items[0]?.id || null; state.error = ''; by('sc-status').textContent = ''; renderStage(); renderCards(); loadCovers(++state.generation).catch(e => { by('sc-status').textContent = e.message; }); }
    catch (e) { state.error = e.message; by('sc-status').textContent = e.message; if (!state.items.length) renderStage(); }
    finally { state.loading = false; }
  }
  addEventListener('forge-ready', refresh);
  addEventListener('forge-page', e => { if (e.detail === 'showcase') refresh(); else { stage.classList.remove('sc-playing'); stopPreview(); } });
  window.ForgeShowcase = { state, refresh, play, stop: stopPreview, step };
})();
