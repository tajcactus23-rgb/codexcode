"""Local Kokoro speech; model assets downloaded by the upstream runtime on first use."""
import sys, json
from kokoro import KPipeline
import soundfile as sf
import numpy as np
VOICES = ('af_heart', 'af_bella', 'af_nicole', 'af_sarah', 'af_sky', 'am_fenrir', 'am_michael', 'bf_emma', 'bf_isabella', 'bm_george')
request = json.loads(sys.stdin.read())
voice = request.get('voice', 'bm_george')
if voice not in VOICES:
    raise ValueError('Choose one of the installed Kokoro voice presets')
pipeline = KPipeline(lang_code=voice[0])
chunks = [audio for _, _, audio in pipeline(request['text'], voice=voice, speed=float(request.get('speed', 1)), split_pattern=r'\n+')]
if not chunks:
    raise ValueError('No speech generated')
sf.write(request['output'], np.concatenate(chunks), 24000)
print('FORGE_AUDIO:' + request['output'])
