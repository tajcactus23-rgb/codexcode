// Forge owns conversation history; provider sessions are resumable bindings only.
const fs = require('node:fs');
const path = require('node:path');
module.exports = function registerChatStore({ app, ipcMain }) {
  const file = path.join(app.getPath('userData'), 'forge-conversations.json');
  let chats = {}; try { chats = JSON.parse(fs.readFileSync(file, 'utf8')).chats || {}; } catch {}
  function write() { fs.mkdirSync(path.dirname(file), { recursive: true }); const temp = file + '.tmp'; fs.writeFileSync(temp, JSON.stringify({ schema: 1, chats }, null, 2), { mode: 0o600 }); fs.renameSync(temp, file); }
  ipcMain.handle('chat:list', () => Object.values(chats));
  ipcMain.handle('chat:save', (_e, chat) => {
    if (!chat || typeof chat.id !== 'string' || !Array.isArray(chat.messages) || !Array.isArray(chat.bindings)) throw new Error('Invalid conversation snapshot.');
    const previous = chats[chat.id];
    if (previous && (chat.revision || 0) < (previous.revision || 0)) return previous;
    chats[chat.id] = { ...chat, messages: chat.messages.filter((m) => ['user', 'assistant', 'tool', 'system'].includes(m.role)).map((m) => ({ ...m, text: String(m.text || '') })) };
    write(); return chats[chat.id];
  });
};
