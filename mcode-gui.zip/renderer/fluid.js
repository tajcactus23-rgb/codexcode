// Raymarched fluid metaballs for the left panel. ~18 shiny blobs, smooth-union,
// crisp fresnel highlights, palette mixed from the active theme. WebGL fragment shader.
export function mountFluid(canvas) {
  const gl = canvas.getContext("webgl", { antialias: false, premultipliedAlpha: false });
  if (!gl) return { pulse() {}, busy() {} };
  const N = 22;
  const vsrc = "attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}";
  const fsrc = `
  precision highp float;
  uniform vec2 uRes; uniform float uT, uEnergy, uPulse; uniform vec3 uC1, uC2, uC3;
  #define N ${N}
  // hash + blobs
  vec3 blobPos(int i, float t){
    float f = float(i);
    float a = f*2.399963;
    float r = 0.35 + 0.42*fract(sin(f*12.9898)*43758.5453);
    float sp = 0.2 + 0.5*fract(sin(f*78.233)*12345.678);
    float ph = f*1.7;
    return vec3(
      cos(a + t*sp)*r + 0.18*sin(t*0.7+ph),
      sin(a*1.3 + t*sp*1.1)*r + 0.18*cos(t*0.6+ph),
      0.7*sin(t*sp*0.8+ph));
  }
  float sdSphere(vec3 p, vec3 c, float s){ return length(p-c)-s; }
  float smin(float a, float b, float k){ float h=clamp(0.5+0.5*(b-a)/k,0.,1.); return mix(b,a,h)-k*h*(1.-h); }
  float map(vec3 p, out float id){
    float d = 10.0; id = 0.0;
    float rad = 0.055 + 0.06*uEnergy + 0.05*uPulse;
    for(int i=0;i<N;i++){
      vec3 c = blobPos(i, uT);
      float di = sdSphere(p, c, rad*(0.7+0.6*fract(sin(float(i)*3.3)*99.)));
      float nd = smin(d, di, 0.06 + 0.22*uEnergy);
      if(nd < d) id = float(i);
      d = nd;
    }
    return d;
  }
  vec3 calcN(vec3 p){ float e=0.001; float id; vec2 h=vec2(1.,-1.);
    return normalize(h.xyy*map(p+h.xyy*e,id)+h.yyx*map(p+h.yyx*e,id)+h.yxy*map(p+h.yxy*e,id)+h.xxx*map(p+h.xxx*e,id)); }
  void main(){
    vec2 uv = (gl_FragCoord.xy*2.0-uRes)/uRes.y;
    vec3 ro = vec3(0.,0.,2.6);
    vec3 rd = normalize(vec3(uv, -1.6));
    float t = 0.0, id = 0.0; bool hit=false;
    for(int i=0;i<70;i++){
      vec3 p = ro+rd*t; float d = map(p, id);
      if(d<0.001){ hit=true; break; }
      t += d*0.85; if(t>7.0) break;
    }
    vec3 col = vec3(0.012,0.02,0.045);
    if(hit){
      vec3 p = ro+rd*t; vec3 n = calcN(p);
      vec3 base = mix(uC1, uC2, fract(id*0.37));
      base = mix(base, uC3, 0.4+0.4*sin(id+uT*0.3));
      vec3 l = normalize(vec3(0.5,0.7,0.8));
      float diff = clamp(dot(n,l),0.,1.);
      float fres = pow(1.0-clamp(dot(n,-rd),0.,1.), 3.0);
      vec3 h = normalize(l-rd); float spec = pow(clamp(dot(n,h),0.,1.), 60.0);
      col = base*(0.4+0.7*diff) + fres*base*1.7 + spec*vec3(1.0)*1.3;
      col += base*uPulse*0.4;
    }
    col = pow(col, vec3(0.85));
    gl_FragColor = vec4(col, 1.0);
  }`;
  function sh(type, src) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; }
  const prog = gl.createProgram();
  gl.attachShader(prog, sh(gl.VERTEX_SHADER, vsrc)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, fsrc)); gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return { pulse() {}, busy() {} };
  gl.useProgram(prog);
  const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(prog, "p"); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const U = (n) => gl.getUniformLocation(prog, n);
  const uRes = U("uRes"), uT = U("uT"), uE = U("uEnergy"), uP = U("uPulse"), uC1 = U("uC1"), uC2 = U("uC2"), uC3 = U("uC3");
  const hex = (h, d) => { h = (h || d).replace("#", ""); if (h.length === 3) h = h.split("").map((c) => c + c).join(""); return [parseInt(h.slice(0, 2), 16) / 255, parseInt(h.slice(2, 4), 16) / 255, parseInt(h.slice(4, 6), 16) / 255]; };
  function resize() { const dpr = Math.min(devicePixelRatio, 1) * 0.65; canvas.width = Math.max(1, canvas.clientWidth * dpr); canvas.height = Math.max(1, canvas.clientHeight * dpr); gl.viewport(0, 0, canvas.width, canvas.height); }
  new ResizeObserver(resize).observe(canvas); resize();
  let energy = 0.3, pulse = 0;
  const t0 = performance.now();
  function frame(now) {
    if (window.__bayOpen || document.hidden || document.body.classList.contains("onpage") || window.CFG?.boidsOn === false) return requestAnimationFrame(frame); // occluded behind the Model Bay
    energy += (0.3 - energy) * 0.02; pulse *= 0.94;
    const cs = getComputedStyle(document.documentElement);
    const C = window.CFG || {};
    const c1 = C.boidColors?.[0] || "#35d6ff";
    const c2 = C.boidColors?.[1] || "#ff5db0";
    const c3 = C.boidColors?.[2] || "#8a7dff";
    gl.uniform2f(uRes, canvas.width, canvas.height);
    gl.uniform1f(uT, (now - t0) / 1000);
    gl.uniform1f(uE, energy); gl.uniform1f(uP, Math.min(pulse, 1));
    gl.uniform3fv(uC1, hex(c1, "#2ad4ff")); gl.uniform3fv(uC2, hex(c2, "#ff3fb4")); gl.uniform3fv(uC3, hex(c3, "#b6ff3b"));
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  return { pulse(a = 1) { pulse = Math.min(1.5, pulse + a); energy = Math.min(1.2, energy + 0.3 * a); }, busy(on) { energy = on ? 1 : 0.3; } };
}
