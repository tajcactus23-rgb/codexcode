// Hands-free half-turn voice with concurrent microphone capture for barge-in.
(() => {
  let stream, context, source, processor, mute, audio, utterance, speakJob, transcriptionJob;
  let running = false, speaking = false, transcribing = false, epoch = 0, samples = [], preroll = [], duration = 0, voiced = 0, silent = 0, interruptVoice = 0, ownedTurn = false;
  const cfg = () => window.ForgeIntegrations.voice();
  const status = (s) => { $('voiceStatus').textContent = s; $('voiceBtn').classList.toggle('on', running); $('voiceStop').hidden = !running; };
  function wav(parts, rate) {
    const count = parts.reduce((n, x) => n + x.length, 0), bytes = new ArrayBuffer(44 + count * 2), d = new DataView(bytes);
    const put = (at, s) => { [...s].forEach((c, i) => d.setUint8(at + i, c.charCodeAt(0))); };
    put(0, 'RIFF'); d.setUint32(4, 36 + count * 2, true); put(8, 'WAVE'); put(12, 'fmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true); d.setUint32(24, rate, true); d.setUint32(28, rate * 2, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); put(36, 'data'); d.setUint32(40, count * 2, true);
    let offset = 44; for (const part of parts) for (const x of part) { d.setInt16(offset, Math.max(-1, Math.min(1, x)) * (x < 0 ? 32768 : 32767), true); offset += 2; }
    return bytes;
  }
  function reset() { samples = []; duration = voiced = silent = interruptVoice = 0; preroll = []; }
  function stopSpeech() {
    if (speakJob) api.voiceCancel(speakJob); speakJob = null;
    if (audio) { audio.pause(); URL.revokeObjectURL(audio.src); audio = null; }
    window.speechSynthesis?.cancel(); utterance = null; speaking = false;
  }
  async function speak(text) {
    stopSpeech(); const v = cfg(); if (!text.trim()) return;
    const id = speakJob = crypto.randomUUID(); speaking = true; status('◉ speaking');
    try {
      const clean = text.replace(/```[\s\S]*?```/g, ' Code is shown in the editor. ').replace(/[*#`]/g, '').slice(0, 12000);
      if (v.output === 'endpoint' || v.output === 'clone' || v.output === 'kokoro') {
        const result = v.output === 'kokoro' ? await api.voiceKokoroSpeak(clean, id) : v.output === 'clone' ? await api.voiceCloneSpeak(clean, id) : await api.voiceSpeak(clean, id); if (speakJob !== id) return;
        audio = new Audio(URL.createObjectURL(new Blob([result.bytes], { type: result.mime }))); audio.volume = v.volume;
        await new Promise((resolve, reject) => { audio.onended = resolve; audio.onerror = () => reject(new Error('Speech audio could not be played.')); audio.onpause = resolve; audio.play().catch(reject); });
      } else {
        if (!window.speechSynthesis) throw new Error('System speech is unavailable; choose an endpoint in Voice settings.');
        await new Promise((resolve, reject) => {
          utterance = new SpeechSynthesisUtterance(clean); utterance.lang = v.language || 'en'; utterance.rate = v.rate; utterance.volume = v.volume;
          const chosen = speechSynthesis.getVoices().find((x) => x.name === v.voice); if (chosen) utterance.voice = chosen;
          utterance.onend = resolve; utterance.onerror = (e) => e.error === 'interrupted' || e.error === 'canceled' ? resolve() : reject(new Error('System speech: ' + e.error)); speechSynthesis.speak(utterance);
        });
      }
    } finally { if (speakJob === id) { stopSpeech(); if (running) status('◉ listening'); else status(''); } }
  }
  async function submit(parts, rate, gen) {
    transcribing = true; status('◉ transcribing'); const id = transcriptionJob = crypto.randomUUID();
    try {
      const bytes = wav(parts, rate);
      const text = (await (cfg().sttBase ? api.voiceTranscribe(bytes, 'audio/wav', id) : api.voiceLocalTranscribe(bytes, id))).trim();
      if (!running || gen !== epoch || !text) return;
      $('prompt').value = [$('prompt').value, text].filter(Boolean).join(' ');
      if (!cfg().autoSend) { $('prompt').focus(); return; }
      // An interrupted ACP turn must finish cancellation before the next turn starts.
      const deadline = Date.now() + 8000;
      while (cur?.busy && Date.now() < deadline && running && gen === epoch) await new Promise((r) => setTimeout(r, 100));
      if (!running || gen !== epoch) return;
      if (cur?.busy) { toast('Previous turn is still stopping. Your voice text is in the composer.'); return; }
      const message = $('prompt').value; $('prompt').value = ''; ownedTurn = true; status('◉ waiting for model');
      transcribing = false;
      await sendText(message);
    } catch (e) { if (running && gen === epoch) { toast(e.message); status('Voice error · text preserved'); } }
    finally { if (gen === epoch) { transcribing = false; transcriptionJob = null; if (running && !speaking && !cur?.busy) status('◉ listening'); } }
  }
  function capture(event) {
    if (!running || transcribing) return;
    const v = cfg(), data = new Float32Array(event.inputBuffer.getChannelData(0)), ms = data.length / context.sampleRate * 1000;
    let sum = 0; for (const x of data) sum += x * x; const loud = Math.sqrt(sum / data.length) > v.threshold;
    if ((speaking || cur?.busy) && !v.bargeIn) { reset(); return; }
    if (speaking || cur?.busy) {
      interruptVoice = loud ? interruptVoice + ms : 0;
      preroll.push(data); if (preroll.length > 6) preroll.shift();
      if (interruptVoice < v.minSpeechMs) return;
      stopSpeech(); if (cur?.busy) { ownedTurn = false; api.acpCancel(cur.engine, cur.sessionId); }
      samples = preroll.slice(); duration = voiced = interruptVoice; silent = 0; interruptVoice = 0; preroll = []; status('◉ listening · interrupted');
      return;
    }
    if (!samples.length) {
      preroll.push(data); if (preroll.length > 6) preroll.shift();
      if (!loud) return;
      samples = preroll.slice(); preroll = [];
    } else samples.push(data);
    duration += ms; if (loud) { voiced += ms; silent = 0; } else silent += ms;
    if (silent >= v.silenceMs || duration >= v.maxRecordSec * 1000) {
      const turn = samples; const enough = voiced >= v.minSpeechMs, rate = context.sampleRate; reset();
      if (enough) submit(turn, rate, epoch);
    }
  }
  async function start() {
    if (running) return stop(); const v = cfg();
    if (!v.sttBase) { const check = await api.voiceCloneCheck(); if (!check.ok) { window._setTab = 'voice'; openSettings(); throw new Error('Install the local voice runtime or set a transcription endpoint in Voice settings.'); } }
    const gen = ++epoch;
    const input = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, ...(v.deviceId ? { deviceId: { exact: v.deviceId } } : {}) }, video: false });
    if (gen !== epoch) { input.getTracks().forEach((t) => t.stop()); return; }
    try {
      stream = input; context = new AudioContext(); await context.resume(); source = context.createMediaStreamSource(stream);
      processor = context.createScriptProcessor(2048, 1, 1); mute = context.createGain(); mute.gain.value = 0;
      source.connect(processor); processor.connect(mute); mute.connect(context.destination); processor.onaudioprocess = capture;
      running = true; reset(); status('◉ listening');
      stream.getAudioTracks()[0].onended = stop;
    } catch (e) { stop(); throw e; }
  }
  function stop() {
    running = false; ++epoch; transcribing = false; ownedTurn = false; if (transcriptionJob) api.voiceCancel(transcriptionJob); transcriptionJob = null;
    stopSpeech(); if (processor) { processor.onaudioprocess = null; processor.disconnect(); } source?.disconnect(); mute?.disconnect(); stream?.getTracks().forEach((t) => { t.onended = null; t.stop(); }); context?.close();
    stream = context = source = processor = mute = null; reset(); status('');
  }
  $('voiceBtn').onclick = () => start().catch((e) => toast(e.message)); $('voiceStop').onclick = stop;
  addEventListener('forge-turn-ended', (event) => {
    const read = running && ownedTurn && cfg().speakReplies; ownedTurn = false;
    if (read) speak(event.detail.text).catch((e) => { toast(e.message); if (running) status('◉ listening'); });
  });
  addEventListener('beforeunload', stop);
  window.ForgeVoice = { start, stop, speak };
})();
