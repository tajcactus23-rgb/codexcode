# BM23-TOOLZ Coder IDE — status + rest-of-build plan (2026-10-05)

Status key: ✅ done + verified · 🟡 built, not fully verified · 🔴 broken / missing · ⚪ not started

## Drift check — what you asked vs where it stands

| Ask | Status | Notes |
|---|---|---|
| File upload, any type (py/html/zip/rar/7z…) | ✅ | Live agent read attached .py + zip. Drag-drop not proven (can't fake an OS drag). |
| Local models: scan PC, load, chat | 🟡 | Load ✅, chat ✅, tools ✅, auto-restart ✅, orphan killer ✅. **Turn 2+ compaction bug** — fix applied (CloudBase + Chrome DevTools plugins disabled), retest running. |
| Model Bay LOCAL tab, animated cards, lattice | ✅ | Crisp, native res. FX toggle AUTO/HIGH/LOW/OFF for low spec. |
| Hugging Face lineup (visuals / uncensored coder / Hermes…) | ✅ | Live from HF; HF had a 500 outage tonight. |
| HF downloads (resume + sha256) | 🟡 | Code written, **never run on a real download**. |
| Recommended-by-hardware (like Lemonade) | ⚪ | Next. |
| Plugin marketplace redesign | ⚪ | Concept pitch first. |
| **Direct updating from GitHub** | ⚪ | **Not implemented.** Was on the deferred list since day 1. |
| Lottie creator tab | ⚪ | Parked by you for local models. |
| Orange-everywhere reactor | 🔴 | Still open from day 1 (reactor follows GOAL tab gold). |
| Settings backdrop | 🟡 | Untested neon streaks; never confirmed with you. |
| Stray `_FORGED` folder merge, ~400 junk Codex pages | ⚪ | Open from day 1. |
| mcode build missing ripgrep (agent glob/grep degraded) | 🔴 | Found day 2, never fixed. |

## Honest drift notes
- Burned a long stretch reverse-engineering mcode's context compaction, with two wrong theories (64K context, byte cap) before the real cause (plugin MCP tools, +42K tokens on turn 2-3).
- Leftovers from that: `MAVIS_MCP_TOOL_SEARCH_WHITELIST` in `main.cjs` (proven ineffective — remove) and a `max_request_body_bytes` entry in `~/.minimax/config.yaml` (harmless; backup `config.yaml.bak-bm23`).
- Unsloth's llama.cpp build loads but runs CPU-only here — not used.

## Plan, in order
1. **Finish local-model reliability** (in progress)
   - Confirm 5-turn retest passes on gpt-oss and Qwen with the plugins off.
   - Remove the dead whitelist env; keep auto context (64K fits-in-VRAM / 32K spills).
   - Show the real error in chat for any local failure (no blank replies) — verify on screen.
   - Fix mcode's missing ripgrep so the agent's glob/grep work at full strength.
   - Coder context = coding only: built-in tools, no GUI/cloud plugins (GUI work lives in the Forge tab).
2. **Recommended for this PC** — best quant per model for 8 GB VRAM / 32 GB RAM, ranked by measured tok/s on this PC + tool-calling reliability; partial-download resume tag; first real download test.
3. **Direct updating from GitHub** — check mcode / llama.cpp / IDE releases, show changelog, one-click update with backup + rollback.
4. **Plugin marketplace redesign** — own card (what it adds, context-cost meter, trust badge, Lean/Full switches) + own backdrop. Pitch concept before building.
5. **Day-1 debt** — orange reactor palette, settings backdrop (confirm concept), `_FORGED` merge, hide/tag junk Codex pages.
6. **Lottie creator tab** — scope with you first.
