// MODEL BAY · LOCAL — device scan, live Hugging Face lineup, downloads, load-into-chat.
// Loaded after app.js (shares its globals: $, h, api, toast, cur, engine, newSession, setModel).
(() => {
  const L = { st: null, cat: [], lane: "suggested", sort: "recommended", q: "", jobs: new Map(), groups: new Map(), ctx: 0, rec: null };
  const LANES = [["suggested", "⭐ SUGGESTED"], ["visuals", "🎨 VISUALS"], ["coder", "⌥ CODER"], ["uncensored-coder", "🔓 UNCENSORED CODER"], ["uncensored", "🔓 UNCENSORED"], ["hermes", "☿ HERMES"], ["agent", "◎ AGENT"]];
  // sort slider for the lineup — the user asked for a popular/recent/recommended toggle like the Model Bay has
  const SORTS = [["recommended", "⭐ RECOMMENDED FOR YOUR PC"], ["popular", "♥ MOST POPULAR"], ["recent", "⏱ MOST RECENT"]];
  const fmtN = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n || 0));
  const fmtB = (n) => (n >= 1073741824 ? (n / 1073741824).toFixed(2) + " GB" : (n / 1048576).toFixed(0) + " MB");
  const hueNum = (id) => { let x = 0; for (const c of String(id)) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
  const hue = (id) => `hsl(${hueNum(id)} 95% 62%)`;
  const slug = (id) => String(id).toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 48) + "-" + hueNum(id + "#") + (String(id).length % 97);
  const rate = (m) => (m ? Math.min(100, Math.round(m.rating / 1.2)) : null);
  const errText = (e) => String(e?.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, "");
  const mono = (id) => h("span", { class: "logo mono" }, String(id).split("/")[0].slice(0, 2).toUpperCase());
  const fitOf = (gb) => { const hw = L.st?.hw || {}; if (hw.vramGB && gb + 1.5 <= hw.vramGB) return ["ok", "fits GPU"]; if (gb <= (hw.ramGB || 0) * 0.62) return ["warn", "GPU+RAM"]; return ["bad", "too big"]; };
  const catFor = (repo) => L.cat.find((c) => c.id === repo);

  function setTab(t) {
    document.querySelectorAll("#mdlTabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === t));
    const local = t === "local";
    $("mdlLocal").hidden = !local;
    for (const sel of ["#mdlGrid", ".mdl-note", ".mdl-key", "#mdlSearch", "#mdlMod", "#mdlSort", "#mdlBenchAll"]) { const e = document.querySelector("#mdl " + sel); if (e) e.hidden = local; }
    let cv = $("bayLattice");
    if (!cv) { cv = h("canvas", { id: "bayLattice" }); $("mdl").prepend(cv); }
    window.__bayOpen = true;
    cv.hidden = !local;
    if (local) { window.BayLattice?.start(cv); openLocal(); } else window.BayLattice?.stop();
  }
  document.querySelectorAll("#mdlTabs button").forEach((b) => (b.onclick = () => setTab(b.dataset.t)));

  async function openLocal() {
    $("mdlLocal").replaceChildren(h("div", { class: "note" }, "scanning this PC…"));
    L.st = await api.localState();
    render();
    if (!L.cat.length) {
      try { L.cat = await api.localCatalog(false); if (!L.cat.length) { await new Promise((r) => setTimeout(r, 1500)); L.cat = await api.localCatalog(true); } }
      catch (e) { toast("Hugging Face: " + errText(e)); }
      render();
    }
    if (!L.rec) { try { L.rec = await api.localRecommend(false); } catch { L.rec = []; } render(); }
  }
  async function refresh() { L.st = await api.localState(); render(); }

  function rig() {
    const s = L.st, hw = s.hw || {}, rt = s.runtime, sv = s.server;
    return h("div", { class: "lc-rig" },
      h("span", { class: "chip" }, "GPU ", h("b", {}, hw.gpu ? `${hw.gpu.replace(/NVIDIA GeForce /, "")} · ${hw.vramGB} GB` : "none")),
      h("span", { class: "chip" }, "RAM ", h("b", {}, hw.ramGB + " GB")),
      s.gpu ? h("span", { class: "chip" + (s.gpu.freeGB < 3 && !sv.running ? " warn" : ""), title: s.gpu.apps.length ? "Also using the GPU: " + s.gpu.apps.map((a) => a.name + " (" + a.pid + ")").join(", ") : "" },
        "VRAM FREE ", h("b", {}, `${s.gpu.freeGB} / ${s.gpu.totalGB} GB`), s.gpu.freeGB < 3 && !sv.running && s.gpu.apps.length ? h("b", { class: "hog" }, " · held by " + s.gpu.apps.map((a) => a.name.replace(/\.exe$/i, "")).join(", ")) : null) : null,
      h("span", { class: "chip" + (rt ? "" : " warn") }, "RUNTIME ", h("b", {}, rt ? `llama.cpp ${rt.tag} ${rt.variant} (${rt.source})` : "missing"),
        rt ? null : h("button", { onclick: async () => { try { await api.localRuntimeInstall(); } catch (e) { toast(errText(e)); } } }, "⬇ install")),
      h("span", { class: "chip" }, "FOLDER ", h("b", { title: s.modelDir || "" }, s.modelDir ? s.modelDir + (s.freeGB != null ? ` · ${s.freeGB} GB free` : "") : "not set"),
        h("button", { onclick: async () => { if (await api.localPickDir()) refresh(); } }, "📁 choose")),
      h("span", { class: "chip " + (sv.ready ? "live" : "") }, sv.ready ? "● SERVING " : "○ IDLE ", h("b", {}, sv.alias || ""),
        sv.running ? h("button", { onclick: async () => { await api.localStop(); refresh(); } }, "■ stop") : null),
      h("label", { class: "chip" }, "CONTEXT ", h("select", { onchange: (e) => (L.ctx = +e.target.value) },
        ...[0, 32768, 65536, 131072].map((n) => h("option", { value: n, ...(n === L.ctx ? { selected: true } : {}) }, n ? n / 1024 + "K" : "AUTO")))),
      h("label", { class: "chip", title: "Backdrop quality. AUTO drops to LOW if the GPU struggles. LOW = 1x pixels, lighter raymarch. OFF = animated gradient only." }, "FX ",
        h("select", { onchange: (e) => window.BayLattice?.setQuality(e.target.value) },
          ...[["auto", "AUTO"], ["high", "HIGH"], ["low", "LOW"], ["off", "OFF"]].map(([v, t]) => h("option", { value: v, ...(window.BayLattice?.getQuality() === v ? { selected: true } : {}) }, t)))));
  }

  // ---- animated card: segmented spinning ring, scanning border, holo sweep, count-up stats, spec bars, tilt
  function fxRing(v) {
    const C = 2 * Math.PI * 17, svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 44 44"); svg.setAttribute("class", "lc-ring");
    const spin = v == null ? 0 : (14 - (v / 100) * 10).toFixed(1); // higher rating = faster spin
    svg.style.setProperty("--spin", spin + "s");
    svg.innerHTML = `<g class="seg"><circle cx="22" cy="22" r="20.5"/></g><circle cx="22" cy="22" r="17" class="rb"/>`
      + `<circle cx="22" cy="22" r="17" class="rf" stroke-dasharray="0 ${C}" data-arc="${(C * (v || 0)) / 100} ${C}"/>`
      + `<text x="22" y="26.5" data-to="${v == null ? "" : v}">${v == null ? "—" : 0}</text>`;
    return svg;
  }
  const bar = (label, frac, txt, lvl) => h("span", { class: "lc-sb" + (lvl ? " l-" + lvl : "") }, h("em", {}, label),
    h("span", { class: "segs", style: `--f:${Math.max(0, Math.min(1, frac || 0))}` }, ...Array.from({ length: 12 }, (_, k) => h("i", { style: `--k:${k}` }))), h("b", {}, txt));
  function fxCard({ key, title, sub, rating, bars, badges, state, onclick, vt }, i) {
    const hn = hueNum(key), col = `hsl(${hn} 96% 62%)`;
    const el = h("button", { class: "lc-card" + (state ? " st-" + state : ""), style: `--h:${hn};--d:${Math.min(i, 30) * 45}ms`, onclick: (e) => { window.BayLattice?.pulse(col); onclick(e); } },
      h("span", { class: "lc-scan" }), h("span", { class: "lc-sheen" }),
      h("span", { class: "lc-hd" }, mono(key), h("span", { class: "lc-tt" }, h("b", {}, title), h("small", {}, sub)), fxRing(rating)),
      h("span", { class: "lc-bars" }, ...bars),
      h("span", { class: "lc-bdg" }, ...badges.filter(Boolean)));
    if (vt) el.dataset.vt = "lcl-" + slug(key);
    el.addEventListener("pointermove", (e) => { const r = el.getBoundingClientRect(); el.style.setProperty("--px", Math.round(e.clientX - r.left) + "px"); });
    el.addEventListener("pointerenter", () => { el.classList.add("hot"); window.BayLattice?.focus(col); });
    el.addEventListener("pointerleave", () => el.classList.remove("hot"));
    return el;
  }
  // arcs sweep and numbers count up once cards are in the DOM
  function animateIn(root, instant) {
    if (instant) {
      root.querySelectorAll(".lc-ring .rf").forEach((c) => c.setAttribute("stroke-dasharray", c.dataset.arc));
      root.querySelectorAll(".lc-ring text[data-to]").forEach((tx) => { if (tx.dataset.to) tx.textContent = tx.dataset.to; });
      return;
    }
    requestAnimationFrame(() => {
      root.querySelectorAll(".lc-ring .rf").forEach((c) => c.setAttribute("stroke-dasharray", c.dataset.arc));
      root.querySelectorAll(".lc-ring text[data-to]").forEach((tx) => {
        const to = +tx.dataset.to; if (!tx.dataset.to) return;
        const t0 = performance.now(), step = (now) => { const k = Math.min(1, (now - t0) / 900); tx.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))); if (k < 1) requestAnimationFrame(step); };
        requestAnimationFrame(step);
      });
    });
  }
  const glitch = (txt) => h("span", { class: "lc-glitch", "data-t": txt }, txt);
  const bdg = (txt, cls) => h("span", { class: "lc-tag " + (cls || "") }, txt);
  function installedCard(m, i) {
    const info = catFor(m.repo), [lv, lt] = fitOf(m.sizeGB);
    const serving = L.st.server.file === m.file && L.st.server.ready;
    const vram = L.st.hw?.vramGB || 8;
    return fxCard({ key: m.repo || m.name, title: m.name, sub: (m.repo || "local file") + " · " + m.source, rating: rate(info),
      state: serving ? "live" : lv === "bad" ? "bad" : "",
      bars: [bar("SIZE", m.sizeGB / (vram * 3), m.sizeGB + " GB"), bar("FIT", lv === "ok" ? 1 : lv === "warn" ? 0.55 : 0.15, lt, lv),
        m.bench ? bar("SPEED", m.bench.tps / 60, m.bench.tps + " tok/s", m.bench.tps >= 15 ? "ok" : m.bench.tps >= 6 ? "warn" : "bad")
          : bar("HF ♥", info ? Math.log10(1 + info.likes) / 4 : 0, info ? fmtN(info.likes) : "—")],
      badges: [serving ? bdg("● SERVING", "live") : null, m.weak ? bdg(m.quant + " · WEAK FOR CODE", "weak") : m.quant ? bdg(m.quant) : null,
        !m.bench ? bdg("⚡ NOT BENCHED", "dim") : null, info?.uncensored ? glitch("UNCENSORED") : null,
        info?.cats.includes("visuals") ? bdg("🎨 VISUALS") : null, info?.cats.includes("coder") ? bdg("⌥ CODER") : null],
      onclick: (e) => detailInstalled(m, e.currentTarget) }, i);
  }
  function lineupCard(m, i) {
    const p = m.paramsB, vram = L.st?.hw?.vramGB || 8;
    const estGB = p ? p * 0.6 : null, [lv, lt] = estGB ? fitOf(m.activeB ? Math.min(estGB, vram - 1.6) + (estGB > vram ? 0.01 : 0) : estGB) : ["", "size ?"];
    return fxCard({ key: m.id, title: m.name.replace(/-GGUF$/i, ""), sub: m.author + (m.updated ? " · " + m.updated.slice(0, 10) : ""), rating: rate(m),
      bars: [bar("DL", Math.log10(1 + m.downloads) / 7, fmtN(m.downloads)), bar("♥", Math.log10(1 + m.likes) / 4, fmtN(m.likes)),
        bar("PARAMS", p ? Math.min(1, p / 70) : 0, p ? p + "B" + (m.activeB ? " · A" + m.activeB + "B" : "") : "?", p ? lv : "")],
      badges: [m.uncensored ? glitch("UNCENSORED") : null, m.cats.includes("visuals") ? bdg("🎨 VISUALS") : null,
        m.cats.includes("coder") ? bdg("⌥ CODER") : null, m.hermes ? bdg("☿ HERMES") : null, m.activeB ? bdg("MoE") : null],
      onclick: (e) => detailRepo(m, e.currentTarget), vt: true }, i);
  }
  function lane() {
    const q = L.q.toLowerCase();
    let list = L.cat.filter((m) => !q || m.id.toLowerCase().includes(q));
    const vram = L.st?.hw?.vramGB || 8, ram = L.st?.hw?.ramGB || 16;
    const usable = (m) => !m.paramsB || (m.activeB ? m.paramsB * 0.6 <= ram * 0.62 : m.paramsB * 0.6 <= Math.max(vram * 1.6, 14));
    const boost = (m) => (m.cats.includes("visuals") ? 25 : 0) + (m.cats.includes("uncensored-coder") ? 20 : 0) + (m.cats.includes("coder") ? 10 : 0);
    // category filter: SUGGESTED keeps everything that fits this PC; the rest filter by category
    if (L.lane === "suggested") list = list.filter(usable);
    else list = list.filter((m) => m.cats.includes(L.lane));
    // sort slider: recommended (fit + rating + category boost), popular (HF downloads), recent (updated)
    if (L.sort === "popular") list.sort((a, b) => (b.downloads || 0) - (a.downloads || 0));
    else if (L.sort === "recent") list.sort((a, b) => String(b.updated || "").localeCompare(String(a.updated || "")));
    else list.sort((a, b) => (b.rating + boost(b) + (usable(b) ? 15 : 0)) - (a.rating + boost(a) + (usable(a) ? 15 : 0)));
    return list.slice(0, 60);
  }

  // name only cards inside the visible scroll area, so nothing animates outside the bay
  function nameVisible(grid) {
    const box = $("mdlLocal").getBoundingClientRect();
    for (const c of grid.children) {
      if (!c.dataset.vt) continue;
      const r = c.getBoundingClientRect();
      c.style.viewTransitionName = r.bottom > box.top && r.top < box.bottom ? c.dataset.vt : "none";
    }
  }
  function renderLineup() {
    document.querySelectorAll(".lc-lanes button[data-lane]").forEach((b) => b.classList.toggle("on", b.dataset.lane === L.lane));
    const g = $("lcLineup"); if (!g) return;
    g.classList.add("vt");
    g.replaceChildren(...(L.cat.length ? lane().map(lineupCard) : [h("div", { class: "note" }, "loading lineup from Hugging Face…")]));
    animateIn(g, true);
  }
  function switchLane(k) {
    if (k === L.lane) return;
    L.lane = k;
    window.BayLattice?.pulse();
    const g = $("lcLineup");
    if (!document.startViewTransition || !g) return renderLineup();
    nameVisible(g);
    try {
      const vt = document.startViewTransition(() => { renderLineup(); nameVisible($("lcLineup")); });
      vt.ready.catch(() => {}); vt.updateCallbackDone.catch(() => {});
      vt.finished.catch(() => { if (!$("lcLineup")?.children.length) renderLineup(); });
    } catch { renderLineup(); }
  }
  function render() {
    if ($("mdlLocal").hidden || !L.st) return;
    const inst = L.st.installed || [];
    $("mdlCount").textContent = `${inst.length} on this PC · ${L.cat.length} on Hugging Face`;
    $("mdlLocal").replaceChildren(
      rig(),
      h("div", { class: "lc-sec" }, `ON THIS PC — ${inst.length} chat model${inst.length === 1 ? "" : "s"} found (HF cache, LM Studio, your folder)`, h("button", { onclick: refresh }, "↻ rescan")),
      h("div", { class: "lc-grid" }, ...(inst.length ? inst.map(installedCard) : [h("div", { class: "note" }, "No local chat models found. Choose a folder or download one below.")])),
      partialsBox(),
      downloadsBox(),
      h("div", { class: "lc-sec" }, "RECOMMENDED FOR THIS PC — best quant per model for your " + (L.st.hw?.vramGB || "?") + " GB GPU / " + (L.st.hw?.ramGB || "?") + " GB RAM, never below 4-bit"),
      h("div", { class: "lc-grid", id: "lcRec" }, ...(L.rec == null ? [h("div", { class: "note" }, "working out the best picks for this PC…")]
        : L.rec.length ? L.rec.map((r, i) => recCard(r, i)).filter(Boolean) : [h("div", { class: "note" }, "No recommendations (Hugging Face unreachable?)")])),
      h('div', { class: 'lc-library' },
        h('strong', {}, 'MODEL LIBRARY'),
        h('select', { id: 'hfSource' }, h('option', { value: 'huggingface' }, 'Hugging Face'), ...['unsloth', 'DavidAU', 'HauhauCS', 'bartowski', 'mradermacher', 'NousResearch', 'uncensored'].map(x => h('option', { value: x }, x === 'uncensored' ? 'Uncensored · all authors' : x + ' GGUFs'))),
        h('input', { id: 'hfQuery', placeholder: 'Search live Hub models or paste owner/repository', value: L.hubQ || '' }),
        h('button', { onclick: async () => {
          const search = $('hfQuery').value.trim(), source = $('hfSource').value; L.hubQ = search;
          const result = $('hfResults'); result.replaceChildren(h('p', {}, 'Searching live model library…'));
          try { if (/^[\w.-]+\/[\w.-]+$/.test(search)) return await detailRepo({ id: search, name: search.split('/')[1], author: search.split('/')[0], downloads: 0, likes: 0, cats: [], tags: [] });
            const list = await api.localSearch({ search, source }); result.replaceChildren(...(list.length ? list.map(lineupCard) : [h('p', {}, 'No matching GGUF chat models found.')]));
          } catch (e) { result.replaceChildren(h('p', {}, errText(e))); }
        } }, 'SEARCH HUB'), h('div', { class: 'lc-grid', id: 'hfResults' })),
      h('div', { class: 'quant-guide' }, h('h3', {}, 'QUANT / MODEL FIELD GUIDE'), h('p', {}, 'Start at Q4_K_M; use Q5_K_M or Q6_K when weights + KV cache + runtime overhead fit. Q8_0 uses more memory. Lower IQ quants trade quality for capacity. Reserve at least 2–4 GB beyond weights and begin at 8K context; longer context needs more KV memory.'), h('p', {}, 'For coding, test a coder/instruct model’s actual tool calling first. Browse DavidAU’s 9B Defiant Fable and 27B NEO-CODER/Fable variants, HauhauCS releases and Nous Hermes. Author names and “uncensored” labels are not coding benchmarks. Use live quant file sizes and your hardware fit estimate before downloading.')),
      h("div", { class: "lc-sec" }, "LINEUP — live from Hugging Face · ring = HF rating (downloads + likes)",
        h("button", { onclick: async () => { L.cat = []; render(); try { L.cat = await api.localCatalog(true); } catch (e) { toast(errText(e)); } render(); } }, "↻ refresh")),
      h("div", { class: "lc-lanes" },
        ...LANES.map(([k, t]) => h("button", { class: L.lane === k ? "on" : "", "data-lane": k, onclick: () => switchLane(k) }, t + (k === "suggested" ? "" : " " + L.cat.filter((m) => m.cats.includes(k)).length))),
        h("input", { placeholder: "search the lineup…", value: L.q, oninput: (e) => { L.q = e.target.value; renderLineup(); } })),
      // sort slider: recommended-for-your-PC / most popular / most recent
      h("div", { class: "lc-sort" },
        ...SORTS.map(([k, t]) => h("button", { class: "lc-sortbtn" + (L.sort === k ? " on" : ""), "data-sort": k, onclick: () => { if (L.sort === k) return; L.sort = k; window.BayLattice?.pulse(); renderLineup(); } }, t))),
      h("div", { class: "lc-grid", id: "lcLineup" }, ...(L.cat.length ? lane().map(lineupCard) : [h("div", { class: "note" }, "loading lineup from Hugging Face…")])));
    animateIn($("mdlLocal"));
  }

  // ---- recommended + partials
  function recCard(r, i) {
    const m = L.cat.find((c) => c.id === r.id); if (!m) return null;
    const p = r.pick, have = (L.st.installed || []).some((x) => x.name.toLowerCase() === p.key.split("/").pop().toLowerCase());
    return fxCard({ key: m.id, title: m.name.replace(/-GGUF$/i, ""), sub: r.why, rating: rate(m),
      bars: [bar("BEST", Math.min(1, (parseInt(p.quant.replace(/\D/g, "")) || 4) / 8), p.quant, p.fit.level === "green" ? "ok" : "warn"),
        bar("SIZE", p.sizeGB / ((L.st.hw?.vramGB || 8) * 3), p.sizeGB + " GB"), bar("♥", Math.log10(1 + m.likes) / 4, fmtN(m.likes))],
      badges: [have ? bdg("✓ INSTALLED", "live") : bdg("★ PICK #" + (i + 1)), m.uncensored ? glitch("UNCENSORED") : null, m.cats.includes("coder") ? bdg("⌥ CODER") : null,
        m.cats.includes("visuals") ? bdg("🎨 VISUALS") : null, m.activeB ? bdg("MoE") : null],
      onclick: (e) => detailRepo(m, e.currentTarget, p.key) }, i);
  }
  function partialsBox() {
    const ps = (L.st.partials || []).filter((p) => !p.running);
    if (!ps.length) return h("div", { id: "lcPart" });
    return h("div", { id: "lcPart", class: "lc-dl" }, h("div", { class: "lc-sec" }, "UNFINISHED DOWNLOADS"),
      ...ps.map((p) => h("div", { class: "lc-job s-paused" },
        h("div", { class: "lc-jt" }, h("b", {}, p.group.key.split("/").pop()), h("span", {}, `${p.haveGB} / ${p.totalGB} GB · ${p.pct}% · ${p.repo}`)),
        h("div", { class: "lc-bar" }, h("i", { style: `width:${p.pct}%` })),
        h("div", { class: "lc-ja" }, h("button", { onclick: () => { startDl(p.repo, p.group); setTimeout(refresh, 400); } }, "▶ resume")))));
  }
  // ---- downloads
  function downloadsBox() {
    const jobs = [...L.jobs.values()].filter((j) => j.state !== "done" || Date.now() - (j.doneAt || 0) < 15000);
    if (!jobs.length) return h("div", { id: "lcDl" });
    return h("div", { id: "lcDl", class: "lc-dl" }, h("div", { class: "lc-sec" }, "DOWNLOADS"), ...jobs.map(jobRow));
  }
  function jobRow(j) {
    const p = j.p || {}, pct = p.total ? (p.done / p.total) * 100 : 0;
    const label = j.state === "running"
      ? (j.phase === "verify" ? `verifying sha256 ${Math.round((p.verifyPct || 0) * 100)}%` : j.phase === "unpack" ? "unpacking…"
        : `${fmtB(p.done || 0)} / ${fmtB(p.total || j.meta.totalBytes || 0)} · ${p.bps ? fmtB(p.bps) + "/s" : "…"}${p.eta ? " · " + Math.ceil(p.eta / 60) + " min left" : ""}`)
      : j.state === "error" ? "✗ " + j.error : j.state;
    return h("div", { class: "lc-job s-" + j.state, id: "job" + j.id },
      h("div", { class: "lc-jt" }, h("b", {}, j.meta.title), h("span", {}, label)),
      h("div", { class: "lc-bar" }, h("i", { style: `width:${pct.toFixed(1)}%` })),
      h("div", { class: "lc-ja" },
        j.state === "running" ? h("button", { onclick: () => api.localJobAction(j.id, "pause") }, "⏸ pause") : null,
        (j.state === "paused" || j.state === "error") && L.groups.get(j.id) ? h("button", { onclick: () => startDl(j.meta.repo, L.groups.get(j.id)) }, "▶ resume") : null,
        j.state === "running" || j.state === "paused" ? h("button", { onclick: () => api.localJobAction(j.id, "cancel") }, "✕ cancel") : null));
  }
  async function startDl(repo, group) {
    try { const id = await api.localDownload(repo, group); L.groups.set(id, group); toast("⬇ downloading " + group.key.split("/").pop()); }
    catch (e) { toast(errText(e)); }
  }
  api.onLocalEvent((ev) => {
    if (ev.kind === "job") {
      const j = L.jobs.get(ev.id) || { id: ev.id };
      Object.assign(j, { state: ev.state, meta: ev.meta, error: ev.error });
      L.jobs.set(ev.id, j);
      if (ev.state === "done") { j.doneAt = Date.now(); toast("✓ " + ev.meta.title + " ready"); window.BayLattice?.pulse("#3bff9a"); refresh(); }
      else if (!$("mdlLocal").hidden) $("lcDl")?.replaceWith(downloadsBox());
    } else if (ev.kind === "progress" || ev.kind === "phase") {
      window.BayLattice?.energy(true);
      const j = L.jobs.get(ev.id); if (!j) return;
      if (ev.kind === "phase") j.phase = ev.phase; else j.p = ev;
      const row = $("job" + ev.id); if (row) row.replaceWith(jobRow(j)); else $("lcDl")?.replaceWith(downloadsBox());
    } else if (ev.kind === "server" && L.st) {
      if (ev.ready) window.BayLattice?.pulse("#3bff9a");
      L.st.server = ev;
      if (ev.exited != null) {
        toast("local model server stopped: " + (ev.reason || "exit " + ev.exited));
        if (/local-llama/.test($("model").value)) err("Local model server stopped: " + (ev.reason || "exit code " + ev.exited) + ". It restarts automatically on your next message.");
      }
      render();
    }
  });

  // ---- detail cards (same flip-out as the cloud bay)
  function show(panel, from) {
    $("mdDetail")?.remove();
    panel.classList.add("lc-detail");
    panel.prepend(h("span", { class: "lc-scan" }));
    const ov = h("div", { id: "mdDetail", onclick: (e) => { if (e.target.id === "mdDetail") ov.remove(); } }, panel);
    if (from) { const r = from.getBoundingClientRect(); panel.style.setProperty("--fx", r.left + r.width / 2 - innerWidth / 2 + "px"); panel.style.setProperty("--fy", r.top + r.height / 2 - innerHeight / 2 + "px"); }
    document.body.append(ov);
    animateIn(panel);
  }
  const stat = (k, v) => h("div", { class: "st" }, h("span", {}, k), h("b", {}, v));
  function hfChips(info) {
    return h("div", { class: "chips" }, ...info.cats.map((c) => h("span", { class: "chip in" }, c)),
      info.uncensored ? h("span", { class: "chip warn" }, "🔓 uncensored / abliterated") : null,
      ...(info.tags || []).filter((t) => !/^(license|region|base_model|arxiv|dataset):|^gguf$|^endpoints/.test(t)).slice(0, 10).map((t) => h("span", { class: "chip" }, t)));
  }
  function hfBlock(info) {
    if (!info) return [h("div", { class: "md-sec" }, "HUGGING FACE"), h("div", { class: "md-desc" }, "Not in the current lineup, so no HF rating is cached for this repo.")];
    return [h("div", { class: "md-sec" }, "HUGGING FACE"),
      h("div", { class: "md-stats" }, stat("DOWNLOADS", fmtN(info.downloads)), stat("LIKES", fmtN(info.likes)), stat("LICENSE", info.license || "—"), stat("UPDATED", info.updated ? info.updated.slice(0, 10) : "—")),
      hfChips(info)];
  }
  function detailInstalled(m, from) {
    const info = catFor(m.repo), [lv, lt] = fitOf(m.sizeGB), sv = L.st.server, running = sv.ready && sv.file === m.file;
    const out = h("div", { class: "md-desc", id: "lcOut" }, running ? "Loaded and serving." : lv === "bad" ? "⚠ Bigger than this PC holds comfortably: expect it to fail or crawl." : "Not loaded.");
    show(h("div", { class: "md-card", style: `--mh:${hue(m.repo || m.name)}` },
      h("div", { class: "md-top" }, mono(m.repo || m.name), h("div", {}, h("div", { class: "md-nm" }, m.name), h("div", { class: "md-id" }, m.repo || m.file)), h("div", { class: "grow" }), fxRing(rate(info))),
      h("div", { class: "md-stats" }, stat("SIZE", m.sizeGB + " GB"), stat("FIT · THIS PC", lt), stat("SOURCE", m.source), stat("CONTEXT", L.ctx ? L.ctx / 1024 + "K" : "AUTO")),
      h("div", { class: "md-desc" }, "File: " + m.file),
      ...hfBlock(info),
      h("div", { class: "md-sec" }, "LOCAL BENCH — measured on this PC"), out,
      h("div", { class: "acts" },
        h('button', { class: 'sel', onclick: async () => { try { await ensureLoaded(m, out); await window.ForgeIntegrations.useLocal(L.st.server.alias); $('mdDetail')?.remove(); $('mdl').hidden = true; } catch (e) { out.textContent = errText(e); } } }, '▶ DIRECT LOCAL CHAT'),
        h("button", { class: "sel", onclick: () => loadIntoChat(m, out) }, running ? "▶ USE IN CHAT" : "▶ LOAD + USE IN CHAT"),
        h("button", { onclick: () => bench(m, out) }, "⚡ BENCH"),
        h("button", { onclick: () => $("mdDetail")?.remove() }, "CLOSE"))), from);
  }
  async function ensureLoaded(m, out) {
    if (L.st.server.ready && L.st.server.file === m.file) return;
    out.textContent = "loading into GPU/RAM… (big models take up to a minute)"; out.classList.add("busy");
    const t0 = Date.now();
    try { await api.localRun(m.file, L.ctx); }
    catch (e) { const log = await api.localLog().catch(() => ""); throw new Error(errText(e) + (log ? "\n\n-- server log --\n" + log.split("\n").slice(-12).join("\n") : "")); }
    finally { out.classList.remove("busy"); }
    out.textContent = `loaded in ${((Date.now() - t0) / 1000).toFixed(1)} s`;
    await refresh();
  }
  async function bench(m, out) {
    try {
      await ensureLoaded(m, out); out.textContent += " · benchmarking…";
      const b = await api.localBench("Write a JavaScript function that debounces another function. Code only.");
      out.textContent = `gen ${b.tps ? b.tps.toFixed(1) : "?"} tok/s · prompt ${b.ppTps ? Math.round(b.ppTps) : "?"} tok/s · ${b.tokens} tokens in ${(b.ms / 1000).toFixed(1)} s\n\n${(b.text || b.reasoning || "").slice(0, 600)}`;
    } catch (e) { out.textContent = "✗ " + errText(e); }
  }
  async function loadIntoChat(m, out) {
    try {
      await ensureLoaded(m, out);
      out.textContent += " · registering with MiniMax Code…";
      await api.localRegister(L.ctx);
      await new Promise((r) => setTimeout(r, 2500));
      if (engine !== "mcode") { $("engine").value = "mcode"; engine = "mcode"; }
      cur = null; await newSession();
      const opt = [...$("model").options].find((o) => /local-llama:|:local-/.test(o.value));
      if (!opt) throw new Error("registered, but MiniMax Code did not offer the model");
      await setModel(opt.value);
      $("mdDetail")?.remove(); $("mdl").hidden = true;
      toast("Chatting with local " + m.name);
    } catch (e) { out.textContent = "✗ " + errText(e); }
  }
  async function detailRepo(m, from, recKey) {
    const files = h("div", { class: "lc-files" }, h("div", { class: "note" }, "reading quantizations from Hugging Face…"));
    show(h("div", { class: "md-card", style: `--mh:${hue(m.id)}` },
      h("div", { class: "md-top" }, mono(m.id), h("div", {}, h("div", { class: "md-nm" }, m.name), h("div", { class: "md-id" }, m.id)), h("div", { class: "grow" }), fxRing(rate(m))),
      h("div", { class: "md-stats" }, stat("PARAMS", m.paramsB ? m.paramsB + "B" + (m.activeB ? " (MoE A" + m.activeB + "B)" : "") : "—"), stat("AUTHOR", m.author), stat("DOWNLOADS", fmtN(m.downloads)), stat("LIKES", fmtN(m.likes))),
      hfChips(m),
      h("div", { class: "md-sec" }, "PICK A QUANT — fit is an estimate for this PC"), files,
      h("div", { class: "acts" }, h("button", { onclick: () => $("mdDetail")?.remove() }, "CLOSE"))), from);
    try {
      const gs = await api.localFiles(m.id);
      if (!recKey) { const green = gs.filter((g) => g.fit.level === 'green'); const possible = green.length ? green : gs.filter((g) => g.fit.level !== 'red'); recKey = possible.slice().sort((a, b) => {
        const bits = (g) => /F16|BF16/.test(g.quant) ? 16 : +(g.quant.match(/(?:IQ|Q)(\d)/)?.[1] || (/MXFP4/.test(g.quant) ? 4 : 0)); return bits(b) - bits(a) || b.size - a.size;
      })[0]?.key; }
      const have = new Set((L.st.installed || []).map((x) => x.name.toLowerCase()));
      files.replaceChildren(...(gs.length ? gs.map((g) => {
        const done = have.has(g.key.split("/").pop().toLowerCase());
        const isRec = g.key === recKey;
        return h("div", { class: "lc-q fit-" + g.fit.level + (isRec ? " rec" : "") },
          h("b", {}, (isRec ? "★ " : "") + g.quant),
          h("span", {}, g.sizeGB + " GB" + (g.parts.length > 1 ? ` · ${g.parts.length} parts` : "")),
          h("span", { class: "fl" }, g.fit.label + (isRec ? "  · (recommended for your PC)" : "")),
          done ? h("span", { class: "chip in" }, "✓ installed")
            : h("button", { class: isRec ? "acc" : "", disabled: g.fit.level === "red", onclick: () => { if (!L.st.modelDir) return toast("Choose a model folder first (📁 choose)."); startDl(m.id, g); $("mdDetail")?.remove(); } }, "⬇ DOWNLOAD"));
      }) : [h("div", { class: "note" }, "No GGUF files in this repo.")]));
    } catch (e) { files.replaceChildren(h("div", { class: "note" }, "✗ " + errText(e))); }
  }
  // header MODELS button always opens on the cloud tab
  const prevOpen = $("mdlBtn").onclick;
  $("mdlBtn").onclick = async (e) => { setTab("cloud"); return prevOpen(e); };
  window.openLocalBay = () => { $("mdl").hidden = false; setTab("local"); };
})();
