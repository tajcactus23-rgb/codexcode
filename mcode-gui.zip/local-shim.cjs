// Local-model shim: sits between MiniMax Code and llama-server.
// llama.cpp compiles tool JSON-schemas into a grammar; large repetition limits (maxLength, maxItems, ...)
// make it fail with "failed to parse grammar". We drop those limits from tool schemas and forward everything else untouched.
const http = require("node:http");

// Constraint keywords dropped from schema nodes. Only schema keywords: a tool PARAMETER named "pattern" or "format"
// lives inside a `properties` map and must survive (stripping it made models omit required args).
const HEAVY = new Set(["maxLength", "minLength", "maxItems", "minItems", "pattern", "format", "maxProperties", "minProperties", "uniqueItems"]);
const MAP_KEYS = new Set(["properties", "patternProperties", "$defs", "definitions", "dependentSchemas"]); // values are name -> schema
function relax(node) {
  if (Array.isArray(node)) return node.map(relax);
  if (!node || typeof node !== "object") return node;
  const out = {};
  for (const [k, v] of Object.entries(node)) {
    if (HEAVY.has(k) && typeof v !== "object") continue;          // a keyword with a scalar value: drop it
    if (MAP_KEYS.has(k) && v && typeof v === "object" && !Array.isArray(v)) {
      out[k] = Object.fromEntries(Object.entries(v).map(([name, sub]) => [name, relax(sub)])); // keep every name
    } else out[k] = relax(v);
  }
  return out;
}
function sanitize(body) {
  if (!Array.isArray(body.tools)) return body;
  return { ...body, tools: body.tools.map((t) => (t?.function?.parameters ? { ...t, function: { ...t.function, parameters: relax(t.function.parameters) } } : t)) };
}

function startShim(listenPort, targetPort) {
  const srv = http.createServer((req, res) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", async () => {
      let body = Buffer.concat(chunks);
      if (body.length && /json/i.test(req.headers["content-type"] || "")) {
        try { body = Buffer.from(JSON.stringify(sanitize(JSON.parse(body.toString("utf8"))))); } catch {}
      }
      try {
        const up = await fetch(`http://127.0.0.1:${targetPort}${req.url}`, {
          method: req.method, body: ["GET", "HEAD"].includes(req.method) ? undefined : body,
          headers: { "content-type": req.headers["content-type"] || "application/json", accept: req.headers.accept || "*/*" },
        });
        res.writeHead(up.status, { "content-type": up.headers.get("content-type") || "application/json" });
        if (!up.body) return res.end();
        const reader = up.body.getReader();
        for (;;) { const { value, done } = await reader.read(); if (done) break; res.write(Buffer.from(value)); }
        res.end();
      } catch (e) {
        if (!res.headersSent) res.writeHead(502, { "content-type": "application/json" });
        res.end(JSON.stringify({ error: { message: "local model server unreachable: " + e.message } }));
      }
    });
  });
  srv.on("error", () => {}); // port already held by a previous shim from this app: that one serves
  srv.listen(listenPort, "127.0.0.1");
  return srv;
}
module.exports = { startShim, sanitize };
