# Forge development quality

Implement behavior in the actual Electron source. Preserve the established reactor, boids, fluid scenes, GUI Lab, local bay and existing provider integrations.

Conversations belong to Forge. Provider and model switches must preserve canonical history, bindings, attachments and workspace context. Never replace history with a provider-filtered list or clear a conversation on connection changes. Keep credentials out of renderer state and logs; use OS-encrypted references and providers' own subscription sign-ins.

Read the relevant source before editing. Keep work inside the assigned working copy and sibling free-proxy. Source staging is a working copy, not a security sandbox. Do not modify the running installation, account files, secrets, runtime caches or unrelated projects.

Run `npm test` and appropriate syntax checks. Add regression coverage for concrete bugs/behaviors. Do not weaken tests to pass, mirror implementation as an assertion, fabricate tool output or claim unexecuted model/hardware flows are verified. UI changes need browser verification, including empty, busy, failure and responsive states. Preserve existing motion; pause hidden rendering and maintain usable text contrast.

Report what changed, exact validation evidence and untested runtime dependencies. A reviewer must read the actual implementation and tests, check against the task and validation results, avoid editing during review, and finish with `FORGE_REVIEW: PASS` or `FORGE_REVIEW: FAIL`. PASS requires implementation and adequate evidence; syntax alone is insufficient. Never apply source directly: Forge's validation/review/hash gates own promotion and rollback.
