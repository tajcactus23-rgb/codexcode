// Local models: llama.cpp runtime install, live Hugging Face catalogue, resumable + hash-verified
// downloads, and the llama-server lifecycle. Everything is user-triggered from the Model Bay;
// downloads only ever come from github.com (llama.cpp releases) and huggingface.co.
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const crypto = require("node:crypto");
const { spawn, execFileSync } = require("node:child_process");

const UA = "bm23-coder-ide";
const PORT = 8089;
const SHIM_PORT = 8088; // MiniMax Code talks to the shim, which relaxes tool schemas for llama.cpp's grammar builder
const { startShim } = require("./local-shim.cjs");
let shim = null;
const HOST_OK = /(^|\.)(github\.com|githubusercontent\.com|huggingface\.co|hf\.co|xethub\.hf\.co)$/i;
const hostOk = (u) => { try { const x = new URL(u); return x.protocol === "https:" && HOST_OK.test(x.hostname); } catch { return false; } };

module.exports = function registerLocalModels({ app, dialog, ipcMain, getWin, send, getSettings, getHfToken, saveSettings, runMcode, restartMcode }) {
  if (!getSettings().modelDir) { const modelDir = path.join(app.getPath('userData'), 'models'); fs.mkdirSync(modelDir, { recursive: true }); saveSettings({ modelDir }); }
  const hfHeaders = () => { const token = getHfToken?.(); return { 'user-agent': UA, ...(token ? { authorization: `Bearer ${token}` } : {}) }; };
  const runtimeRoot = () => path.join(app.getPath("userData"), "llama-runtime");
  const runtimeFile = () => path.join(runtimeRoot(), "runtime.json");
  const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return null; } };
  const emit = (kind, data) => send("local:event", { kind, ...data });
  const sysTar = () => { const t = path.join(process.env.SystemRoot || "C:\\Windows", "System32", "tar.exe"); return fs.existsSync(t) ? t : null; };

  // ---------- hardware (measured, not assumed) ----------
  let hwCache;
  function hardware() {
    if (hwCache) return hwCache;
    let vramGB = 0, gpu = null, driver = null;
    try {
      const out = execFileSync("nvidia-smi", ["--query-gpu=name,memory.total,driver_version", "--format=csv,noheader,nounits"], { encoding: "utf8", windowsHide: true, timeout: 8000 });
      const [name, mib, drv] = out.trim().split(/\r?\n/)[0].split(",").map((s) => s.trim());
      gpu = name; vramGB = Math.round((Number(mib) / 1024) * 10) / 10; driver = drv;
    } catch {}
    hwCache = { gpu, vramGB, driver, ramGB: Math.round((os.totalmem() / 1073741824) * 10) / 10 };
    return hwCache;
  }
  function freeGB(dir) {
    try { const s = fs.statfsSync(dir); return Math.round((s.bavail * s.bsize) / 1073741824 * 10) / 10; } catch { return null; }
  }

  // ---------- downloads: Range-resume, throttled progress, sha256 verify ----------
  const jobs = new Map();
  let jobSeq = 1;
  async function sha256File(file, onPct) {
    const total = fs.statSync(file).size; let done = 0;
    const hash = crypto.createHash("sha256");
    await new Promise((res, rej) => {
      const s = fs.createReadStream(file, { highWaterMark: 4 << 20 });
      s.on("data", (b) => { hash.update(b); done += b.length; onPct?.(done / total); });
      s.on("end", res); s.on("error", rej);
    });
    return hash.digest("hex");
  }
  async function download(url, dest, { signal, sha256, onProgress, onPhase }) {
    if (!hostOk(url)) throw new Error("download blocked: host not allowed");
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    // a finished file only exists after the size + sha256 checks below passed, so resuming a split model skips it
    if (fs.existsSync(dest)) { const sz = fs.statSync(dest).size; onProgress?.({ done: sz, total: sz, bps: 0, eta: 0 }); return; }
    const part = dest + ".part";
    let have = fs.existsSync(part) ? fs.statSync(part).size : 0;
    const res = await fetch(url, { headers: { ...(new URL(url).hostname === "huggingface.co" ? hfHeaders() : { "user-agent": UA }), ...(have ? { Range: `bytes=${have}-` } : {}) }, signal, redirect: "follow" });
    if (!hostOk(res.url)) throw new Error("download blocked: redirected to a disallowed host");
    if (res.status === 416) { have = 0; fs.rmSync(part, { force: true }); return download(url, dest, { signal, sha256, onProgress, onPhase }); }
    if (!res.ok) throw new Error("HTTP " + res.status + (res.status === 401 || res.status === 403 ? " (gated or private repo)" : ""));
    if (res.status === 200 && have) { fs.rmSync(part, { force: true }); have = 0; }
    const total = have + Number(res.headers.get("content-length") || 0);
    const out = fs.createWriteStream(part, { flags: have ? "a" : "w" });
    const reader = res.body.getReader();
    let done = have, lastT = Date.now(), lastB = done, bps = 0;
    try {
      for (;;) {
        const { value, done: fin } = await reader.read();
        if (fin) break;
        if (!out.write(value)) await new Promise((r) => out.once("drain", r));
        done += value.length;
        const now = Date.now();
        if (now - lastT >= 250) {
          const inst = ((done - lastB) / (now - lastT)) * 1000;
          bps = bps ? bps * 0.7 + inst * 0.3 : inst;
          lastT = now; lastB = done;
          onProgress?.({ done, total, bps, eta: bps > 0 && total ? (total - done) / bps : null });
        }
      }
    } finally { await new Promise((r) => out.end(r)); }
    if (total && fs.statSync(part).size !== total) throw new Error("incomplete download (connection dropped) — press resume");
    if (sha256) {
      onPhase?.("verify");
      const got = await sha256File(part, (p) => onProgress?.({ done: total, total, verifyPct: p, bps: 0, eta: null }));
      if (got !== sha256.toLowerCase()) { fs.rmSync(part, { force: true }); throw new Error("hash mismatch — file corrupted, deleted. Retry."); }
    }
    fs.renameSync(part, dest);
    return dest;
  }
  function startJob(meta, worker) {
    const id = jobSeq++, ctl = new AbortController();
    const job = { id, ctl, meta, state: "running" };
    jobs.set(id, job);
    emit("job", { id, state: "running", meta });
    (async () => {
      try {
        await worker({ id, signal: ctl.signal, onProgress: (p) => emit("progress", { id, ...p }), onPhase: (phase) => emit("phase", { id, phase }) });
        job.state = "done"; emit("job", { id, state: "done", meta });
      } catch (e) {
        job.state = ctl.signal.aborted ? (job.cancel ? "cancelled" : "paused") : "error";
        emit("job", { id, state: job.state, meta, error: ctl.signal.aborted ? null : e.message });
      }
    })();
    return id;
  }

  // ---------- runtime (llama.cpp) ----------
  // Reuse an existing llama.cpp when present (read-only; we never modify another app's files).
  function lemonadeRuntime() {
    const base = path.join(os.homedir(), ".cache", "lemonade", "bin", "llamacpp");
    const hw = hardware();
    for (const variant of hw.gpu ? ["cuda", "vulkan", "cpu"] : ["vulkan", "cpu"]) {
      const server = path.join(base, variant, "llama-server.exe");
      if (fs.existsSync(server)) {
        // version.txt is optional in some Lemonade builds; a missing one must not break runtime detection (local:state, runServer)
        let tag = "unknown";
        try { tag = (fs.readFileSync(path.join(base, variant, "version.txt"), "utf8").split(/\r?\n/)[0] || "").trim() || "unknown"; } catch {}
        return { source: "lemonade", tag, variant, server };
      }
    }
    return null;
  }
  function runtimeInfo() {
    const own = readJson(runtimeFile());
    if (own && fs.existsSync(own.server)) return { source: "own", ...own };
    // Standalone by default: the IDE runs its own llama.cpp. Another app's runtime is only reused when the user opts in.
    return getSettings().useExternalRuntime === true ? lemonadeRuntime() : null;
  }
  let autoInstall = null;
  async function installRuntime() {
    const hw = hardware(), tar = sysTar();
    if (!tar) throw new Error("Windows tar.exe not found (needed to unpack the runtime)");
    const rels = await (await fetch("https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=15", { headers: { "user-agent": UA, accept: "application/vnd.github+json" } })).json();
    if (!Array.isArray(rels)) throw new Error("could not read llama.cpp releases");
    const variant = hw.gpu ? "cuda-12.4" : "vulkan"; // 12.4 runs on any driver >=551; CUDA 13.x needs a much newer driver
    const binRe = new RegExp(`^llama-b\\d+-bin-win-${variant.replace(/\./g, "\\.")}-x64\\.zip$`);
    const rel = rels.find((r) => /^b\d+$/.test(r.tag_name) && r.assets.some((a) => binRe.test(a.name)));
    if (!rel) throw new Error("no matching llama.cpp Windows build found in recent releases");
    const bin = rel.assets.find((a) => binRe.test(a.name));
    const rt = variant.startsWith("cuda") ? rel.assets.find((a) => a.name === `cudart-llama-bin-win-${variant}-x64.zip`) : null;
    const dir = path.join(runtimeRoot(), rel.tag_name);
    fs.mkdirSync(dir, { recursive: true });
    const id = startJob({ type: "runtime", title: `llama.cpp ${rel.tag_name} (${variant})`, totalBytes: bin.size + (rt?.size || 0) }, async ({ signal, onProgress, onPhase }) => {
      const steps = [bin, rt].filter(Boolean);
      let base = 0;
      const grand = steps.reduce((s, a) => s + a.size, 0);
      for (const a of steps) {
        const zip = path.join(dir, a.name);
        await download(a.browser_download_url, zip, { signal, sha256: a.digest?.startsWith("sha256:") ? a.digest.slice(7) : null, onPhase,
          onProgress: (p) => onProgress({ ...p, done: base + (p.done || 0), total: grand }) });
        onPhase("unpack");
        execFileSync(tar, ["-xf", zip, "-C", dir], { windowsHide: true });
        fs.rmSync(zip, { force: true });
        base += a.size;
      }
      const server = (function find(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isFile() && e.name.toLowerCase() === "llama-server.exe") return p; if (e.isDirectory()) { const f = find(p); if (f) return f; } } return null; })(dir);
      if (!server) throw new Error("llama-server.exe not found after unpack");
      const version = execFileSync(server, ["--version"], { encoding: "utf8", windowsHide: true, timeout: 30000, stdio: ["ignore", "pipe", "pipe"] }).toString().trim();
      fs.writeFileSync(runtimeFile(), JSON.stringify({ tag: rel.tag_name, variant, server, version: version.slice(0, 200) }, null, 2));
    });
    return id;
  }

  // ---------- catalogue: live from Hugging Face ----------
  const FAMILIES = [
    { cat: "visuals", q: ["uigen", "webgen", "frontend coder", "webdev", "threejs", "web-ui", "react coder", "tesslate"] },
    { cat: "coder", q: ["qwen3-coder", "qwen2.5-coder", "devstral", "deepseek-coder", "codestral", "opencoder", "glm coder"] },
    { cat: "uncensored-coder", q: ["coder abliterated", "coder uncensored", "coder heretic", "coder dolphin"] },
    { cat: "agent", q: ["gpt-oss", "qwen3", "glm", "mistral-small", "gemma", "llama-3", "phi"] },
    { cat: "hermes", q: ["hermes"] },
    { cat: "uncensored", q: ["uncensored", "abliterated", "dolphin", "heretic"] },
  ];
  // image/audio/video generators, encoders, embedders: not chat/coding models
  const NON_CHAT_REPO = /image-|-image|diffusion|flux|sdxl|text-encoder|vae|whisper|tts|kokoro|wan2|video|embed|rerank|ace-?step|mmproj|clip/i;
  const UNCENSORED = /uncensored|abliterat|heretic|dolphin|lorablated|unfiltered|decensor/i;
  const parseParams = (id) => { const m = id.match(/(\d+(?:\.\d+)?)\s*[bB](?![a-zA-Z])/); return m ? Number(m[1]) : null; };
  const parseActive = (id) => { const m = id.match(/[-_ ]A(\d+(?:\.\d+)?)B/i); return m ? Number(m[1]) : null; };
  let catCache = { t: 0, items: null };
  async function hf(pathq) {
    const r = await fetch("https://huggingface.co" + pathq, { headers: hfHeaders(), signal: AbortSignal.timeout(30000) });
    if (!r.ok) throw new Error("Hugging Face HTTP " + r.status);
    return r.json();
  }
  async function catalog(force) {
    if (!force && catCache.items && Date.now() - catCache.t < 30 * 60 * 1000) return catCache.items;
    const seen = new Map();
    await Promise.all(FAMILIES.flatMap((f) => f.q.map(async (q) => {
      try {
        const list = await hf(`/api/models?search=${encodeURIComponent(q)}&filter=gguf&sort=downloads&direction=-1&limit=12`);
        for (const m of list) {
          if ((m.downloads || 0) < 800) continue; // drop the long tail of sub-par / abandoned uploads
          if (NON_CHAT_REPO.test(m.id) || (m.pipeline_tag && !/text-generation|image-text-to-text|conversational/.test(m.pipeline_tag))) continue;
          const prev = seen.get(m.id);
          if (prev) { if (!prev.cats.includes(f.cat)) prev.cats.push(f.cat); continue; }
          seen.set(m.id, { id: m.id, author: m.id.split("/")[0], name: m.id.split("/")[1], downloads: m.downloads || 0, likes: m.likes || 0, updated: m.lastModified || m.createdAt || null,
            tags: m.tags || [], cats: [f.cat], uncensored: UNCENSORED.test(m.id), hermes: /hermes/i.test(m.id), paramsB: parseParams(m.id), activeB: parseActive(m.id),
            license: (m.tags || []).find((t) => t.startsWith("license:"))?.slice(8) || null });
        }
      } catch {}
    })));
    const VIS = /uigen|webgen|frontend|webdev|three|web-?ui|react|tesslate|svelte|tailwind/i, COD = /coder|code|devstral|codestral/i;
    const items = [...seen.values()].map((m) => {
      if (m.uncensored && !m.cats.includes("uncensored")) m.cats.push("uncensored");
      if (VIS.test(m.id) && !m.cats.includes("visuals")) m.cats.push("visuals");
      if (m.uncensored && COD.test(m.id) && !m.cats.includes("uncensored-coder")) m.cats.push("uncensored-coder");
      m.rating = Math.round(Math.log10(1 + m.downloads) * 10 + Math.log10(1 + m.likes) * 15); // HF popularity score
      return m; }).sort((a, b) => b.downloads - a.downloads);
    catCache = { t: Date.now(), items };
    return items;
  }
  ipcMain.handle('local:search', async (_e, query = {}) => {
    const params = new URLSearchParams({ search: String(query.search || '').slice(0, 120), filter: 'gguf', sort: query.sort === 'recent' ? 'lastModified' : 'downloads', direction: '-1', limit: '100' });
    if (['unsloth', 'DavidAU', 'HauhauCS', 'bartowski', 'mradermacher', 'NousResearch'].includes(query.source)) params.set('author', query.source);
    if (query.source === 'uncensored' && !query.search) params.set('search', 'uncensored');
    if (query.author) params.set('author', String(query.author).slice(0, 80));
    const result = await hf('/api/models?' + params);
    return result.filter((m) => !NON_CHAT_REPO.test(m.id)).map((m) => ({ id: m.id, name: m.id.split('/')[1], author: m.id.split('/')[0], downloads: m.downloads || 0, likes: m.likes || 0,
      updated: m.lastModified || m.createdAt || null, tags: m.tags || [], cats: ['library', ...(/code|coder|devstral/i.test(m.id) ? ['coder'] : []), ...(/hermes/i.test(m.id) ? ['hermes'] : [])],
      hermes: /hermes/i.test(m.id), uncensored: UNCENSORED.test(m.id), paramsB: parseParams(m.id), activeB: parseActive(m.id), license: (m.tags || []).find((x) => x.startsWith('license:'))?.slice(8),
      rating: Math.round(Math.log10(1 + (m.downloads || 0)) * 10 + Math.log10(1 + (m.likes || 0)) * 15) }));
  });
  // per-quant fit for THIS machine: an estimate, labelled as such in the UI
  function fitFor(sizeGB, model) {
    const hw = hardware(), kv = Math.max(2, +(getSettings().localRuntime?.reserveGB || 2));
    if (hw.vramGB && sizeGB + kv <= hw.vramGB) return { level: "green", label: "fits in GPU — estimate" };
    if (sizeGB <= hw.ramGB * 0.62) return { level: "orange", label: model?.activeB && model.activeB <= 8 ? "spills to RAM — MoE, usable speed" : "spills to RAM — dense, slow" };
    return { level: "red", label: "too big for this PC" };
  }
  const treeCache = new Map(); // repo -> { t, tree }
  async function files(repo) {
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw new Error("bad repo id");
    let c = treeCache.get(repo);
    if (!c || Date.now() - c.t > 3600000) {
      const tree = []; let next = `https://huggingface.co/api/models/${repo}/tree/main?recursive=true&limit=100`;
      for (let page = 0; next && page < 100; page++) {
        const url = new URL(next); if (url.origin !== 'https://huggingface.co' || !url.pathname.startsWith(`/api/models/${repo}/tree/`)) throw new Error('Unexpected model tree pagination URL.');
        const r = await fetch(next, { headers: hfHeaders(), signal: AbortSignal.timeout(30000) }); if (!r.ok) throw new Error('Model files HTTP ' + r.status);
        tree.push(...await r.json()); next = r.headers.get('link')?.match(/<([^>]+)>;\s*rel="next"/)?.[1] || null;
      }
      if (next) throw new Error('Model repository has too many files; choose a narrower repository.');
      c = { t: Date.now(), tree }; treeCache.set(repo, c);
    }
    const tree = c.tree;
    const info = (await catalog()).find((m) => m.id === repo);
    // only main weights: drop vision projectors and speculative-decoding helpers (draft-*, mtp-*, MTP/ folders, eagle*),
    // but keep "noMTP" variants, which are full models
    const HELPER = /(^|[\/_.-])(mmproj|draft|mtp|eagle\d*|vision|projector)([\/_.-]|$)/i;
    const gg = tree.filter((f) => f.type === "file" && /\.gguf$/i.test(f.path) && !HELPER.test(f.path));
    const groups = new Map();
    for (const f of gg) {
      const split = f.path.match(/^(.*?)-0*(\d+)-of-0*(\d+)\.gguf$/i);
      const key = split ? split[1] : f.path.replace(/\.gguf$/i, "");
      const g = groups.get(key) || { key, parts: [], size: 0 };
      g.parts.push({ path: f.path, size: f.size, sha256: f.lfs?.oid || null }); g.size += f.size; groups.set(key, g);
    }
    const quant = (k) => (k.match(/(IQ\d[_A-Z0-9]*|Q\d[_A-Z0-9]*|MXFP4|BF16|F16|F32)/i) || [])[0] || "?";
    return [...groups.values()].sort((a, b) => a.size - b.size).map((g) => ({ ...g, quant: quant(g.key), sizeGB: Math.round((g.size / 1073741824) * 100) / 100, fit: fitFor(g.size / 1073741824, info) }));
  }

  // quant quality: bits, plus a little for K_M/K_L/XL mixes. <4 bits is weak for coding (tested: the IQ2 Qwen ignores instructions).
  function quantRank(q) {
    const u = String(q || "").toUpperCase();
    if (/^(BF16|F16|F32)/.test(u)) return 9;
    if (/MXFP4/.test(u)) return 4.2; // gpt-oss native 4-bit format
    const m = u.match(/^(IQ|Q)(\d)/); if (!m) return 0;
    return +m[2] + (/_K_(M|L|XL)|_XL/.test(u) ? 0.3 : 0) + (u.startsWith("IQ") ? 0.1 : 0);
  }
  // Recommended for THIS PC: per repo, the best quant that fits fully in VRAM (or, for MoE, spills to RAM at usable speed),
  // never below 4-bit, ranked by fit + quant quality + coding focus + HF rating.
  async function recommend(force) {
    const cat = await catalog(force);
    const wanted = ["coder", "uncensored-coder", "visuals", "agent", "hermes"];
    const cands = cat.filter((m) => m.cats.some((c) => wanted.includes(c))).sort((a, b) => b.rating - a.rating).slice(0, 28);
    const out = [];
    let i = 0;
    await Promise.all(Array.from({ length: 4 }, async () => {
      while (i < cands.length) {
        const m = cands[i++];
        let gs; try { gs = await files(m.id); } catch { continue; }
        const moe = !!(m.activeB && m.activeB <= 8);
        // size sanity: a real N-billion-param model at b bits is ~N*b/8 GB; anything far smaller is a helper we missed
        const sane = (g) => !m.paramsB || g.size / 1073741824 >= m.paramsB * Math.min(quantRank(g.quant), 8) / 8 * 0.6;
        const good = gs.filter((g) => quantRank(g.quant) >= 4 && quantRank(g.quant) < 9 && sane(g));
        const green = good.filter((g) => g.fit.level === "green");
        const pool = green.length ? green : good.filter((g) => g.fit.level === "orange" && moe);
        if (!pool.length) continue;
        const best = pool.sort((a, b) => quantRank(b.quant) - quantRank(a.quant) || b.size - a.size)[0];
        const score = m.rating + (best.fit.level === "green" ? 30 : 14) + Math.min(quantRank(best.quant), 8) * 3
          + (m.cats.includes("coder") ? 20 : 0) + (m.cats.includes("uncensored-coder") ? 15 : 0) + (m.cats.includes("visuals") ? 15 : 0);
        const why = best.fit.level === "green" ? `${best.quant} fits fully in your ${hardware().vramGB} GB GPU` : `MoE (${m.activeB}B active): spills to RAM, still usable speed`;
        out.push({ id: m.id, score: Math.round(score), why, pick: { key: best.key, quant: best.quant, sizeGB: best.sizeGB, fit: best.fit, parts: best.parts, size: best.size } });
      }
    }));
    return out.sort((a, b) => b.score - a.score).slice(0, 12);
  }

  // ---------- installed models + server ----------
  // Not chat models: audio/music/TTS parts, speculative-decoding drafts, vision projectors, embeddings.
  const NOT_CHAT = /acestep|ace-step|thinksound|eagle3|mmproj|(^|[-_])(vae|dit|t5|metaclip|clip)[-_.]|whisper|kokoro|embed|rerank|bge-|nomic-embed/i;
  const gb = (n) => Math.round((n / 1073741824) * 100) / 100;
  function installed() {
    const out = [], seen = new Set();
    const push = (file, name, source, deletable, repo) => {
      let real = file; try { real = fs.realpathSync(file); } catch {}
      if (seen.has(real.toLowerCase())) return; seen.add(real.toLowerCase());
      if (NOT_CHAT.test(name) || NOT_CHAT.test(repo || "")) return;
      let size = 0; try { size = fs.statSync(file).size; } catch {}
      if (size < 50 * 1048576) return;
      const quant = (name.match(/(IQ\d[_A-Z0-9]*|Q\d[_A-Z0-9]*|MXFP4|BF16|F16)/i) || [])[0] || null;
      out.push({ file, name, repo: repo || null, source, deletable, sizeGB: gb(size), quant, weak: quant ? quantRank(quant) > 0 && quantRank(quant) < 4 : false,
        bench: (getSettings().localBench || {})[file] || null });
    };
    const dir = getSettings().modelDir;
    if (dir && fs.existsSync(dir)) (function walk(d, depth) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory() && depth < 3) walk(p, depth + 1);
        else if (e.isFile() && /\.gguf$/i.test(e.name)) push(p, e.name.replace(/\.gguf$/i, ""), "your folder", true, null);
      }
    })(dir, 0);
    // Hugging Face cache (used by Lemonade and others): hub/models--org--name/snapshots/<rev>/*.gguf
    const hub = path.join(os.homedir(), ".cache", "huggingface", "hub");
    try {
      for (const m of fs.readdirSync(hub, { withFileTypes: true })) {
        if (!m.isDirectory() || !m.name.startsWith("models--")) continue;
        const repo = m.name.slice(8).replace("--", "/"), snaps = path.join(hub, m.name, "snapshots");
        if (!fs.existsSync(snaps)) continue;
        for (const rev of fs.readdirSync(snaps)) for (const f of fs.readdirSync(path.join(snaps, rev)))
          if (/\.gguf$/i.test(f)) push(path.join(snaps, rev, f), f.replace(/\.gguf$/i, ""), "HF cache", false, repo);
      }
    } catch {}
    // LM Studio library
    const lms = path.join(os.homedir(), ".lmstudio", "models");
    if (fs.existsSync(lms)) (function walk(d, depth) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory() && depth < 4) walk(p, depth + 1);
        else if (e.isFile() && /\.gguf$/i.test(e.name)) push(p, e.name.replace(/\.gguf$/i, ""), "LM Studio", false, null);
      }
    })(lms, 0);
    return out.sort((a, b) => b.sizeGB - a.sizeGB);
  }
  // ---------- server lifecycle (hardened) ----------
  let server = null;
  const pidFile = () => path.join(app.getPath("userData"), "llama-server.pid");
  const logFile = () => path.join(app.getPath("userData"), "llama-server.log");
  const sh = (cmd, args) => { try { return execFileSync(cmd, args, { encoding: "utf8", windowsHide: true, timeout: 8000 }); } catch { return ""; } };
  const imageOf = (pid) => (sh("tasklist", ["/FI", `PID eq ${pid}`, "/FO", "CSV", "/NH"]).split(",")[0] || "").replace(/"/g, "").trim().toLowerCase();
  function killPid(pid) { if (pid && imageOf(pid) === "llama-server.exe") { sh("taskkill", ["/PID", String(pid), "/F"]); return true; } return false; }
  // A crashed app or killed test can leave llama-server running with a model in VRAM; it silently starves the next load.
  function killOrphans() {
    const killed = [];
    try { const pid = +fs.readFileSync(pidFile(), "utf8"); if (pid && pid !== server?.child.pid && killPid(pid)) killed.push(pid); } catch {}
    for (const line of sh("netstat", ["-ano", "-p", "tcp"]).split(/\r?\n/)) {
      const m = line.match(/127\.0\.0\.1:(\d+)\s+\S+\s+LISTENING\s+(\d+)/);
      if (!m || +m[1] !== PORT) continue;
      const pid = +m[2]; if (pid !== server?.child.pid && killPid(pid)) killed.push(pid);
    }
    try { fs.rmSync(pidFile(), { force: true }); } catch {}
    return killed;
  }
  function gpuNow() {
    const row = sh("nvidia-smi", ["--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"]).trim().split(/\r?\n/)[0];
    if (!row) return null;
    const [used, total] = row.split(",").map((x) => +x.trim());
    const apps = sh("nvidia-smi", ["--query-compute-apps=pid,process_name", "--format=csv,noheader"]).split(/\r?\n/).filter(Boolean)
      .map((l) => { const [pid, name] = l.split(",").map((x) => x.trim()); return { pid: +pid, name: path.basename(name || "") }; })
      .filter((a) => a.pid && a.pid !== server?.child.pid);
    return { usedGB: +(used / 1024).toFixed(1), totalGB: +(total / 1024).toFixed(1), freeGB: +((total - used) / 1024).toFixed(1), apps };
  }
  const helpCache = new Map();
  function supports(bin, flag) {
    if (!helpCache.has(bin)) {
      let t = "";
      try { t = execFileSync(bin, ["--help"], { encoding: "utf8", windowsHide: true, timeout: 20000, stdio: ["ignore", "pipe", "pipe"] }); }
      catch (e) { t = String(e.stdout || "") + String(e.stderr || ""); }
      helpCache.set(bin, t);
    }
    return helpCache.get(bin).includes(flag);
  }
  function explain(log) {
    const t = log.join("\n");
    if (/address already in use|bind.*fail|couldn't bind|failed to listen/i.test(t)) return `port ${PORT} is busy: another program is using it`;
    if (/out of memory|failed to allocate|cudaMalloc failed|OutOfDeviceMemory|unable to allocate/i.test(t)) return "not enough GPU/system memory for this model at this context: try a smaller context or a smaller quant";
    if (/unknown model architecture|unknown architecture|unsupported model/i.test(t)) return "this llama.cpp build is too old for this model's architecture";
    if (/unknown argument|invalid argument|unrecognized (option|argument)|error while handling argument/i.test(t)) return "this llama.cpp build rejected a launch flag: update the runtime from the LOCAL tab (⬇ install)";
    return log.slice(-4).join(" | ") || "no output from llama-server";
  }
  const serverState = () => ({ running: !!server, ready: !!server?.ready, file: server?.file || null, alias: server?.alias || null, port: PORT, log: server?.log?.slice(-6) || [] });
  function stopServer() { if (server) { try { server.child.kill(); } catch {} server = null; } try { fs.rmSync(pidFile(), { force: true }); } catch {} emit("server", serverState()); }
  async function runServer({ file, ctx }) {
    const rt = runtimeInfo();
    if (!rt) {
      // first use: fetch the built-in runtime automatically (one-time download, progress shows in MODELS > LOCAL)
      if (!autoInstall) autoInstall = installRuntime().catch((e) => { autoInstall = null; throw e; });
      await autoInstall;
      throw new Error("installing the built-in llama.cpp runtime (one-time download, see MODELS > LOCAL) — load the model again when it finishes");
    }
    if (!file || !fs.existsSync(file)) throw new Error("model file missing: " + file);
    stopServer();
    const orphans = killOrphans();
    // auto context per model: fully-in-VRAM models get 64K; models that spill to RAM get 32K (measured: gpt-oss-20b on 8 GB
    // drops from ~21 to ~1 tok/s at 64K because the bigger KV cache pushes layers off the GPU)
    const lc = getSettings().localRuntime || {};
    ctx = ctx || lc.context;
    if (!ctx) { const gb = fs.statSync(file).size / 1073741824, vram = hardware().vramGB || 0; ctx = gb + 2 <= vram ? 65536 : 32768; }
    const alias = "local-" + path.basename(file).replace(/\.gguf$/i, "").replace(/[^A-Za-z0-9._-]+/g, "-").slice(0, 60);
    // -np 1: one slot owns the whole context and keeps the agent's long system prompt cached between turns.
    // --fit sizes GPU layers / MoE experts to free VRAM; q8 KV + flash-attn measured 1.4 -> 20.9 tok/s at 32k on the RTX 4060.
    const args = ["-m", file, "--host", "127.0.0.1", "--port", String(PORT), "-c", String(ctx), "-np", "1", "-a", alias,
      "-ctk", ['f16', 'q8_0', 'q4_0'].includes(lc.cacheType) ? lc.cacheType : 'q8_0', "-ctv", ['f16', 'q8_0', 'q4_0'].includes(lc.cacheType) ? lc.cacheType : 'q8_0'];
    if (lc.threads > 0) args.push('-t', String(Math.max(1, Math.min(256, Math.trunc(lc.threads)))));
    args.push('-b', String(Math.max(32, Math.min(4096, lc.batch || 512))), '-ub', String(Math.max(32, Math.min(2048, lc.ubatch || 128))));
    // Newer-build flags are feature-checked: older llama.cpp builds (e.g. some Lemonade ones) exit on unknown arguments.
    if (lc.gpuLayers >= 0) args.push("-ngl", String(Math.trunc(lc.gpuLayers)));
    else if (supports(rt.server, "--fit")) args.push("--fit", "on", "-fitt", "768");
    else args.push("-ngl", "99");                                   // old builds: offload what fits, the classic way
    const help = helpCache.get(rt.server) || "";
    if (lc.flashAttention !== false && /flash-attn[^\n]*(on\|off|\[on|<on)/i.test(help)) args.push("-fa", "on");   // value form: -fa on|off|auto
    else if (lc.flashAttention !== false && help.includes("--flash-attn")) args.push("-fa");                        // legacy boolean form
    if (supports(rt.server, "--reasoning-budget")) args.push("--reasoning-budget", String(lc.reasoningBudget ?? 2048)); // thinking models always reach an answer
    const logStream = fs.createWriteStream(logFile(), { flags: "w" });
    logStream.write(`# ${new Date().toISOString()}  ${rt.server}  ${args.join(" ")}\n`);
    const child = spawn(rt.server, args, { cwd: path.dirname(rt.server), windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    try { fs.writeFileSync(pidFile(), String(child.pid)); } catch {}
    const s = server = { child, file, alias, ctx, ready: false, log: [], args };
    const onLog = (b) => { const txt = b.toString(); logStream.write(txt); for (const l of txt.split(/\r?\n/).filter(Boolean)) { s.log.push(l.slice(0, 300)); if (s.log.length > 200) s.log.shift(); } };
    child.stdout.on("data", onLog); child.stderr.on("data", onLog);
    child.on("error", (e) => s.log.push("spawn error: " + e.message));
    child.on("exit", (code) => {
      logStream.end();
      if (server === s) { server = null; try { fs.rmSync(pidFile(), { force: true }); } catch {} emit("server", { ...serverState(), exited: code, tail: s.log.slice(-5), reason: explain(s.log) }); }
    });
    const t0 = Date.now();
    while (Date.now() - t0 < 240000) {
      if (server !== s) throw new Error("llama-server stopped while loading: " + explain(s.log));
      try { const r = await fetch(`http://127.0.0.1:${PORT}/health`); if (r.ok) { s.ready = true; break; } } catch {}
      await new Promise((r) => setTimeout(r, 800));
    }
    if (!s.ready) { stopServer(); throw new Error("llama-server did not become ready in 4 minutes: " + explain(s.log)); }
    saveSettings({ localLast: { file, ctx, alias } });
    emit("server", serverState());
    return { alias, port: PORT, orphans, gpu: gpuNow() };
  }
  app.on("before-quit", () => { try { server?.child.kill(); } catch {} try { fs.rmSync(pidFile(), { force: true }); } catch {} });
  // clean up leftovers from a previous crash, and keep the shim up so a registered local model never points at a dead port
  try { const k = killOrphans(); if (k.length) console.log("[local] killed orphan llama-server", k.join(",")); } catch {}
  if (!shim) shim = startShim(SHIM_PORT, PORT);

  // ---------- IPC ----------
  ipcMain.handle("local:state", () => {
    const st = getSettings();
    return { modelDir: st.modelDir || null, freeGB: st.modelDir ? freeGB(st.modelDir) : null, hw: hardware(), gpu: gpuNow(), runtime: runtimeInfo(), installed: installed(), server: serverState(), last: st.localLast || null, partials: partials(),
      jobs: [...jobs.values()].map((j) => ({ id: j.id, state: j.state, meta: j.meta })) };
  });
  ipcMain.handle("local:pickDir", async () => {
    const r = await dialog.showOpenDialog(getWin(), { title: "Where should downloaded models live?", properties: ["openDirectory", "createDirectory"] });
    if (r.canceled || !r.filePaths[0]) return null;
    saveSettings({ modelDir: r.filePaths[0] });
    return r.filePaths[0];
  });
  ipcMain.handle("local:runtimeInstall", () => installRuntime());
  // downloads that were started but not finished (app closed / paused / failed): resumable from the .part files
  function partials() {
    const pend = getSettings().localPending || {}, dir = getSettings().modelDir;
    return Object.entries(pend).map(([repo, g]) => {
      const target = dir ? path.join(dir, repo.replace("/", "__")) : null;
      let have = 0;
      for (const p of g.parts || []) for (const f of [path.basename(p.path), path.basename(p.path) + ".part"]) { try { have += fs.statSync(path.join(target, f)).size; } catch {} }
      return { repo, group: g, haveGB: gb(have), totalGB: gb(g.size), pct: g.size ? Math.round((have / g.size) * 100) : 0, running: [...jobs.values()].some((j) => j.state === "running" && j.meta.repo === repo) };
    });
  }
  const setPending = (repo, g) => { const p = { ...(getSettings().localPending || {}) }; if (g) p[repo] = g; else delete p[repo]; saveSettings({ localPending: p }); };
  ipcMain.handle("local:catalog", (_e, force) => catalog(force));
  ipcMain.handle("local:recommend", (_e, force) => recommend(force));
  ipcMain.handle("local:files", (_e, repo) => files(repo));
  ipcMain.handle("local:download", (_e, repo, group) => {
    const dir = getSettings().modelDir;
    if (!dir) throw new Error("pick a model folder first");
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw new Error("bad repo id");
    if (!group || !Array.isArray(group.parts) || !group.parts.length || group.parts.some((p) => !p.path || p.path.split('/').some((x) => x === '..' || x === '.') || !/\.gguf$/i.test(p.path))) throw new Error('Invalid model download group.');
    const free = freeGB(dir), needGB = group.size / 1073741824;
    if (free != null && needGB + 1 > free) throw new Error(`not enough disk space: need ${needGB.toFixed(1)} GB, ${free} GB free`);
    const target = path.join(dir, repo.replace("/", "__"));
    setPending(repo, { key: group.key, size: group.size, parts: group.parts });
    return startJob({ type: "model", title: group.key.split("/").pop(), repo, totalBytes: group.size }, async ({ signal, onProgress, onPhase }) => {
      let base = 0;
      for (const part of group.parts) {
        await download(`https://huggingface.co/${repo}/resolve/main/${part.path.split("/").map(encodeURIComponent).join("/")}`, path.join(target, ...part.path.split("/")),
          { signal, sha256: part.sha256, onPhase, onProgress: (p) => onProgress({ ...p, done: base + (p.done || 0), total: group.size }) });
        base += part.size;
      }
      setPending(repo, null);   // complete: no longer a partial
    });
  });
  ipcMain.handle("local:jobAction", (_e, id, action) => {
    const j = jobs.get(id); if (!j) return false;
    if (action === "pause" || action === "cancel") { j.cancel = action === "cancel"; j.ctl.abort(); }
    return true;
  });
  ipcMain.handle("local:delete", (_e, file) => {
    const dir = getSettings().modelDir;
    if (!dir || !path.resolve(file).toLowerCase().startsWith(path.resolve(dir).toLowerCase() + path.sep) || !/\.gguf(\.part)?$/i.test(file)) throw new Error("refusing to delete outside the model folder");
    fs.rmSync(file, { force: true }); return true;
  });
  ipcMain.handle("local:run", (_e, file, ctx) => runServer({ file, ctx }));
  ipcMain.handle("local:stop", () => { stopServer(); return true; });
  ipcMain.handle("local:ensure", async () => {
    if (server?.ready) return { ready: true, alias: server.alias, started: false };
    const last = getSettings().localLast;
    if (!last?.file || !fs.existsSync(last.file)) throw new Error("no local model loaded: open MODELS > LOCAL and load one");
    const r = await runServer({ file: last.file, ctx: last.ctx });
    return { ready: true, alias: r.alias, started: true, gpu: r.gpu };
  });
  ipcMain.handle("local:log", () => { try { return fs.readFileSync(logFile(), "utf8").slice(-6000); } catch { return ""; } });
  // MiniMax Code's built-in models declare capabilities.max_request_body_bytes (64 MiB); custom providers get none.
  // Without it, context compaction's admission check demands the summary be smaller than the original history,
  // which a short chat can never satisfy -> "Generated checkpoint does not fit the next Provider request" on turn 2-3.
  // We give our own model entry the same capability mcode gives its own models. Nothing else in the file is touched.
  function patchCapabilities(alias) {
    const f = path.join(os.homedir(), ".minimax", "config.yaml");
    try {
      const YAML = require("node:module").createRequire(path.join(getSettings().mcodeDir, "package.json"))("yaml");
      const text = fs.readFileSync(f, "utf8");
      const doc = YAML.parseDocument(text);
      if (!doc.hasIn(["custom_provider", "local-llama", "models", alias])) return false;
      if (!fs.existsSync(f + ".bak-bm23")) fs.writeFileSync(f + ".bak-bm23", text);   // one-time backup of the user's config
      doc.setIn(["custom_provider", "local-llama", "models", alias, "capabilities", "max_request_body_bytes"], 67108864);
      fs.writeFileSync(f + ".tmp", doc.toString());
      fs.renameSync(f + ".tmp", f);
      return true;
    } catch (e) { console.log("[local] capability patch skipped:", e.message); return false; }
  }
  // expose the running local model to MiniMax Code as provider "local-llama"
  ipcMain.handle("local:register", async (_e, ctx) => {
    if (!server?.ready) throw new Error("load a model first");
    await runMcode(["provider", "remove", "custom_provider:local-llama", "--yes"]);
    const r = await runMcode(["provider", "add", "--name", "local-llama", "--base-url", `http://127.0.0.1:${SHIM_PORT}/v1`, "--api-format", "openai-completions",
      "--api-key-env", "FREE_PROXY_KEY", "--context-limit", String(server.ctx || ctx || 32768), "--output-limit", "8192", "--model", server.alias]);
    if (r.code !== 0) throw new Error("mcode provider add failed: " + r.out.trim().split("\n").slice(-3).join(" | "));
    patchCapabilities(server.alias);
    restartMcode();
    return { alias: server.alias, out: r.out };
  });
  // chat/bench runs in the main process: the renderer CSP is connect-src 'none' by design
  ipcMain.handle("local:bench", async (_e, prompt) => {
    if (!server?.ready) throw new Error("no local model running");
    const t0 = Date.now();
    const r = await fetch(`http://127.0.0.1:${PORT}/v1/chat/completions`, { method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ model: server.alias, messages: [{ role: "user", content: prompt || "Write three short sentences about the ocean." }], max_tokens: 160 }),
      signal: AbortSignal.timeout(180000) });
    if (!r.ok) throw new Error("server HTTP " + r.status);
    const j = await r.json();
    const msg = j.choices?.[0]?.message || {};
    const res = { ms: Date.now() - t0, text: msg.content || "", reasoning: msg.reasoning_content || "", tps: j.timings?.predicted_per_second || null, ppTps: j.timings?.prompt_per_second || null, tokens: j.usage?.completion_tokens || null };
    if (res.tps) saveSettings({ localBench: { ...(getSettings().localBench || {}), [server.file]: { tps: +res.tps.toFixed(1), pp: res.ppTps ? Math.round(res.ppTps) : null, ctx: server.ctx, at: Date.now() } } });
    return res;
  });
};
