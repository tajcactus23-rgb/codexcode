const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const readline = require('node:readline');
const crypto = require('node:crypto');
module.exports = function register({ app, ipcMain, dialog, getWin, getSettings, saveSettings, send = () => {} }) {
  let worker, ready, pending = new Map(), log = '', installing = false;
  const localJobs = new Map();
  const runtimeDir = path.join(app.getPath('userData'), 'voice-runtime');
  const runtimePython = path.join(runtimeDir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
  function run(command, args, timeout = 900000, id = crypto.randomUUID()) {
    return new Promise((resolve, reject) => {
      let output = ''; const child = spawn(command, args, { windowsHide: true, env: { ...process.env, PYTHONUNBUFFERED: '1' } }); localJobs.set(id, child);
      const timer = setTimeout(() => child.kill(), timeout);
      child.stdout.on('data', (b) => { output = (output + b).slice(-12000); send('voice:setup-event', b.toString()); });
      child.stderr.on('data', (b) => { output = (output + b).slice(-12000); send('voice:setup-event', b.toString()); });
      child.on('error', (e) => { clearTimeout(timer); localJobs.delete(id); reject(e); });
      child.on('close', (code) => { clearTimeout(timer); localJobs.delete(id); code === 0 ? resolve(output) : reject(new Error('Voice process failed (' + code + '): ' + output.slice(-1500))); });
    });
  }
  ipcMain.handle('voice:install', async () => {
    if (installing) throw new Error('Voice runtime setup is already running.');
    installing = true;
    try {
      const v = getSettings().integrations?.voice || {};
      if (!fs.existsSync(runtimePython)) await run(v.clonePython || 'python', ['-m', 'venv', runtimeDir]);
      await run(runtimePython, ['-m', 'pip', 'install', '--upgrade', 'pip']);
      await run(runtimePython, ['-m', 'pip', 'install', 'torch', 'torchaudio', 'torchcodec', 'coqui-tts', 'faster-whisper', 'kokoro>=0.9.4', 'soundfile'], 1800000);
      const st = getSettings(); saveSettings({ integrations: { ...st.integrations, voice: { ...st.integrations?.voice, clonePython: runtimePython, localSttModel: v.localSttModel || 'small' } } });
      return { message: 'Local voice runtime installed. Choose your recording and cloned speech output. Leave transcription URL blank to use local Whisper.' };
    } finally { installing = false; }
  });
  ipcMain.handle('file:install', async () => {
    if (installing) throw new Error('Runtime setup is already running.');
    installing = true;
    try {
      const v = getSettings().integrations?.voice || {};
      if (!fs.existsSync(runtimePython)) await run(v.clonePython || 'python', ['-m', 'venv', runtimeDir]);
      await run(runtimePython, ['-m', 'pip', 'install', 'pypdf', 'python-docx', 'openpyxl', 'python-pptx']);
      saveSettings({ files: { ...getSettings().files, python: runtimePython } });
      return { message: 'PDF, DOCX, XLSX and PPTX extractors installed.' };
    } finally { installing = false; }
  });
  ipcMain.handle('voice:kokoro-check', async () => {
    try { const output = await run(getSettings().integrations?.voice?.clonePython || 'python', ['-c', 'import kokoro, soundfile; print("Kokoro ready; ten voice presets available. First synthesis downloads model assets.")'], 30000); return { ok: true, message: output }; }
    catch (e) { return { ok: false, message: e.message }; }
  });
  ipcMain.handle('voice:kokoro-speak', async (_e, text, id) => {
    const v = getSettings().integrations?.voice || {}, dir = path.join(app.getPath('userData'), 'voice-output'); fs.mkdirSync(dir, { recursive: true });
    const output = path.join(dir, crypto.randomUUID() + '.wav');
    const child = spawn(v.clonePython || 'python', [path.join(__dirname, 'tools', 'kokoro-speak.py')], { windowsHide: true, env: { ...process.env, PYTHONUNBUFFERED: '1' } });
    localJobs.set(id, child); let log = '';
    const timer = setTimeout(() => child.kill(), 300000);
    child.stdin.end(JSON.stringify({ text: String(text).slice(0, 12000), voice: v.kokoroVoice || 'bm_george', speed: v.rate || 1, output }));
    try {
      await new Promise((resolve, reject) => { child.stderr.on('data', b => { log = (log + b).slice(-3000); }); child.stdout.on('data', () => {}); child.on('error', reject); child.on('close', code => code === 0 ? resolve() : reject(new Error('Kokoro failed: ' + log))); });
      return { bytes: fs.readFileSync(output), mime: 'audio/wav' };
    } finally { clearTimeout(timer); localJobs.delete(id); fs.rmSync(output, { force: true }); }
  });
  ipcMain.handle('voice:local-transcribe', async (_e, bytes, id) => {
    if (bytes.byteLength > 25 * 1048576) throw new Error('Recording exceeds 25 MB.');
    const v = getSettings().integrations?.voice || {}; const dir = path.join(app.getPath('userData'), 'voice-input'); fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, crypto.randomUUID() + '.wav'); fs.writeFileSync(file, Buffer.from(bytes));
    try { const output = await run(v.clonePython || 'python', [path.join(__dirname, 'tools', 'transcribe.py'), file, v.localSttModel || 'small', v.language || 'en'], 300000, id);
      const result = output.split('\n').find((s) => s.startsWith('FORGE_TRANSCRIPT:')); if (!result) throw new Error('Local Whisper returned no transcript.'); return JSON.parse(result.slice(17));
    } finally { fs.rmSync(file, { force: true }); }
  });
  const referenceDir = path.join(app.getPath('userData'), 'voice-reference');
  ipcMain.handle('voice:reference', async () => {
    const pick = await dialog.showOpenDialog(getWin(), { title: 'Choose a clean recording of your own voice (6–30 seconds)', properties: ['openFile'], filters: [{ name: 'Voice recording', extensions: ['wav', 'mp3', 'flac'] }] });
    if (pick.canceled) return null;
    const file = pick.filePaths[0]; if (fs.statSync(file).size > 25 * 1048576) throw new Error('Choose a recording under 25 MB.');
    fs.mkdirSync(referenceDir, { recursive: true }); const target = path.join(referenceDir, 'my-voice' + path.extname(file).toLowerCase()); fs.copyFileSync(file, target);
    const st = getSettings(); saveSettings({ integrations: { ...st.integrations, voice: { ...st.integrations?.voice, reference: target } } }); stop(); return target;
  });
  function stop() { worker?.kill(); worker = ready = null; for (const p of pending.values()) p.reject(new Error('Voice-clone worker stopped.')); pending.clear(); }
  function start() {
    if (ready) return ready;
    const v = getSettings().integrations?.voice || {};
    if (!v.cloneLicenseAccepted) return Promise.reject(new Error('Accept the XTTS model license in Voice settings before loading the model.'));
    const child = worker = spawn(v.clonePython || 'python', [path.join(__dirname, 'tools', 'voice-clone.py')], { windowsHide: true, env: { ...process.env, PYTHONUNBUFFERED: '1', COQUI_TOS_AGREED: '1' }, stdio: ['pipe', 'pipe', 'pipe'] });
    ready = new Promise((resolve, reject) => {
      const timer = setTimeout(() => { stop(); reject(new Error('Voice model loading timed out. Check Python/coqui-tts and the XTTS model installation.')); }, 240000);
      child.stderr.on('data', (b) => { log = (log + b).slice(-3000); });
      child.on('error', (e) => { clearTimeout(timer); if (worker === child) stop(); reject(e); });
      child.on('exit', (code) => { clearTimeout(timer); if (worker === child) stop(); reject(new Error('Voice clone exited ' + code + ': ' + log.slice(-800))); });
      readline.createInterface({ input: child.stdout }).on('line', (line) => {
        if (!line.startsWith('FORGE_JSON:')) return; let j; try { j = JSON.parse(line.slice(11)); } catch { return; }
        if (j.ready) { clearTimeout(timer); resolve(true); return; }
        const job = pending.get(j.id); if (!job) return; pending.delete(j.id); j.error ? job.reject(new Error(j.error)) : job.resolve(j.output);
      });
    });
    return ready;
  }
  ipcMain.handle('voice:cloneCheck', () => new Promise((resolve) => {
    const v = getSettings().integrations?.voice || {};
    const child = spawn(v.clonePython || 'python', ['-c', 'import TTS, torch, faster_whisper; print("coqui-tts ready; GPU=" + str(torch.cuda.is_available()))'], { windowsHide: true }); let out = '';
    const timer = setTimeout(() => { child.kill(); resolve({ ok: false, message: 'Python check timed out.' }); }, 30000);
    child.stdout.on('data', (b) => out += b); child.stderr.on('data', (b) => out += b);
    child.on('error', (e) => { clearTimeout(timer); resolve({ ok: false, message: e.message }); }); child.on('close', (code) => { clearTimeout(timer); resolve({ ok: code === 0, message: out.slice(-3000) }); });
  }));
  ipcMain.handle('voice:cloneSpeak', async (_e, text, id) => {
    const v = getSettings().integrations?.voice || {}; if (!v.reference || !fs.existsSync(v.reference)) throw new Error('Choose your voice recording in Settings → Voice.');
    await start(); const outDir = path.join(app.getPath('userData'), 'voice-output'); fs.mkdirSync(outDir, { recursive: true });
    const output = path.join(outDir, crypto.randomUUID() + '.wav');
    const file = await new Promise((resolve, reject) => { const timer = setTimeout(() => { pending.delete(id); reject(new Error('Voice synthesis timed out.')); }, 180000);
      pending.set(id, { resolve: (v) => { clearTimeout(timer); resolve(v); }, reject: (e) => { clearTimeout(timer); reject(e); } }); worker.stdin.write(JSON.stringify({ id, text: String(text).slice(0, 4000), reference: v.reference, language: v.language || 'en', output }) + '\n'); });
    try { return { bytes: fs.readFileSync(file), mime: 'audio/wav' }; } finally { fs.rmSync(file, { force: true }); }
  });
  ipcMain.on('voice:cancel', (_e, id) => { if (pending.has(id)) stop(); localJobs.get(id)?.kill(); });
  app.on('before-quit', () => { stop(); for (const job of localJobs.values()) job.kill(); });
};
