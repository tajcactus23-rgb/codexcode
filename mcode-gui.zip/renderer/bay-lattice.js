// Model Bay backdrop: raymarched crystal lattice, rendered at native device resolution.
// Nodes morph octahedron <-> cube over time, struts carry travelling energy dashes, the palette rotates slowly.
// Crisp only: rim lines are 1-pixel anti-aliased with fwidth (no glow, no blur), sub-pixel struts fade instead of shimmering.
// API: BayLattice.start(canvas) · .focus(css) flashes near nodes in a card's hue · .pulse(css) one-shot burst · .energy(0..1) dash speed.
(() => {
  const vert = `#version 300 es
  in vec2 p; void main(){ gl_Position = vec4(p,0.,1.); }`;
  const frag = `#version 300 es
  precision highp float;
  out vec4 o;
  uniform vec2 res; uniform float t, uFocus, uPulse, uEnergy; uniform vec3 uHue; uniform int uSteps;
  const float C = 2.2, SR = 0.017;
  float hash(vec3 p){ return fract(sin(dot(p, vec3(127.1,311.7,74.7))) * 43758.5453); }
  mat2 rot(float a){ float c=cos(a), s=sin(a); return mat2(c,-s,s,c); }
  float sdOct(vec3 p, float s){ p = abs(p); return (p.x+p.y+p.z-s)*0.57735027; }
  float sdBox(vec3 p, vec3 b){ vec3 q = abs(p)-b; return length(max(q,0.)) + min(max(q.x,max(q.y,q.z)),0.); }
  float nodeSD(vec3 q, float hsh){
    float sz = 0.21 + 0.14*hsh + 0.035*sin(t*1.3 + hsh*20.0);
    vec3 r = q; r.xz *= rot(t*0.38 + hsh*6.28); r.xy *= rot(t*0.26 + hsh*3.1);
    float m = smoothstep(0.2, 0.8, 0.5 + 0.5*sin(t*0.19 + hsh*6.2832));   // evolving shape
    return mix(sdOct(r, sz*1.38) - 0.018, sdBox(r, vec3(sz*0.6)) - 0.03, m);
  }
  float map(vec3 p, out vec3 cell, out float kind){
    cell = floor(p/C + 0.5);
    vec3 q = p - cell*C;
    float node = nodeSD(q, hash(cell));
    float st = min(length(q.yz), min(length(q.xz), length(q.xy))) - SR;
    kind = st < node ? 1.0 : 0.0;
    return min(node, st);
  }
  float mapD(vec3 p){ vec3 c; float k; return map(p, c, k); }
  vec3 nrm(vec3 p){ vec2 e = vec2(.0012,0.); return normalize(vec3(mapD(p+e.xyy)-mapD(p-e.xyy), mapD(p+e.yxy)-mapD(p-e.yxy), mapD(p+e.yyx)-mapD(p-e.yyx))); }
  vec3 neon(float x){
    x = fract(x) * 5.0;
    vec3 c0 = vec3(0.16,0.83,1.00), c1 = vec3(1.00,0.25,0.71), c2 = vec3(0.71,1.00,0.23), c3 = vec3(0.54,0.49,1.00), c4 = vec3(1.00,0.69,0.13);
    float f = smoothstep(0.82, 1.0, fract(x)); int i = int(x);
    vec3 a = i==0?c0:i==1?c1:i==2?c2:i==3?c3:c4, b = i==0?c1:i==1?c2:i==2?c3:i==3?c4:c0;
    return mix(a, b, f);
  }
  void main(){
    vec2 uv = (gl_FragCoord.xy - .5*res) / res.y;
    vec3 ro = vec3(1.1 + 0.4*sin(t*.11), 1.1 + 0.28*cos(t*.09), t*(0.32 + 0.25*uEnergy)); // fly through open space between node rows
    vec3 rd = normalize(vec3(uv, 1.25));
    rd.xy *= rot(t*0.025); rd.xz *= rot(0.16*sin(t*0.05));
    float d = 0., h, kind = 0.; vec3 cell; bool hit = false;
    for(int i=0;i<110;i++){ if(i >= uSteps) break; h = map(ro+rd*d, cell, kind); if(h < .0009*(1.0+d*0.6)){ hit = true; break; } d += h*0.92; if(d > 24.) break; }
    vec3 bg = vec3(0.006,0.010,0.024) + vec3(0.012,0.008,0.03)*(1.0-abs(uv.y));
    vec3 col = bg;
    if(hit){
      vec3 p = ro+rd*d, n = nrm(p), q = p - cell*C;
      float hsh = hash(cell);
      vec3 base = neon(hsh + t*0.012);
      vec3 l = normalize(vec3(.45,.8,-.35));
      float diff = clamp(dot(n,l),0.,1.);
      float fr = pow(1.-clamp(dot(n,-rd),0.,1.),3.);
      float w = fwidth(fr);
      float edge = smoothstep(0.52-w, 0.52+w, fr);                  // 1px anti-aliased rim line
      float spec = pow(clamp(dot(reflect(-l,n),-rd),0.,1.), 80.);
      vec3 c0;
      if(kind > 0.5){
        // strut: travelling energy dashes along the strut's own axis
        float dx = length(q.yz), dy = length(q.xz), dz = length(q.xy);
        float s = dx < dy && dx < dz ? p.x : (dy < dz ? p.y : p.z);
        vec3 lineId = dx < dy && dx < dz ? vec3(0., cell.yz) : (dy < dz ? vec3(cell.x, 0., cell.z) : vec3(cell.xy, 0.));
        float lh = hash(lineId + 7.0);
        vec3 lc = neon(lh + t*0.012);
        float u = s*0.42 - t*(0.7 + 2.6*uEnergy) - lh*13.0;
        float fw = fwidth(u);
        float dash = smoothstep(0.93-fw, 0.93+fw, fract(u));
        float px = d * 1.6 / res.y;                                    // pixel footprint: fade sub-pixel struts
        float vis = clamp(SR*2.2/px, 0., 1.);
        c0 = (lc*0.16 + lc*dash*1.6) * vis;
      } else {
        float beat = step(0.986, fract(t*0.23 + hsh*7.0));
        c0 = base*(0.05+0.24*diff) + base*edge*0.95 + vec3(1.)*spec*0.85 + base*beat*0.9;
      }
      float near = smoothstep(9., 2.5, d);
      c0 = mix(c0, uHue*(0.35 + edge*1.5), uFocus*near*(kind > 0.5 ? 0.45 : 1.0));
      c0 += uHue*uPulse*(edge + 0.3)*near;
      col = mix(bg, c0, exp(-0.105*d));                               // depth fade to the backdrop, no scatter
    }
    o = vec4(pow(min(col, vec3(1.)), vec3(0.9)), 1.);
  }`;

  let gl, canvas, prog, U = {}, raf = 0, t0 = 0, focus = 0, focusT = 0, pulse = 0, energy = 0, energyT = 0, hue = [0.16, 0.83, 1];
  function compile(type, src) {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error("bay-lattice shader: " + gl.getShaderInfoLog(s));
    return s;
  }
  function init(c) {
    canvas = c;
    gl = c.getContext("webgl2", { antialias: false, alpha: false, powerPreference: "high-performance" });
    if (!gl) return false;
    prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, vert)); gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, frag)); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error("bay-lattice link: " + gl.getProgramInfoLog(prog));
    gl.useProgram(prog);
    const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "p"); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    for (const n of ["res", "t", "uFocus", "uPulse", "uEnergy", "uHue", "uSteps"]) U[n] = gl.getUniformLocation(prog, n);
    t0 = performance.now();
    return true;
  }
  // quality tiers. dpr = pixel density cap (biggest cost lever), steps = raymarch iterations, fps = target cap.
  const QUAL = {
    high: { dpr: 2.0, steps: 110, fps: 60 },
    low:  { dpr: 1.0, steps: 46,  fps: 30 },   // ~1/6 the pixel+march work of high
    off:  { dpr: 1.0, steps: 0,   fps: 10 },   // raymarch skipped entirely — just the animated gradient
  };
  let qual = "auto"; try { qual = localStorage.getItem("bayQual") || "auto"; } catch {}
  let tier = qual === "auto" ? "high" : qual, lowStreak = 0, minFrame = 1000 / 60;
  const activeTier = () => QUAL[tier];
  function resize() {
    const dpr = Math.min(devicePixelRatio || 1, activeTier().dpr);
    const w = Math.max(1, Math.round(canvas.clientWidth * dpr)), h = Math.max(1, Math.round(canvas.clientHeight * dpr));
    if (w !== canvas.width || h !== canvas.height) { canvas.width = w; canvas.height = h; gl.viewport(0, 0, w, h); }
  }
  const STATIC = true; // user choice: still backdrop, no motion
  let drawn = false;
  let frames = 0, fpsT = 0, running = false, lastDraw = 0;
  function frame(now) {
    if (!running || !canvas.isConnected) { raf = 0; return; }
    raf = requestAnimationFrame(frame);
    if (canvas.getClientRects().length === 0) return;
    if (now - lastDraw < minFrame - 1.5) return;   // cap FPS to the tier so we don't burn the GPU at 144Hz
    lastDraw = now;
    const w0 = canvas.width, h0 = canvas.height;
    resize();
    if (STATIC && drawn && canvas.width === w0 && canvas.height === h0) return; // still frame: redraw only on resize
    focus += ((now < focusT ? 1 : 0) - focus) * 0.14;
    pulse *= 0.93;
    energy += ((now < energyT ? 1 : 0) - energy) * 0.04;
    gl.uniform2f(U.res, canvas.width, canvas.height);
    gl.uniform1f(U.t, STATIC ? 10.3 : (now - t0) / 1000); // still frame: camera parked between lattice cells, not inside a node
    gl.uniform1f(U.uFocus, focus); gl.uniform1f(U.uPulse, pulse); gl.uniform1f(U.uEnergy, energy);
    gl.uniform3fv(U.uHue, hue); gl.uniform1i(U.uSteps, activeTier().steps);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    drawn = true;
    frames++;
    if (now - fpsT > 1000) {
      const fps = Math.round((frames * 1000) / (now - fpsT)); window.BayLattice.fps = fps; frames = 0; fpsT = now;
      if (qual === "auto") {   // auto-downshift: two slow seconds -> drop a tier; never auto-upshift (avoid oscillation)
        if (fps < 34 && tier !== "low") { if (++lowStreak >= 2) { setTier(tier === "high" ? "low" : "low"); lowStreak = 0; } }
        else lowStreak = 0;
      }
    }
  }
  function setTier(t) { tier = t; minFrame = 1000 / QUAL[t].fps; if (gl) resize(); window.BayLattice.tier = t; }
  const toRgb = (css) => {
    const m = String(css).match(/hsl\(\s*([\d.]+)/);
    if (m) { const hh = ((+m[1] % 360) + 360) % 360 / 60, x = 1 - Math.abs((hh % 2) - 1); const s = [[1, x, 0], [x, 1, 0], [0, 1, x], [0, x, 1], [x, 0, 1], [1, 0, x]][Math.floor(hh) % 6]; return s.map((v) => 0.2 + 0.8 * v); }
    const hx = String(css).replace("#", "");
    return hx.length >= 6 ? [0, 2, 4].map((i) => parseInt(hx.slice(i, i + 2), 16) / 255) : hue;
  };
  window.BayLattice = {
    fps: 0, tier: "high",
    start(c) { if (!gl && !init(c)) return; running = true; if (qual !== "auto") setTier(qual); resize(); if (!raf) raf = requestAnimationFrame(frame); },
    stop() { running = false; },
    setQuality(q) { qual = q; lowStreak = 0; if (q === "auto") { tier = "high"; setTier("high"); } else setTier(q); try { localStorage.setItem("bayQual", q); } catch {} },
    getQuality: () => qual,
    focus(css) { hue = toRgb(css); focusT = performance.now() + 900; },
    pulse(css) { if (css) hue = toRgb(css); pulse = 1; },
    energy(on) { if (on) energyT = performance.now() + 1500; },
  };
})();
