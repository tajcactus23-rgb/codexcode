const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'uploads', '.self-dev', '__pycache__']);
function files(root, dir = root) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    if (SKIP.has(entry.name) || entry.isSymbolicLink()) return [];
    const file = path.join(dir, entry.name); return entry.isDirectory() ? files(root, file) : [file];
  });
}
function hashTree(root) { const h = crypto.createHash('sha256'); for (const f of files(root).sort()) { h.update(path.relative(root, f)); h.update(fs.readFileSync(f)); } return h.digest('hex'); }
function copyTree(source, target) { fs.mkdirSync(target, { recursive: true }); for (const f of files(source)) { const out = path.join(target, path.relative(source, f)); fs.mkdirSync(path.dirname(out), { recursive: true }); fs.copyFileSync(f, out); } }
function syncTree(source, target) {
  const wanted = new Set(files(source).map((f) => path.relative(source, f)));
  for (const file of files(target)) if (!wanted.has(path.relative(target, file))) fs.rmSync(file);
  copyTree(source, target);
}
module.exports = function register({ app, ipcMain, send, getSettings, sourceRoot = __dirname }) {
  const base = path.join(app.getPath('userData'), 'self-development'); let current = null, running = null, validating = false, cancelled = false;
  const sourceProxy = path.join(sourceRoot, '..', 'free-proxy');
  const stateFile = path.join(base, 'state.json');
  try { current = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch {}
  const save = () => { fs.mkdirSync(base, { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify(current, null, 2)); if (current?.root) fs.writeFileSync(path.join(current.root, 'checkpoint.json'), JSON.stringify(current, null, 2)); };
  const history = () => { if (!fs.existsSync(base)) return []; return fs.readdirSync(base, { withFileTypes: true }).filter(d => d.isDirectory()).flatMap(d => { try { return [JSON.parse(fs.readFileSync(path.join(base, d.name, 'checkpoint.json'), 'utf8'))]; } catch { return []; } }).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); };
  ipcMain.handle('dev:history', () => history());
  ipcMain.handle('dev:diff', () => {
    if (!current?.workspace) throw new Error('Create a working copy first.');
    const changes = [];
    for (const [name, oldRoot, newRoot] of [['mcode-gui', sourceRoot, current.workspace], ['free-proxy', sourceProxy, path.join(current.root, 'free-proxy')]]) {
      const old = new Map((fs.existsSync(oldRoot) ? files(oldRoot) : []).map(f => [path.relative(oldRoot, f), f]));
      const next = new Map((fs.existsSync(newRoot) ? files(newRoot) : []).map(f => [path.relative(newRoot, f), f]));
      for (const rel of new Set([...old.keys(), ...next.keys()])) { const a = old.get(rel), b = next.get(rel); const hash = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex'); const before = a ? hash(a) : null, after = b ? hash(b) : null; if (before !== after) changes.push({ path: name + '/' + rel, kind: !a ? 'added' : !b ? 'removed' : 'modified', before, after, bytes: b ? fs.statSync(b).size : 0 }); }
    }
    return { workspace: current.workspace, changes };
  });
  const digest = () => hashTree(current.workspace) + (fs.existsSync(path.join(current.root, 'free-proxy')) ? ':' + hashTree(path.join(current.root, 'free-proxy')) : '');
  function run(cmd, args, cwd, timeout = 180000) {
    const env = { ...process.env, ELECTRON_RUN_AS_NODE: cmd === process.execPath ? '1' : process.env.ELECTRON_RUN_AS_NODE };
    delete env.NODE_TEST_CONTEXT;
    return new Promise((resolve) => { let output = '', timedOut = false; const child = running = spawn(cmd, args, { cwd, env, shell: false, windowsHide: true });
      const timer = setTimeout(() => { timedOut = true; child.kill(); }, timeout);
      const log = (b) => { output = (output + b).slice(-30000); send('dev:event', { kind: 'output', text: b.toString() }); }; child.stdout.on('data', log); child.stderr.on('data', log);
      child.on('error', (e) => { clearTimeout(timer); resolve({ ok: false, code: -1, output: e.message }); });
      child.on('close', (code) => { clearTimeout(timer); if (running === child) running = null; resolve({ ok: code === 0 && !cancelled && !timedOut, code, output: output + (timedOut ? '\nValidation timed out.' : cancelled ? '\nValidation cancelled.' : '') }); });
    });
  }
  ipcMain.handle('dev:state', () => current);
  ipcMain.handle('dev:cancel', () => { cancelled = true; running?.kill(); return true; });
  ipcMain.handle('dev:prepare', () => {
    if (validating) throw new Error('Validation is still running.');
    const id = new Date().toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomBytes(3).toString('hex'), root = path.join(base, id), workspace = path.join(root, 'mcode-gui');
    copyTree(sourceRoot, workspace);
    if (fs.existsSync(sourceProxy)) copyTree(sourceProxy, path.join(root, 'free-proxy'));
    current = { id, root, workspace, createdAt: new Date().toISOString(), validation: null, review: null }; current.sourceHash = digest(); save(); return current;
  });
  ipcMain.handle('dev:validate', async () => {
    if (!current || !fs.existsSync(current.workspace)) throw new Error('Create a self-development workspace first.');
    if (validating) throw new Error('Validation is already running.');
    validating = true; cancelled = false; current.validation = current.review = null; save(); const checks = [], before = digest();
    try {
      const roots = [current.workspace, path.join(current.root, 'free-proxy')].filter(fs.existsSync);
      for (const file of roots.flatMap((root) => files(root)).filter((f) => /\.(cjs|mjs|js)$/.test(f))) {
        if (cancelled) break;
        const result = await run(process.execPath, ['--check', file], current.workspace);
        checks.push({ name: 'syntax ' + path.relative(current.root, file), ...result });
        if (!result.ok) break;
      }
      if (!cancelled && checks.every((c) => c.ok)) {
        const testFiles = fs.existsSync(path.join(current.workspace, 'tests')) ? files(path.join(current.workspace, 'tests')).filter((f) => /\.test\.cjs$/.test(f)) : [];
        if (!testFiles.length) checks.push({ name: 'test suite', ok: false, output: 'No executable tests found. Add regression tests before validating.' });
        else checks.push({ name: 'regression tests', ...await run(process.execPath, ['--test', ...testFiles], current.workspace, 300000) });
      }
      for (const validator of getSettings().selfDev?.validators || []) {
        if (cancelled || !checks.every((c) => c.ok)) break;
        if (!validator.command || !Array.isArray(validator.args) || !validator.args.every((x) => typeof x === 'string')) throw new Error('Validators need a command and an array of arguments.');
        checks.push({ name: validator.name || validator.command, ...await run(validator.command, validator.args, current.workspace, 300000) });
      }
      const after = digest();
      if (before !== after) checks.push({ name: 'source stability', ok: false, output: 'Source changed during validation. Run checks again on a stable tree.' });
      current.validation = { ok: !cancelled && checks.length > 0 && checks.every((c) => c.ok), at: new Date().toISOString(), hash: after, checks }; save(); return current.validation;
    } finally { validating = false; }
  });
  ipcMain.handle('dev:review', (_e, verdict, text) => {
    if (!current?.validation?.ok || current.validation.hash !== digest()) throw new Error('Validate the current source before recording a review.');
    current.review = { ok: verdict === 'PASS', text: String(text).slice(-50000), hash: digest(), at: new Date().toISOString() }; save(); return current.review;
  });
  ipcMain.handle('dev:apply', () => {
    if (validating || !current?.validation?.ok || !current?.review?.ok) throw new Error('Both validation and reviewer approval must pass.');
    const actual = digest(); if (actual !== current.validation.hash || actual !== current.review.hash) throw new Error('Source changed after validation/review. Run them again.');
    if (current.appliedAt) throw new Error('This working copy was already applied. Create a new copy for the next improvement.');
    const backup = path.join(current.root, 'previous-installation'); copyTree(sourceRoot, backup);
    if (fs.existsSync(sourceProxy)) copyTree(sourceProxy, path.join(current.root, 'previous-proxy'));
    try {
      syncTree(current.workspace, sourceRoot);
      const proxy = path.join(current.root, 'free-proxy'); if (fs.existsSync(proxy)) { fs.mkdirSync(sourceProxy, { recursive: true }); syncTree(proxy, sourceProxy); }
    } catch (e) {
      syncTree(backup, sourceRoot); const previousProxy = path.join(current.root, 'previous-proxy'); if (fs.existsSync(previousProxy)) syncTree(previousProxy, sourceProxy);
      throw new Error('Apply failed; previous source restored: ' + e.message);
    }
    current.appliedAt = new Date().toISOString(); current.backup = backup; save();
    return { backup, message: 'Validated source applied. Restart Forge. If dependencies changed, run npm install first.' };
  });
  ipcMain.handle('dev:rollback', (_e, checkpointId) => {
    if (checkpointId) { const selected = history().find(x => x.id === checkpointId); if (!selected) throw new Error('Checkpoint not found.'); current = selected; }
    else if (!current?.backup) { const selected = history().find(x => x.appliedAt && x.backup); if (selected) current = selected; }
    if (validating || !current?.backup || !fs.existsSync(current.backup)) throw new Error('No installation rollback is available, or validation is running.');
    syncTree(current.backup, sourceRoot); const proxy = path.join(current.root, 'previous-proxy'); if (fs.existsSync(proxy)) syncTree(proxy, sourceProxy);
    current.appliedAt = null; current.review = null; save(); return { message: 'Previous source restored. Restart Forge.' };
  });
  app.on('before-quit', () => running?.kill());
};
module.exports.hashTree = hashTree;
module.exports.copyTree = copyTree;
module.exports.syncTree = syncTree;
