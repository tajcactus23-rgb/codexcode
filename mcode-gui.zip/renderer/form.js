import * as THREE from "../node_modules/three/build/three.module.js";

// Living reactive centrepiece for the CODE deck — morphing crystal core, breathing
// wire shell, orbital rings, particle halo. Colour driven by the active tab/engine.
export function mountForm(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setClearColor(0x000000, 0);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
  camera.position.set(0, 0.3, 10);
  const rig = new THREE.Group(); scene.add(rig);

  const NOISE = `
  vec3 mod289(vec3 x){return x-floor(x*(1./289.))*289.;}vec4 mod289(vec4 x){return x-floor(x*(1./289.))*289.;}
  vec4 permute(vec4 x){return mod289(((x*34.)+1.)*x);}vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
  float snoise(vec3 v){const vec2 C=vec2(1./6.,1./3.);const vec4 D=vec4(0.,.5,1.,2.);vec3 i=floor(v+dot(v,C.yyy));vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz);vec3 l=1.-g;vec3 i1=min(g.xyz,l.zxy);vec3 i2=max(g.xyz,l.zxy);vec3 x1=x0-i1+C.xxx;vec3 x2=x0-i2+C.yyy;vec3 x3=x0-D.yyy;
  i=mod289(i);vec4 p=permute(permute(permute(i.z+vec4(0.,i1.z,i2.z,1.))+i.y+vec4(0.,i1.y,i2.y,1.))+i.x+vec4(0.,i1.x,i2.x,1.));
  float n_=.142857142857;vec3 ns=n_*D.wyz-D.xzx;vec4 j=p-49.*floor(p*ns.z*ns.z);vec4 x_=floor(j*ns.z);vec4 y_=floor(j-7.*x_);
  vec4 x=x_*ns.x+ns.yyyy;vec4 y=y_*ns.x+ns.yyyy;vec4 h=1.-abs(x)-abs(y);vec4 b0=vec4(x.xy,y.xy);vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.+1.;vec4 s1=floor(b1)*2.+1.;vec4 sh=-step(h,vec4(0.));vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy;vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x);vec3 p1=vec3(a0.zw,h.y);vec3 p2=vec3(a1.xy,h.z);vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));p0*=norm.x;p1*=norm.y;p2*=norm.z;p3*=norm.w;
  vec4 m=max(.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.);m=m*m;return 42.*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));}`;

  const U = {
    uTime: { value: 0 }, uEnergy: { value: 0.2 }, uPulse: { value: 0 },
    uCol: { value: new THREE.Color("#2ad4ff") }, uCol2: { value: new THREE.Color("#ff3ec8") },
    uMouse: { value: new THREE.Vector3(0, 0, 3) },
  };
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.5, 64), new THREE.ShaderMaterial({
    uniforms: U,
    vertexShader: NOISE + `uniform float uTime,uEnergy,uPulse;uniform vec3 uMouse;varying vec3 vN;varying vec3 vP;varying float vD;
      void main(){vec3 n=normalize(normal);float t=uTime*.35;
        float d=snoise(n*1.3+vec3(t,t*.7,-t*.5))*.42+snoise(n*3.1-vec3(t*1.3))*.13*(.6+uEnergy);
        d+=pow(max(dot(n,normalize(uMouse)),0.),6.)*.5*(.4+uEnergy);
        d+=sin(length(position)*9.-uTime*7.)*.08*uPulse; d*=(.55+uEnergy*.9);
        vD=d;vec3 p=position+n*d;vN=normalize(normalMatrix*n);vP=(modelViewMatrix*vec4(p,1.)).xyz;
        gl_Position=projectionMatrix*vec4(vP,1.);}`,
    fragmentShader: `uniform vec3 uCol,uCol2;uniform float uTime,uEnergy,uPulse;varying vec3 vN;varying vec3 vP;varying float vD;
      void main(){vec3 V=normalize(-vP);float fr=pow(1.-max(dot(vN,V),0.),2.6);
        float bands=.5+.5*sin(vD*22.-uTime*2.2);vec3 base=mix(vec3(.01,.02,.05),uCol*.35,bands*.55);
        vec3 col=base+mix(uCol,uCol2,.5+.5*sin(uTime*.6+vD*6.))*fr*(1.4+uEnergy*1.6);
        col+=vec3(1.)*smoothstep(.97,1.,bands)*.35*(.4+uEnergy)+uCol*uPulse*.35;
        gl_FragColor=vec4(col,.96);}`,
  }));
  rig.add(core);
  const basePos = core.geometry.attributes.position.array.slice();

  const shell = new THREE.Mesh(new THREE.IcosahedronGeometry(2.4, 2), new THREE.ShaderMaterial({
    uniforms: U, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, wireframe: true,
    vertexShader: NOISE + `uniform float uTime,uEnergy,uPulse;varying float vA;
      void main(){vec3 n=normalize(position);float d=snoise(n*1.6+uTime*.25)*.25*(.5+uEnergy)+uPulse*.35;
        vA=.5+.5*snoise(n*3.+uTime*.5);gl_Position=projectionMatrix*modelViewMatrix*vec4(position*(1.+d*.25),1.);}`,
    fragmentShader: `uniform vec3 uCol,uCol2;uniform float uEnergy;varying float vA;
      void main(){gl_FragColor=vec4(mix(uCol,uCol2,vA),.16+uEnergy*.22);}`,
  }));
  rig.add(shell);

  const rings = [];
  for (let i = 0; i < 3; i++) {
    const r = new THREE.Mesh(new THREE.TorusGeometry(3 + i * 0.4, 0.006 + i * 0.002, 6, 200),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }));
    r.rotation.set(Math.PI / 2 + (i - 1) * 0.55, i * 0.9, 0); r.userData.s = 0.12 + i * 0.07; rig.add(r); rings.push(r);
  }
  const N = 1400, pos = new Float32Array(N * 3), seed = new Float32Array(N);
  for (let i = 0; i < N; i++) { const u = Math.random() * 2 - 1, th = Math.random() * 6.28, s = Math.sqrt(1 - u * u), rr = 3.4 + Math.random() * 2.6; pos.set([Math.cos(th) * s * rr, u * rr * 0.8, Math.sin(th) * s * rr], i * 3); seed[i] = Math.random(); }
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos, 3)); pg.setAttribute("seed", new THREE.BufferAttribute(seed, 1));
  const halo = new THREE.Points(pg, new THREE.ShaderMaterial({
    uniforms: U, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    vertexShader: `uniform float uTime,uEnergy,uPulse;attribute float seed;varying float vA;
      void main(){vec3 p=position;float a=uTime*(.05+seed*.08)+seed*6.28;p.xz=mat2(cos(a),-sin(a),sin(a),cos(a))*p.xz;
        p*=1.+uPulse*.16*sin(seed*20.+uTime*3.);vec4 mv=modelViewMatrix*vec4(p,1.);
        gl_PointSize=(1.+seed*1.8+uEnergy*1.5)*(20./-mv.z);vA=.3+.6*fract(seed*13.+uTime*.2);gl_Position=projectionMatrix*mv;}`,
    fragmentShader: `uniform vec3 uCol,uCol2;varying float vA;void main(){vec2 c=gl_PointCoord-.5;float r=length(c);if(r>.5)discard;gl_FragColor=vec4(mix(uCol,uCol2,vA),vA*(1.-r*1.6));}`,
  }));
  rig.add(halo);

  const target = { col: new THREE.Color("#2ad4ff"), col2: new THREE.Color("#ff3ec8") };
  const state = { energy: 0.22, pulse: 0 };
  const mouse = new THREE.Vector2(), m3 = new THREE.Vector3(0, 0, 3);
  let rotY = 0, velY = 0.0022, drag = null;
  canvas.addEventListener("pointermove", (e) => { const r = canvas.getBoundingClientRect(); mouse.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); if (drag) { velY = (e.clientX - drag.x) * 0.0006; drag = { x: e.clientX, t: drag.t }; } state.energy = Math.min(1.2, state.energy + 0.004); });
  canvas.addEventListener("pointerdown", (e) => { drag = { x: e.clientX, t: performance.now() }; });
  addEventListener("pointerup", () => { if (drag && performance.now() - drag.t < 220) api.pulse(1.3); drag = null; });

  function resize() { const w = canvas.clientWidth || 1, h = canvas.clientHeight || 1; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
  const ro = new ResizeObserver(resize); ro.observe(canvas); resize();

  const t0 = performance.now();
  renderer.setAnimationLoop((now) => {
    if (window.__bayOpen || document.hidden || document.body.classList.contains("onpage")) return; // occluded behind the fullscreen Model Bay — don't burn GPU
    const t = (now - t0) / 1000; U.uTime.value = t;
    state.energy += (0.2 - state.energy) * 0.012; state.pulse *= 0.955; U.uPulse.value = state.pulse;
    U.uEnergy.value += (state.energy * intensity - U.uEnergy.value) * 0.08;
    U.uCol.value.lerp(target.col, 0.05); U.uCol2.value.lerp(target.col2, 0.05);
    m3.set(mouse.x * 4, mouse.y * 3, 2.5); U.uMouse.value.lerp(m3.clone().applyEuler(new THREE.Euler(-rig.rotation.x, -rig.rotation.y, 0)), 0.1);
    if (!drag) velY += (0.0022 - velY) * 0.02; rotY += velY;
    rig.rotation.y = rotY + mouse.x * 0.25; rig.rotation.x = -mouse.y * 0.16;
    rings.forEach((r, i) => { r.rotation.z += r.userData.s * 0.016 * (1 + U.uEnergy.value * 3 + state.pulse); r.material.color.copy(i === 1 ? U.uCol2.value : U.uCol.value); r.scale.setScalar(1 + state.pulse * 0.06 * (i + 1)); });
    shell.rotation.y = -t * 0.08; core.scale.setScalar(1 + Math.sin(t * 1.3) * 0.02 + state.pulse * 0.05);
    if (visible) renderer.render(scene, camera); else { renderer.clear(); }
  });

  let intensity = 1, visible = true;
  const api = {
    config(c){ intensity = c.reactorIntensity ?? 1; visible = c.reactorOn !== false; canvas.style.opacity = visible ? "" : "0"; },
    setColors(a, b) { target.col.set(a); target.col2.set(b || a); state.pulse = Math.min(2.5, state.pulse + 1); state.energy = Math.min(1.2, state.energy + 0.4); },
    pulse(a = 1) { state.pulse = Math.min(2.5, state.pulse + a); state.energy = Math.min(1.2, state.energy + 0.25 * a); },
    busy(on) { state.energy = on ? 1 : 0.22; },
  };
  return api;
}
