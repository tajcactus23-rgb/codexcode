const test = require('node:test'), assert = require('node:assert/strict'), fs = require('node:fs'), os = require('node:os'), path = require('node:path'), http = require('node:http');
const supervisor = require('../supervisor.cjs'), telegram = require('../telegram.cjs');
function host(t) { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'forge-mon-')), handlers = {}, quit = []; t.after(() => { quit.forEach(f => f()); fs.rmSync(dir, { recursive: true, force: true }); }); return { dir, app: { getPath: () => dir, on: (name, f) => quit.push(f) }, ipcMain: { handle: (name, f) => handlers[name] = f }, call: (name, ...args) => handlers[name](null, ...args) }; }
test('independent monitor approval requires an ended turn; STOP cancels the worker and review failures fail closed', async t => {
  const h = host(t), cancels = []; let verdict = 'OK'; const monitor = supervisor({ ...h, send: () => {}, getSettings: () => ({ monitor: { reviewer: 'claude' } }), cancel: (...args) => cancels.push(args), review: async ({ engine, onSession }) => { assert.equal(engine, 'claude'); onSession('review-session'); return { ok: true, text: 'Read actual progress.\nFORGE_MONITOR: ' + verdict }; } });
  h.call('monitor:start', { engine: 'native', sessionId: 'worker', cwd: h.dir, goal: 'Implement feature' }); await monitor.check(); assert.throws(() => h.call('monitor:complete'), /approval/); h.call('monitor:turn-ended'); assert.equal((await monitor.check()).ok, true); assert.equal(h.call('monitor:complete').status, 'complete');
  h.call('monitor:start', { engine: 'native', sessionId: 'worker2', cwd: h.dir, goal: 'Continue' }); verdict = 'STOP'; assert.equal((await monitor.check()).ok, false); assert.equal(monitor.get().status, 'stopped'); assert.ok(cancels.some(x => x[1] === 'worker2'));
});
test('monitor cancels repeated actual tool-failure notifications and unavailable reviewers', async t => {
  const h = host(t), cancels = [], m = supervisor({ ...h, send: () => {}, getSettings: () => ({ monitor: { failureLimit: 2 } }), cancel: (...x) => cancels.push(x), review: async () => { throw Error('Account not signed in'); } });
  h.call('monitor:start', { engine: 'native', sessionId: 'a', goal: 'task' }); for (let i = 0; i < 2; i++) m.observe('acp:notify', 'native', 'session/update', { sessionId: 'a', update: { sessionUpdate: 'tool_call_update', status: 'failed' } }); assert.equal(m.get().reason, 'Repeated tool failures'); assert.ok(cancels.length);
  h.call('monitor:start', { engine: 'native', sessionId: 'b', goal: 'task' }); await m.check(); assert.match(m.get().reason, /Account not signed in/); assert.equal(m.get().status, 'stopped');
});
test('monitor watchdog enforces a real elapsed runtime budget', async t => {
  const h = host(t), m = supervisor({ ...h, send: () => {}, getSettings: () => ({ monitor: { maxMinutes: 0.001 } }), cancel: () => {}, review: async () => ({ ok: true, text: 'FORGE_MONITOR: OK' }) }); h.call('monitor:start', { engine: 'native', sessionId: 'a', goal: 'task' }); await new Promise(r => setTimeout(r, 2700)); assert.equal(m.get().status, 'stopped'); assert.match(m.get().reason, /runtime limit/);
});
test('Telegram routes only allowed chats, blocks disabled remote runs, streams real documents and segments replies', async t => {
  const h = host(t), requests = [], events = [], payload = Buffer.from('file content 🎙'), server = http.createServer(async (req, res) => {
    if (req.url.startsWith('/file/')) { res.end(payload); return; } let raw = ''; for await (const b of req) raw += b; const method = req.url.split('/').at(-1), args = JSON.parse(raw); requests.push({ method, args }); res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ ok: true, result: method === 'getFile' ? { file_path: 'documents/sample.bin', file_size: payload.length } : method === 'getMe' ? { id: 123, username: 'fixture_bot' } : true }));
  }); await new Promise(r => server.listen(0, '127.0.0.1', r)); t.after(() => { server.closeAllConnections(); server.close(); }); const config = { telegram: { chatIds: ['7'], allowRun: false } }, api = telegram({ ...h, getSettings: () => config, getSecret: () => 'fixture-token', getStatus: () => ({ state: 'idle' }), stopMission: () => {}, send: (...args) => events.push(args), baseOverride: 'http://127.0.0.1:' + server.address().port });
  const update = (id, text, document) => ({ update_id: 1, message: { chat: { id }, from: {}, text, document } }); await api.handle(update(999, '/chat ignore')); assert.equal(events.length, 0); assert.equal(requests.length, 0);
  await api.handle(update(7, '/run task')); assert.equal(events.length, 0); assert.match(requests.at(-1).args.text, /disabled/);
  await api.handle(update(7, '/chat continue')); assert.equal(events.at(-1)[1].kind, 'chat'); assert.equal(events.at(-1)[1].text, 'continue');
  await api.handle(update(7, '', { file_id: 'f1', file_name: 'report.anytype' })); const doc = events.at(-1)[1]; assert.equal(doc.kind, 'document'); assert.deepEqual(fs.readFileSync(doc.path), payload);
  const before = requests.length; await api.reply(7, 'x'.repeat(8000)); assert.equal(requests.length - before, 3); await assert.rejects(api.reply(999, 'no'), /allowlist/);
});
test('turn-end awaits an in-flight review; a stopped old review cannot stop a replacement run', async t => {
  const h = host(t); let rejectOld, resolveCurrent; let count = 0; const prompts=[];
  const m = supervisor({ ...h, send: () => {}, getSettings: () => ({}), cancel: () => {}, review: ({prompt}) => { prompts.push(prompt); return ++count === 1 ? new Promise((resolve, reject) => { rejectOld = reject; }) : count === 2 ? new Promise(resolve => { resolveCurrent = resolve; }) : Promise.resolve({ ok: true, text: 'Fresh final review. FORGE_MONITOR: OK' }); } });
  h.call('monitor:start', { engine: 'native', sessionId: 'old', goal: 'old task' }); const old = m.check(); h.call('monitor:stop');
  h.call('monitor:start', { engine: 'native', sessionId: 'new', goal: 'new task' }); const current = m.check(); m.observe('acp:notify','native','session/update',{sessionId:'new',update:{sessionUpdate:'agent_message_chunk',content:{text:'Final source changed and tested.'}}}); h.call('monitor:turn-ended'); const same = m.check(); assert.equal(current, same);
  rejectOld(Error('Old request cancelled')); await old; assert.equal(m.get().sessionId, 'new'); assert.equal(m.get().status, 'reviewing');
  resolveCurrent({ ok: true, text: 'FORGE_MONITOR: OK' }); assert.equal((await current).ok, true); assert.equal(m.get().status, 'ready'); assert.equal(h.call('monitor:complete').status, 'complete'); assert.equal(count, 3); assert.match(prompts.at(-1), /Final source changed and tested/); assert.doesNotMatch(prompts[1], /Final source changed and tested/);
});
