// Usage: electron tools/snap.cjs <outDir> <file1.html> [file2.html ...]
// Renders each page offscreen for a moment (so animations run) and saves a PNG thumbnail.
const { app, BrowserWindow } = require("electron");
const fs = require("node:fs");
const path = require("node:path");

const [outDir, ...files] = process.argv.slice(process.argv.findIndex((a) => /snap\.cjs$/i.test(a)) + 1);
const WAIT = Number(process.env.SNAP_WAIT || 2500);
const W = Number(process.env.SNAP_W || 1600), H = Number(process.env.SNAP_H || 900), THUMB = Number(process.env.SNAP_THUMB || 0);

app.disableHardwareAcceleration = app.disableHardwareAcceleration || (() => {});
app.whenReady().then(async () => {
  fs.mkdirSync(outDir, { recursive: true });
  const win = new BrowserWindow({ show: false, width: W, height: H, webPreferences: { offscreen: false, sandbox: true, backgroundThrottling: false } });
  let n = 0;
  for (const f of files) {
    const out = path.join(outDir, path.basename(f).replace(/\.html?$/i, ".png"));
    if (fs.existsSync(out) && !process.env.SNAP_FORCE) continue;
    try {
      await Promise.race([win.loadFile(f), new Promise((r) => setTimeout(r, 6000))]);
      await new Promise((r) => setTimeout(r, WAIT));
      let img = await win.capturePage();
      if (THUMB) img = img.resize({ width: THUMB });
      fs.writeFileSync(out, THUMB ? img.toJPEG(82) : img.toPNG());
      n++;
      console.log("ok", path.basename(out));
    } catch (e) { console.log("fail", path.basename(f), e.message); }
  }
  console.log("done", n);
  app.quit();
});
